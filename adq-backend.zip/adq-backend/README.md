# ADQ Backend Server v2.0

A modular, scalable backend server for Agentic Data Quality with WebSocket and HTTP support.

## 🏗️ Architecture

### Modular Structure
```
adq-backend/
├── server.js                 # Main server entry point
├── package.json              # Dependencies and scripts
└── src/
    ├── config/
    │   └── server.config.js   # Centralized configuration
    ├── services/
    │   ├── messageProcessor.js    # Message parsing and routing
    │   └── pythonProcessManager.js # Python process management
    ├── handlers/
    │   └── webSocketHandler.js     # WebSocket connection handling
    ├── routes/
    │   └── httpRoutes.js           # HTTP API endpoints
    └── utils/
        └── logger.js               # Structured logging utility
```

## 🚀 Features

### WebSocket Support
- Real-time communication with React frontend
- Automatic process cleanup on disconnect
- Support for multiple concurrent connections
- Ping/pong for connection health monitoring

### HTTP API Support
- RESTful endpoints for testing and monitoring
- Postman-compatible test endpoint
- Health checks and server status
- Process and client management endpoints

### Message Processing
- Length-prefixed message protocol support
- Direct JSON message support
- Graceful fallback to plain text
- Extensible message type routing

### Process Management
- Automatic Python process spawning
- Process timeout handling
- Resource cleanup on completion/error
- Multiple process support with limits

### Logging & Monitoring
- Structured logging with levels
- Color-coded console output
- Request/response logging
- Process lifecycle tracking

## 🛠️ Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Start production server
npm start
```

## 📡 API Endpoints

### WebSocket Events

#### Incoming Events (from client):
- `start_process` - Start Python analysis with user data
- `stop_process` - Stop current Python process
- `ping` - Health check ping

#### Outgoing Events (to client):
- `process_step` - Analysis step update
- `final_response` - Final analysis result
- `lineage_tree` - Data lineage information
- `node_status_update` - Node status change
- `error` - Error information
- `process_complete` - Process completion notification

### HTTP Endpoints

#### GET Endpoints:
- `GET /` - Server information
- `GET /api/health` - Health check
- `GET /api/info` - Detailed server info
- `GET /api/processes` - Active processes
- `GET /api/clients` - Connected clients

#### POST Endpoints:
- `POST /api/test-python` - Test Python script execution

## 🧪 Testing

### WebSocket Testing (Browser Console)
```javascript
const socket = io('http://localhost:3001');

socket.on('connect', () => {
  console.log('Connected!');
  
  socket.emit('start_process', {
    "failed_table": "test_table",
    "failed_column": "test_column", 
    "db_type": "GCP"
  });
});

socket.on('process_step', (data) => {
  console.log('Step:', data);
});
```

### HTTP Testing (Postman)
```bash
POST http://localhost:3001/api/test-python
Content-Type: application/json

{
  "failed_table": "vz-it-np-gk1v-dev-cwlspr-0.vzw_uda_prd_tbls.port_sum_fact_adg",
  "failed_column": "port_out_cnt",
  "db_type": "GCP",
  "expected_value": 11477,
  "actual_value": 12584
}
```

## ⚙️ Configuration

Configuration is centralized in `src/config/server.config.js`:

```javascript
export const SERVER_CONFIG = {
  PORT: process.env.PORT || 3001,
  NODE_ENV: process.env.NODE_ENV || 'development',
  CORS_ORIGINS: [...],
  PYTHON: {
    SCRIPT_NAME: 'adq_agents_test.py',
    // ... other Python settings
  },
  PROCESS: {
    TIMEOUT_MS: 300000,
    MAX_ACTIVE_PROCESSES: 10
  }
};
```

## 🔧 Customization

### Adding New Message Types
```javascript
// In MessageProcessor
messageProcessor.registerHandler('custom_type', (socket, message) => {
  socket.emit('custom_event', message);
});
```

### Adding New HTTP Routes
```javascript
// In httpRoutes.js
router.get('/custom-endpoint', (req, res) => {
  res.json({ custom: 'response' });
});
```

### Custom Validation
```javascript
// In WebSocketHandler
validateUserData(userData) {
  // Add custom validation logic
  return userData.requiredField !== undefined;
}
```

## 🔒 Security Features

- CORS configuration
- Input validation
- Process isolation
- Resource limits
- Graceful error handling
- Request size limits

## 📈 Monitoring

- Process count tracking
- Memory usage monitoring
- Connection count tracking
- Request logging
- Error tracking

## 🚦 Environment Variables

```bash
PORT=3001                    # Server port
NODE_ENV=development         # Environment
LOG_LEVEL=info              # Logging level
```

## 🔄 Migration from v1.0

The new modular architecture is backward compatible. Existing WebSocket connections will work without changes. The main improvements are:

1. **Separation of Concerns** - Each module has a single responsibility
2. **Testability** - Individual components can be tested in isolation  
3. **Extensibility** - Easy to add new features without touching core logic
4. **Maintainability** - Clear code organization and documentation
5. **HTTP Support** - Added REST API for testing and monitoring

## 🐛 Troubleshooting

### Common Issues:

1. **Python script not found**
   - Check `PYTHON.SCRIPT_NAME` in config
   - Verify relative path structure

2. **WebSocket connection fails**
   - Check CORS configuration
   - Verify port accessibility

3. **Process timeout**
   - Increase `PROCESS.TIMEOUT_MS` in config
   - Check Python script execution time

## 📝 Logging

Logs are structured and color-coded:
- 🔴 **ERROR** - Process errors, exceptions
- 🟡 **WARN** - Warnings, deprecated usage
- 🔵 **INFO** - Server lifecycle, connections
- 🟣 **DEBUG** - Detailed execution info (dev only)

Example log output:
```
[2024-01-01T12:00:00.000Z] [INFO] [MainServer] 🚀 ADQ Backend Server v2.0 running on port 3001
[2024-01-01T12:00:01.000Z] [INFO] [WebSocketHandler] Client connected: abc123
[2024-01-01T12:00:02.000Z] [DEBUG] [MessageProcessor] Routing message type: process_step
```
