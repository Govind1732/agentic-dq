import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import Joi from 'joi';
import { EventEmitter } from 'events';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Express app
const app = express();
const server = createServer(app);

// Socket.IO server with updated CORS to include more ports
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:5173", "http://localhost:5174", "http://localhost:5175", "http://localhost:5176", "http://localhost:5177", "http://localhost:3000"],
    methods: ["GET", "POST"],
    credentials: true
  },
  pingTimeout: 60000,
  pingInterval: 25000,
  maxHttpBufferSize: 1e6,
  allowEIO3: true
});

// Middleware with updated CORS
app.use(cors({
  origin: ["http://localhost:5173", "http://localhost:5174", "http://localhost:5175", "http://localhost:5176", "http://localhost:5177", "http://localhost:3000"],
  credentials: true,
  optionsSuccessStatus: 200
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Simple test endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'CORS Fixed Server Running' });
});

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);
  
  socket.on('start_process', (userData) => {
    console.log('Received start_process:', userData);
    
    // Send a test response
    socket.emit('process_step', {
      type: 'bot_introduction',
      content: "Hello! I'm your Data Quality Assistant. I can help you identify and resolve data quality issues by tracing through your data lineage.",
      timestamp: new Date().toISOString(),
      title: 'Welcome',
      emoji: '👋',
      sample_input: {
        failed_table: "revenue_summary_fact",
        failed_column: "total_revenue", 
        validation_query: "SELECT COUNT(*) as validation_result FROM revenue_summary_fact WHERE total_revenue < 0 AND business_date = '2024-01-15'",
        expected_value: 0,
        expected_std_dev: 0,
        sd_threshold: 3
      }
    });
  });
  
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`🚀 CORS Fixed Backend Server running on port ${PORT}`);
  console.log(`📡 WebSocket server ready for connections`);
  console.log(`🔗 Frontend can connect from ports: 3000, 5173-5177`);
});
