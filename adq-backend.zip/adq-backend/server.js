import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { PythonShell } from 'python-shell';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const server = createServer(app);

// Setup Socket.IO with CORS
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:5173", "http://localhost:3000", "http://localhost:3004"], // Vite and Create React App default ports
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: ["http://localhost:5173", "http://localhost:3000", "http://localhost:3004"],
  methods: ["GET", "POST"],
  credentials: true
}));
app.use(express.json());

// Store active Python processes and prevent duplicates
const activePythonProcesses = new Map();
const processingRequests = new Set(); // Track requests being processed

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);

  socket.on('disconnect', () => {
    console.log(`[${socket.id}] Client disconnected`);
    
    // Clean up any active Python processes for this socket
    if (activePythonProcesses.has(socket.id)) {
      const pythonProcess = activePythonProcesses.get(socket.id);
      pythonProcess.kill();
      activePythonProcesses.delete(socket.id);
    }
    
    // Remove from processing requests
    processingRequests.delete(socket.id);
  });

  // Handle start process request from frontend
  socket.on('start_process', (userData) => {
    console.log(`[${socket.id}] Starting RCA process for:`, userData);
    
    // Check if this socket is already processing a request
    if (processingRequests.has(socket.id)) {
      console.log(`[${socket.id}] Request already being processed, ignoring duplicate`);
      return;
    }
    
    // Check if this socket already has an active process
    if (activePythonProcesses.has(socket.id)) {
      console.log(`[${socket.id}] Process already running for this socket, ignoring duplicate request`);
      socket.emit('error', {
        type: 'error',
        message: 'A process is already running for this connection. Please wait for it to complete.',
        timestamp: new Date().toISOString()
      });
      return;
    }
    
    // Mark this socket as processing a request
    processingRequests.add(socket.id);
    
    // Extract the actual message data if it's wrapped
    let actualData = userData;
    if (userData && userData.message && typeof userData.message === 'object') {
      actualData = userData.message;
      console.log(`[${socket.id}] Extracted message data:`, actualData);
    }
    
    startRCAProcess(socket, actualData);
  });
});

// HTTP POST endpoint for starting RCA
app.post('/api/start-rca', (req, res) => {
  const userData = req.body;
  console.log('RCA process started via HTTP:', userData);
  
  // For HTTP requests, we'll emit to all connected sockets
  // You could modify this to be more specific if needed
  io.emit('process_started', userData);
  
  res.json({ status: 'RCA process started', data: userData });
});

// Function to start the Python RCA process
function startRCAProcess(socket, userData) {
  try {
    console.log(`[${socket.id}] Starting Python RCA process...`);
    
    // Check if too many processes are running
    if (activePythonProcesses.size >= 3) {
      console.log(`[${socket.id}] Server busy - ${activePythonProcesses.size} processes already running`);
      socket.emit('error', {
        type: 'error',
        message: 'Server is busy. Too many active processes. Please try again in a moment.',
        timestamp: new Date().toISOString()
      });
      return;
    }

    // Double-check if this socket already has an active process
    if (activePythonProcesses.has(socket.id)) {
      console.log(`[${socket.id}] Killing existing process before starting new one`);
      activePythonProcesses.get(socket.id).kill();
      activePythonProcesses.delete(socket.id);
    }

    // Path to the Python script - use the real adq_agents.py script
    const pythonScriptPath = path.join(__dirname, '..', 'adq-python-script', 'scripts', 'adq_agents.py');
    
    // Convert userData to JSON string
    const userDataJson = JSON.stringify(userData, null, 2);
    console.log('Data being sent to Python script:', userDataJson);
    console.log('Python script path:', pythonScriptPath);
    
    // Use the .venv Python interpreter that has pyvegas installed
    const venvPythonPath = path.join(__dirname, '..', 'adq-python-script', '.venv', 'Scripts', 'python.exe');
    console.log('Using Python interpreter:', venvPythonPath);
    
    // Encode JSON as base64 to safely pass through command line
    const userDataBase64 = Buffer.from(userDataJson, 'utf8').toString('base64');
    console.log('Encoded user data as base64 for safe command line transmission');
    
    // Pass the base64-encoded JSON as argument
    const options = {
      mode: 'text',
      pythonPath: venvPythonPath,
      pythonOptions: ['-u'], // Unbuffered output
      scriptPath: path.dirname(pythonScriptPath),
      args: ['--base64', userDataBase64], // Pass base64-encoded JSON
      env: {
        ...process.env,
        PYTHONIOENCODING: 'utf-8',
        PYTHONLEGACYWINDOWSSTDIO: '1',
        PYTHONUNBUFFERED: '1',
        PYTHONUTF8: '1'
      }
    };

    // Start the Python process
    const pythonProcess = new PythonShell(path.basename(pythonScriptPath), options);
    
    // Store the process reference
    activePythonProcesses.set(socket.id, pythonProcess);
    console.log(`[${socket.id}] Python process started. Active processes: ${activePythonProcesses.size}`);
    
    // Clear the processing flag since process is now active
    processingRequests.delete(socket.id);

    // Set up a timeout to kill hung processes (10 minutes)
    const processTimeout = setTimeout(() => {
      console.log(`[${socket.id}] Killing Python process due to timeout`);
      if (activePythonProcesses.has(socket.id)) {
        pythonProcess.kill();
        activePythonProcesses.delete(socket.id);
        processingRequests.delete(socket.id);
        
        socket.emit('error', {
          type: 'error',
          message: 'Process timed out after 10 minutes. Please try again.',
          timestamp: new Date().toISOString()
        });
      }
    }, 10 * 60 * 1000); // 10 minutes

    // Emit initial acknowledgment
    socket.emit('acknowledgment', {
      type: 'acknowledgment',
      content: 'Starting Agentic Data Quality analysis...',
      timestamp: new Date().toISOString()
    });

    // Handle Python script output (real-time)
    let messageBuffer = '';
    let expectedLength = null;

    pythonProcess.on('message', (message) => {
      try {
        console.log('Python output:', message);
        
        // Accumulate data in buffer
        messageBuffer += message;
        
        // Process complete messages
        while (messageBuffer.length > 0) {
          if (expectedLength === null) {
            // Look for length prefix
            const newlineIndex = messageBuffer.indexOf('\n');
            if (newlineIndex === -1) break; // Wait for more data
            
            const lengthStr = messageBuffer.substring(0, newlineIndex);
            expectedLength = parseInt(lengthStr, 10);
            messageBuffer = messageBuffer.substring(newlineIndex + 1);
            
            if (isNaN(expectedLength)) {
              // Skip non-delimited messages (like pyvegas logs)
              const nextNewlineIndex = messageBuffer.indexOf('\n');
              if (nextNewlineIndex !== -1) {
                messageBuffer = messageBuffer.substring(nextNewlineIndex + 1);
              } else {
                messageBuffer = ''; // Clear buffer if no more newlines
              }
              expectedLength = null;
              continue;
            }
          }
          
          if (messageBuffer.length < expectedLength + 1) {
            break; // Wait for complete message
          }
          
          // Extract the complete message
          const completeMessage = messageBuffer.substring(0, expectedLength);
          messageBuffer = messageBuffer.substring(expectedLength + 1); // +1 for trailing newline
          expectedLength = null;
          
          // Process the complete message
          processCompleteMessage(completeMessage, socket);
        }
        
      } catch (error) {
        console.error('Error processing Python output buffer:', error);
        socket.emit('error', {
          type: 'error',
          message: `Error processing output: ${error.message}`,
          timestamp: new Date().toISOString()
        });
      }
    });

    // Handle regular stdout (fallback for non-delimited messages)
    pythonProcess.stdout?.on('data', (data) => {
      const message = data.toString();
      console.log('Python stdout:', message);
      
      // Try to parse as JSON for backwards compatibility
      try {
        const parsedMessage = JSON.parse(message);
        processCompleteMessage(JSON.stringify(parsedMessage), socket);
      } catch (e) {
        // If not JSON, treat as plain text
        socket.emit('process_step', {
          type: 'process_step',
          content: message,
          timestamp: new Date().toISOString()
        });
      }
    });

    // Handle stderr for Python errors
    pythonProcess.stderr?.on('data', (data) => {
      const errorMessage = data.toString();
      console.error(`[${socket.id}] Python stderr:`, errorMessage);
      
      // Send stderr output as error to frontend
      socket.emit('error', {
        type: 'error',
        message: `Python error: ${errorMessage}`,
        timestamp: new Date().toISOString()
      });
    });

    // Function to process complete messages
    function processCompleteMessage(messageStr, socket) {
      try {
        const parsedMessage = JSON.parse(messageStr);
        
        // Handle different message types based on the Python script output format
        if (parsedMessage.type === 'LINEAGE_TREE') {
          socket.emit('lineage_tree', parsedMessage);
          return;
        }
        
        if (parsedMessage.type === 'NODE_STATUS') {
          socket.emit('node_status', parsedMessage);
          return;
        }
        
        if (parsedMessage.type === 'FLOW_UPDATE') {
          socket.emit('process_step', {
            title: parsedMessage.data?.stepId || 'Process Update',
            type: 'flow_update',
            content: parsedMessage.data?.message || 'Processing...',
            data: parsedMessage.data,
            status: parsedMessage.data?.status,
            timestamp: parsedMessage.data?.timestamp || new Date().toISOString()
          });
          return;
        }

        // Handle standard message format from send_update function
        if (parsedMessage.title && parsedMessage.type && parsedMessage.content) {
          const isFinalResponse = parsedMessage.title === 'Final Summary' || 
                                 parsedMessage.type === 'final_summary' ||
                                 parsedMessage.type === 'completion';

          if (isFinalResponse) {
            socket.emit('final_response', {
              type: 'final_response',
              content: parsedMessage.content,
              timestamp: parsedMessage.timestamp || new Date().toISOString()
            });
          } else if (parsedMessage.type === 'error') {
            socket.emit('error', {
              type: 'error',
              message: parsedMessage.content,
              timestamp: parsedMessage.timestamp || new Date().toISOString()
            });
          } else {
            socket.emit('process_step', {
              type: 'process_step',
              content: parsedMessage.content,
              title: parsedMessage.title,
              timestamp: parsedMessage.timestamp || new Date().toISOString()
            });
          }
        } else {
          // Fallback for unstructured messages
          socket.emit('process_step', {
            type: 'process_step',
            content: messageStr,
            timestamp: new Date().toISOString()
          });
        }
        
      } catch (error) {
        console.error('Error parsing complete message:', error);
        socket.emit('process_step', {
          type: 'process_step',
          content: messageStr,
          timestamp: new Date().toISOString()
        });
      }
    }

    // Handle Python script completion
    pythonProcess.on('close', (code, signal) => {
      console.log(`[${socket.id}] Python script finished with code: ${code}, signal: ${signal}`);
      
      // Clear the timeout
      clearTimeout(processTimeout);
      
      // Clean up the process reference
      activePythonProcesses.delete(socket.id);
      console.log(`[${socket.id}] Process cleaned up. Active processes: ${activePythonProcesses.size}`);
      
      // Handle different exit scenarios
      if (code === 0 || (code === null && signal === null)) {
        // Success case - either explicit 0 or normal termination
        console.log(`[${socket.id}] Process completed successfully`);
        socket.emit('final_response', {
          type: 'final_response',
          content: 'Root Cause Analysis completed successfully.',
          timestamp: new Date().toISOString()
        });
      } else if (signal) {
        // Process was killed by signal
        console.log(`[${socket.id}] Process terminated by signal: ${signal}`);
        socket.emit('error', {
          type: 'error',
          message: `Process was terminated (signal: ${signal}). Please try again.`,
          timestamp: new Date().toISOString()
        });
      } else if (code === null || code === undefined) {
        // Handle undefined exit code - likely successful completion on Windows
        console.log(`[${socket.id}] Process completed with undefined exit code - treating as success`);
        socket.emit('final_response', {
          type: 'final_response',
          content: 'Root Cause Analysis completed successfully.',
          timestamp: new Date().toISOString()
        });
      } else {
        // Non-zero exit code
        console.log(`[${socket.id}] Process failed with exit code: ${code}`);
        socket.emit('error', {
          type: 'error',
          message: `Process completed with error code: ${code}. Please check the Python script and dependencies.`,
          timestamp: new Date().toISOString()
        });
      }
    });

    // Handle Python script errors
    pythonProcess.on('error', (error) => {
      console.error(`[${socket.id}] Python script error:`, error);
      
      // Clear the timeout
      clearTimeout(processTimeout);
      
      // Clear processing flag
      processingRequests.delete(socket.id);
      
      socket.emit('error', {
        type: 'error',
        message: `Python script error: ${error.message}. Please check if Python is installed and accessible.`,
        timestamp: new Date().toISOString()
      });
      
      // Clean up
      activePythonProcesses.delete(socket.id);
    });

  } catch (error) {
    console.error(`[${socket.id}] Error starting Python process:`, error);
    
    // Clear processing flag on error
    processingRequests.delete(socket.id);
    
    socket.emit('error', {
      type: 'error',
      message: `Failed to start RCA process: ${error.message}`,
      timestamp: new Date().toISOString()
    });
  }
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    activeProcesses: activePythonProcesses.size,
    processingRequests: processingRequests.size,
    connections: io.engine.clientsCount
  });
});

// Serve test page
app.get('/test', (req, res) => {
  res.sendFile(path.join(__dirname, 'test.html'));
});

// Start the server
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`🚀 Agentic DQ Backend Server running on port ${PORT}`);
  console.log(`📡 WebSocket server ready for connections`);
  console.log(`🔗 Frontend can connect to: http://localhost:${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Shutting down server...');
  
  // Kill all active Python processes
  activePythonProcesses.forEach((process, socketId) => {
    console.log(`Killing Python process for socket: ${socketId}`);
    process.kill();
  });
  
  server.close(() => {
    console.log('Server closed.');
    process.exit(0);
  });
});
