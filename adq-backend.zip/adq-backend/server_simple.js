import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Express app
const app = express();
const server = createServer(app);

// Socket.IO server
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:3003", "http://localhost:5173", "http://localhost:5174", "http://localhost:5175", "http://localhost:5176", "http://localhost:5177", "http://localhost:3000"],
    methods: ["GET", "POST"],
    credentials: true
  }
});

// CORS middleware
app.use(cors({
  origin: ["http://localhost:3003", "http://localhost:5173", "http://localhost:5174", "http://localhost:5175", "http://localhost:5176", "http://localhost:5177", "http://localhost:3000"],
  credentials: true
}));

app.use(express.json());

// Store active processes
const activeProcesses = new Map();

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`✅ Client connected: ${socket.id}`);
  
  socket.on('disconnect', (reason) => {
    console.log(`❌ Client disconnected: ${socket.id}, reason: ${reason}`);
    
    // Kill any active process for this socket
    const process = activeProcesses.get(socket.id);
    if (process && !process.killed) {
      process.kill();
      activeProcesses.delete(socket.id);
    }
  });

  // Handle messages from frontend
  socket.on('start_process', (userData) => {
    console.log('Received user data:', userData);
    startPythonScript(socket, userData);
  });
});

// Function to start Python script
function startPythonScript(socket, userData) {
  try {
    // Kill any existing process for this socket
    const existingProcess = activeProcesses.get(socket.id);
    if (existingProcess && !existingProcess.killed) {
      existingProcess.kill();
    }

    // Set up paths
    const baseDir = path.join(__dirname, '..', 'adq-python-script');
    const scriptsDir = path.join(baseDir, 'scripts');
    const pythonScriptPath = path.join(scriptsDir, 'adq_agents_test.py');
    const pythonVenvPath = path.join(baseDir, '.venv', 'Scripts', 'python.exe');
    
    console.log('Starting Python script:', pythonScriptPath);
    
    // Convert user data to JSON string
    const userDataJson = JSON.stringify(userData);
    
    // Python arguments
    const pythonArgs = ['-u', 'adq_agents_test.py', userDataJson];
    
    // Spawn options
    const spawnOptions = {
      cwd: scriptsDir,
      stdio: ['ignore', 'pipe', 'pipe']
    };

    // Start Python process
    const pythonProcess = spawn(pythonVenvPath, pythonArgs, spawnOptions);
    
    // Store process reference
    activeProcesses.set(socket.id, pythonProcess);
    
    console.log(`Python process started for socket ${socket.id}`);

    // Handle Python stdout
    pythonProcess.stdout.on('data', (data) => {
      const output = data.toString();
      console.log('Python output:', output);
      
      // Try to parse as delimited message
      const lines = output.split('\n');
      for (const line of lines) {
        if (line.trim()) {
          processMessage(socket, line.trim());
        }
      }
    });

    // Handle Python stderr
    pythonProcess.stderr.on('data', (data) => {
      const errorMessage = data.toString();
      console.error('Python error:', errorMessage);
      
      socket.emit('error', {
        type: 'python_error',
        message: errorMessage
      });
    });

    // Handle process completion
    pythonProcess.on('close', (code) => {
      console.log(`Python process finished with code: ${code}`);
      activeProcesses.delete(socket.id);
      
      if (code === 0) {
        socket.emit('process_complete', {
          message: 'Analysis completed successfully'
        });
      } else {
        socket.emit('error', {
          type: 'process_error',
          message: `Process failed with code: ${code}`
        });
      }
    });

    // Handle process errors
    pythonProcess.on('error', (error) => {
      console.error('Process error:', error);
      activeProcesses.delete(socket.id);
      
      socket.emit('error', {
        type: 'spawn_error',
        message: error.message
      });
    });

  } catch (error) {
    console.error('Error starting Python script:', error);
    socket.emit('error', {
      type: 'startup_error',
      message: error.message
    });
  }
}

// Process messages from Python script
function processMessage(socket, message) {
  try {
    // Check if it's a length-prefixed message: [LENGTH]MESSAGE
    const lengthMatch = message.match(/^\[(\d+)\](.+)$/);
    if (lengthMatch) {
      const expectedLength = parseInt(lengthMatch[1]);
      const content = lengthMatch[2];
      
      if (content.length === expectedLength) {
        // Parse the JSON content
        const parsedMessage = JSON.parse(content);
        
        // Emit based on message type
        if (parsedMessage.type === 'final_response') {
          socket.emit('final_response', parsedMessage);
        } else if (parsedMessage.type === 'lineage_tree') {
          socket.emit('lineage_tree', parsedMessage);
        } else if (parsedMessage.type === 'node_status_update') {
          socket.emit('node_status_update', parsedMessage);
        } else {
          socket.emit('process_step', parsedMessage);
        }
        return;
      }
    }
    
    // If not length-prefixed, try to parse as JSON directly
    try {
      const parsedMessage = JSON.parse(message);
      socket.emit('process_step', parsedMessage);
    } catch (e) {
      // If not JSON, send as plain text
      socket.emit('process_step', {
        type: 'message',
        content: message
      });
    }
    
  } catch (error) {
    console.error('Error processing message:', error);
    socket.emit('process_step', {
      type: 'message',
      content: message
    });
  }
}

// Simple health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok',
    timestamp: new Date().toISOString()
  });
});

// Start server
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`🚀 Simple ADQ Backend running on port ${PORT}`);
  console.log(`📡 WebSocket ready for connections`);
});

// Cleanup on exit
process.on('SIGTERM', () => {
  console.log('Shutting down...');
  
  // Kill all active processes
  for (const [socketId, process] of activeProcesses) {
    if (!process.killed) {
      process.kill();
    }
  }
  
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Shutting down...');
  
  // Kill all active processes
  for (const [socketId, process] of activeProcesses) {
    if (!process.killed) {
      process.kill();
    }
  }
  
  process.exit(0);
});
