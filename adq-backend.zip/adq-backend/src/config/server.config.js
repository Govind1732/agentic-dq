/**
 * Server Configuration
 * Centralized configuration for the ADQ Backend server
 */

export const SERVER_CONFIG = {
  // Server settings
  PORT: process.env.PORT || 3001,
  NODE_ENV: process.env.NODE_ENV || 'development',
  
  // CORS settings
  CORS_ORIGINS: [
    "http://localhost:3000",
    "http://localhost:3003", 
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5175",
    "http://localhost:5176",
    "http://localhost:5177"
  ],
  
  // Python script settings
  PYTHON: {
    SCRIPT_NAME: 'adq_agents_test.py',
    VENV_PATH: '.venv',
    SCRIPTS_DIR: 'scripts',
    BASE_DIR_NAME: 'adq-python-script'
  },
  
  // Process settings
  PROCESS: {
    TIMEOUT_MS: 300000, // 5 minutes
    MAX_ACTIVE_PROCESSES: 10,
    KILL_SIGNAL: 'SIGTERM'
  },
  
  // Logging
  LOGGING: {
    LEVEL: process.env.LOG_LEVEL || 'info',
    ENABLE_DEBUG: process.env.NODE_ENV === 'development'
  }
};

export default SERVER_CONFIG;
