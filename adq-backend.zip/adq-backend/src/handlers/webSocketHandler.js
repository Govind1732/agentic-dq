/**
 * WebSocket Handler
 * Manages Socket.IO connections and events
 */

import { createLogger } from '../utils/logger.js';

const logger = createLogger('WebSocketHandler');

export class WebSocketHandler {
  constructor(io, pythonProcessManager) {
    this.io = io;
    this.pythonProcessManager = pythonProcessManager;
    this.connectedClients = new Map();
    this.setupConnectionHandlers();
  }

  /**
   * Setup Socket.IO connection handlers
   */
  setupConnectionHandlers() {
    this.io.on('connection', (socket) => {
      this.handleConnection(socket);
    });
  }

  /**
   * Handle new socket connection
   * @param {Object} socket - Socket.IO socket instance
   */
  handleConnection(socket) {
    logger.info(`Client connected: ${socket.id}`);
    
    // Store client info
    this.connectedClients.set(socket.id, {
      connectedAt: new Date(),
      lastActivity: new Date()
    });

    this.setupSocketEvents(socket);
  }

  /**
   * Setup event handlers for a socket
   * @param {Object} socket - Socket.IO socket instance
   */
  setupSocketEvents(socket) {
    // Handle disconnection
    socket.on('disconnect', (reason) => {
      this.handleDisconnection(socket, reason);
    });

    // Handle start process request
    socket.on('start_process', (userData) => {
      this.handleStartProcess(socket, userData);
    });

    // Handle stop process request
    socket.on('stop_process', () => {
      this.handleStopProcess(socket);
    });

    // Handle ping for connection health
    socket.on('ping', () => {
      this.handlePing(socket);
    });

    // Update last activity
    socket.onAny(() => {
      this.updateLastActivity(socket.id);
    });
  }

  /**
   * Handle client disconnection
   * @param {Object} socket - Socket.IO socket instance
   * @param {string} reason - Disconnection reason
   */
  handleDisconnection(socket, reason) {
    logger.info(`Client disconnected: ${socket.id}, reason: ${reason}`);
    
    // Kill any active process for this socket
    this.pythonProcessManager.killProcess(socket.id, 'client_disconnect');
    
    // Remove from connected clients
    this.connectedClients.delete(socket.id);
  }

  /**
   * Handle start process request
   * @param {Object} socket - Socket.IO socket instance
   * @param {Object} userData - User data for Python script
   */
  handleStartProcess(socket, userData) {
    logger.info(`Start process request from ${socket.id}`);
    
    // Validate user data
    if (!this.validateUserData(userData)) {
      socket.emit('error', {
        type: 'validation_error',
        message: 'Invalid user data provided',
        timestamp: new Date().toISOString()
      });
      return;
    }

    // Update activity
    this.updateLastActivity(socket.id);
    
    // Start Python script
    this.pythonProcessManager.startPythonScript(socket, userData);
  }

  /**
   * Handle stop process request
   * @param {Object} socket - Socket.IO socket instance
   */
  handleStopProcess(socket) {
    logger.info(`Stop process request from ${socket.id}`);
    this.pythonProcessManager.killProcess(socket.id, 'user_request');
    
    socket.emit('process_stopped', {
      message: 'Process stopped by user request',
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Handle ping request
   * @param {Object} socket - Socket.IO socket instance
   */
  handlePing(socket) {
    this.updateLastActivity(socket.id);
    socket.emit('pong', {
      timestamp: new Date().toISOString(),
      serverTime: Date.now()
    });
  }

  /**
   * Update last activity for a client
   * @param {string} socketId - Socket ID
   */
  updateLastActivity(socketId) {
    const clientInfo = this.connectedClients.get(socketId);
    if (clientInfo) {
      clientInfo.lastActivity = new Date();
    }
  }

  /**
   * Validate user data
   * @param {Object} userData - User data to validate
   * @returns {boolean} True if valid
   */
  validateUserData(userData) {
    // Basic validation - can be expanded
    if (!userData || typeof userData !== 'object') {
      return false;
    }

    // Add specific validation rules as needed
    // Example: Check for required fields
    // if (!userData.failed_table || !userData.failed_column) {
    //   return false;
    // }

    return true;
  }

  /**
   * Broadcast message to all connected clients
   * @param {string} event - Event name
   * @param {Object} data - Data to broadcast
   */
  broadcast(event, data) {
    logger.info(`Broadcasting ${event} to all clients`);
    this.io.emit(event, data);
  }

  /**
   * Get connected client count
   * @returns {number} Number of connected clients
   */
  getConnectedClientCount() {
    return this.connectedClients.size;
  }

  /**
   * Get client information
   * @param {string} socketId - Socket ID
   * @returns {Object|null} Client info or null
   */
  getClientInfo(socketId) {
    return this.connectedClients.get(socketId) || null;
  }

  /**
   * Get all connected clients info
   * @returns {Array} Array of client info objects
   */
  getAllClientsInfo() {
    return Array.from(this.connectedClients.entries()).map(([socketId, info]) => ({
      socketId,
      ...info
    }));
  }
}

export default WebSocketHandler;
