/**
 * HTTP Routes Handler
 * Optional HTTP endpoints for testing and monitoring
 */

import express from 'express';
import { createLogger } from '../utils/logger.js';
import { SERVER_CONFIG } from '../config/server.config.js';

const logger = createLogger('HTTPRoutes');

export function createHttpRoutes(pythonProcessManager, webSocketHandler) {
  const router = express.Router();

  // Health check endpoint
  router.get('/health', (req, res) => {
    const healthStatus = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      activeProcesses: pythonProcessManager.getActiveProcessCount(),
      connectedClients: webSocketHandler.getConnectedClientCount(),
      environment: SERVER_CONFIG.NODE_ENV,
      version: process.version
    };

    logger.info('Health check requested');
    res.json(healthStatus);
  });

  // Server info endpoint
  router.get('/info', (req, res) => {
    res.json({
      name: 'ADQ Backend Server',
      version: '2.0.0',
      description: 'Agentic Data Quality Backend with WebSocket support',
      endpoints: {
        health: '/api/health',
        info: '/api/info',
        test: '/api/test-python',
        processes: '/api/processes',
        clients: '/api/clients'
      },
      websocket: {
        events: {
          incoming: ['start_process', 'stop_process', 'ping'],
          outgoing: ['process_step', 'final_response', 'lineage_tree', 'node_status_update', 'error', 'process_complete']
        }
      }
    });
  });

  // Test endpoint for Postman testing
  router.post('/test-python', (req, res) => {
    logger.info('HTTP test request received', req.body);
    
    // Create a mock socket for HTTP testing
    const mockSocket = createMockSocket(res);
    
    try {
      pythonProcessManager.startPythonScript(mockSocket, req.body);
      
      res.json({
        status: 'success',
        message: 'Python script started via HTTP',
        socketId: mockSocket.id,
        timestamp: new Date().toISOString(),
        note: 'Check server logs for process output. For real-time updates, use WebSocket connection.'
      });
    } catch (error) {
      logger.error('HTTP test error:', error);
      res.status(500).json({
        status: 'error',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    }
  });

  // Get active processes info
  router.get('/processes', (req, res) => {
    const processes = [];
    
    // This would need to be implemented in PythonProcessManager
    // to return process information
    
    res.json({
      count: pythonProcessManager.getActiveProcessCount(),
      processes: processes,
      timestamp: new Date().toISOString()
    });
  });

  // Get connected clients info
  router.get('/clients', (req, res) => {
    res.json({
      count: webSocketHandler.getConnectedClientCount(),
      clients: webSocketHandler.getAllClientsInfo(),
      timestamp: new Date().toISOString()
    });
  });

  return router;
}

/**
 * Create a mock socket for HTTP testing
 * @param {Object} res - Express response object
 * @returns {Object} Mock socket object
 */
function createMockSocket(res) {
  const socketId = `http-test-${Date.now()}`;
  const results = [];

  return {
    id: socketId,
    emit: (event, data) => {
      const logEntry = {
        event,
        data,
        timestamp: new Date().toISOString()
      };
      
      results.push(logEntry);
      logger.info(`Mock socket emit: ${event}`, data);
      
      // For HTTP testing, we could store results and provide an endpoint to retrieve them
      // This is a simplified version
    },
    getResults: () => results
  };
}

export default createHttpRoutes;
