/**
 * Message Processing Module
 * Handles parsing and routing of messages from Python scripts
 */

import { createLogger } from '../utils/logger.js';

const logger = createLogger('MessageProcessor');

export class MessageProcessor {
  constructor() {
    this.messageHandlers = new Map();
    this.setupDefaultHandlers();
  }

  /**
   * Setup default message type handlers
   */
  setupDefaultHandlers() {
    this.messageHandlers.set('final_response', this.handleFinalResponse.bind(this));
    this.messageHandlers.set('lineage_tree', this.handleLineageTree.bind(this));
    this.messageHandlers.set('node_status_update', this.handleNodeStatusUpdate.bind(this));
    this.messageHandlers.set('process_step', this.handleProcessStep.bind(this));
  }

  /**
   * Process a message from Python script
   * @param {Object} socket - Socket.IO socket instance
   * @param {string} message - Raw message from Python
   */
  processMessage(socket, message) {
    try {
      let parsedMessage = this.parseMessage(message);
      
      if (parsedMessage) {
        this.routeMessage(socket, parsedMessage);
      } else {
        // Handle as plain text
        this.handlePlainText(socket, message);
      }
      
    } catch (error) {
      logger.error('Error processing message:', error);
      this.handleError(socket, message, error);
    }
  }

  /**
   * Parse incoming message - supports both length-prefixed and direct JSON
   * @param {string} message - Raw message
   * @returns {Object|null} - Parsed message or null
   */
  parseMessage(message) {
    // Try length-prefixed format first: [LENGTH]MESSAGE
    const lengthMatch = message.match(/^\[(\d+)\](.+)$/);
    if (lengthMatch) {
      const expectedLength = parseInt(lengthMatch[1]);
      const content = lengthMatch[2];
      
      if (content.length === expectedLength) {
        try {
          return JSON.parse(content);
        } catch (e) {
          logger.warn('Failed to parse length-prefixed JSON:', e.message);
          return null;
        }
      }
    }

    // Try direct JSON parsing
    try {
      return JSON.parse(message);
    } catch (e) {
      // Not JSON, will be handled as plain text
      return null;
    }
  }

  /**
   * Route message to appropriate handler based on type
   * @param {Object} socket - Socket.IO socket
   * @param {Object} parsedMessage - Parsed message object
   */
  routeMessage(socket, parsedMessage) {
    const messageType = parsedMessage.type || 'process_step';
    const handler = this.messageHandlers.get(messageType) || this.handleProcessStep.bind(this);
    
    logger.debug(`Routing message type: ${messageType}`);
    handler(socket, parsedMessage);
  }

  /**
   * Register a custom message handler
   * @param {string} type - Message type
   * @param {Function} handler - Handler function
   */
  registerHandler(type, handler) {
    this.messageHandlers.set(type, handler);
    logger.info(`Registered custom handler for message type: ${type}`);
  }

  // Default message handlers
  handleFinalResponse(socket, message) {
    logger.info('Emitting final_response');
    socket.emit('final_response', message);
  }

  handleLineageTree(socket, message) {
    logger.info('Emitting lineage_tree');
    socket.emit('lineage_tree', message);
  }

  handleNodeStatusUpdate(socket, message) {
    logger.debug('Emitting node_status_update');
    socket.emit('node_status_update', message);
  }

  handleProcessStep(socket, message) {
    logger.debug('Emitting process_step');
    socket.emit('process_step', message);
  }

  handlePlainText(socket, message) {
    logger.debug('Handling plain text message');
    socket.emit('process_step', {
      type: 'message',
      content: message,
      timestamp: new Date().toISOString()
    });
  }

  handleError(socket, originalMessage, error) {
    logger.error('Message processing error:', error);
    socket.emit('process_step', {
      type: 'error',
      content: `Error processing message: ${originalMessage}`,
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

export default MessageProcessor;
