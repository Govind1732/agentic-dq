/**
 * Python Process Manager
 * Handles spawning, monitoring, and cleanup of Python processes
 */

import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import { SERVER_CONFIG } from '../config/server.config.js';
import { createLogger } from '../utils/logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const logger = createLogger('PythonProcessManager');

export class PythonProcessManager {
  constructor(messageProcessor) {
    this.activeProcesses = new Map();
    this.messageProcessor = messageProcessor;
    this.setupPaths();
  }

  /**
   * Setup Python script paths
   */
  setupPaths() {
    this.baseDir = path.join(__dirname, '..', '..', '..', SERVER_CONFIG.PYTHON.BASE_DIR_NAME);
    this.scriptsDir = path.join(this.baseDir, SERVER_CONFIG.PYTHON.SCRIPTS_DIR);
    this.pythonScriptPath = path.join(this.scriptsDir, SERVER_CONFIG.PYTHON.SCRIPT_NAME);
    this.pythonVenvPath = path.join(this.baseDir, SERVER_CONFIG.PYTHON.VENV_PATH, 'Scripts', 'python.exe');
  }

  /**
   * Start Python script for a socket connection
   * @param {Object} socket - Socket.IO socket instance
   * @param {Object} userData - User data to pass to Python script
   */
  async startPythonScript(socket, userData) {
    try {
      // Kill any existing process for this socket
      await this.killExistingProcess(socket.id);

      // Check process limits
      if (this.activeProcesses.size >= SERVER_CONFIG.PROCESS.MAX_ACTIVE_PROCESSES) {
        throw new Error('Maximum number of active processes reached');
      }

      logger.info(`Starting Python script for socket ${socket.id}`);
      
      const userDataJson = JSON.stringify(userData);
      const pythonArgs = ['-u', SERVER_CONFIG.PYTHON.SCRIPT_NAME, userDataJson];
      
      const spawnOptions = {
        cwd: this.scriptsDir,
        stdio: ['ignore', 'pipe', 'pipe'],
        env: { ...process.env }
      };

      const pythonProcess = spawn(this.pythonVenvPath, pythonArgs, spawnOptions);
      
      // Store process with metadata
      this.activeProcesses.set(socket.id, {
        process: pythonProcess,
        startTime: Date.now(),
        userData: userData
      });
      
      this.setupProcessHandlers(socket, pythonProcess);
      
      logger.info(`Python process started for socket ${socket.id} (PID: ${pythonProcess.pid})`);
      
      // Setup process timeout
      this.setupProcessTimeout(socket.id);

    } catch (error) {
      logger.error('Error starting Python script:', error);
      socket.emit('error', {
        type: 'startup_error',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * Setup event handlers for Python process
   * @param {Object} socket - Socket.IO socket
   * @param {Object} pythonProcess - Child process instance
   */
  setupProcessHandlers(socket, pythonProcess) {
    // Handle stdout
    pythonProcess.stdout.on('data', (data) => {
      const output = data.toString();
      logger.debug('Python stdout:', output);
      
      const lines = output.split('\n');
      for (const line of lines) {
        if (line.trim()) {
          this.messageProcessor.processMessage(socket, line.trim());
        }
      }
    });

    // Handle stderr
    pythonProcess.stderr.on('data', (data) => {
      const errorMessage = data.toString();
      logger.error('Python stderr:', errorMessage);
      
      socket.emit('error', {
        type: 'python_error',
        message: errorMessage,
        timestamp: new Date().toISOString()
      });
    });

    // Handle process completion
    pythonProcess.on('close', (code, signal) => {
      logger.info(`Python process finished for socket ${socket.id} with code: ${code}, signal: ${signal}`);
      this.cleanupProcess(socket.id);
      
      if (code === 0) {
        socket.emit('process_complete', {
          message: 'Analysis completed successfully',
          timestamp: new Date().toISOString()
        });
      } else {
        socket.emit('error', {
          type: 'process_error',
          message: `Process failed with code: ${code}`,
          timestamp: new Date().toISOString()
        });
      }
    });

    // Handle process errors
    pythonProcess.on('error', (error) => {
      logger.error('Python process error:', error);
      this.cleanupProcess(socket.id);
      
      socket.emit('error', {
        type: 'spawn_error',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    });
  }

  /**
   * Setup process timeout
   * @param {string} socketId - Socket ID
   */
  setupProcessTimeout(socketId) {
    setTimeout(() => {
      const processInfo = this.activeProcesses.get(socketId);
      if (processInfo && !processInfo.process.killed) {
        logger.warn(`Process timeout for socket ${socketId}`);
        this.killProcess(socketId, 'timeout');
      }
    }, SERVER_CONFIG.PROCESS.TIMEOUT_MS);
  }

  /**
   * Kill existing process for a socket
   * @param {string} socketId - Socket ID
   */
  async killExistingProcess(socketId) {
    const existingProcessInfo = this.activeProcesses.get(socketId);
    if (existingProcessInfo && !existingProcessInfo.process.killed) {
      logger.info(`Killing existing process for socket ${socketId}`);
      existingProcessInfo.process.kill(SERVER_CONFIG.PROCESS.KILL_SIGNAL);
      this.cleanupProcess(socketId);
    }
  }

  /**
   * Kill a process by socket ID
   * @param {string} socketId - Socket ID
   * @param {string} reason - Reason for killing
   */
  killProcess(socketId, reason = 'manual') {
    const processInfo = this.activeProcesses.get(socketId);
    if (processInfo && !processInfo.process.killed) {
      logger.info(`Killing process for socket ${socketId}, reason: ${reason}`);
      processInfo.process.kill(SERVER_CONFIG.PROCESS.KILL_SIGNAL);
      this.cleanupProcess(socketId);
    }
  }

  /**
   * Cleanup process from active processes map
   * @param {string} socketId - Socket ID
   */
  cleanupProcess(socketId) {
    this.activeProcesses.delete(socketId);
    logger.debug(`Cleaned up process for socket ${socketId}`);
  }

  /**
   * Get active process count
   * @returns {number} Number of active processes
   */
  getActiveProcessCount() {
    return this.activeProcesses.size;
  }

  /**
   * Get process info for a socket
   * @param {string} socketId - Socket ID
   * @returns {Object|null} Process info or null
   */
  getProcessInfo(socketId) {
    return this.activeProcesses.get(socketId) || null;
  }

  /**
   * Kill all active processes
   */
  killAllProcesses() {
    logger.info('Killing all active processes');
    for (const [socketId, processInfo] of this.activeProcesses) {
      if (!processInfo.process.killed) {
        processInfo.process.kill(SERVER_CONFIG.PROCESS.KILL_SIGNAL);
      }
    }
    this.activeProcesses.clear();
  }
}

export default PythonProcessManager;
