/**
 * Simple Logger Utility
 * Provides structured logging with different levels
 */

import { SERVER_CONFIG } from '../config/server.config.js';

const LOG_LEVELS = {
  error: 0,
  warn: 1,
  info: 2,
  debug: 3
};

const COLORS = {
  error: '\x1b[31m', // Red
  warn: '\x1b[33m',  // Yellow
  info: '\x1b[36m',  // Cyan
  debug: '\x1b[35m', // Magenta
  reset: '\x1b[0m'   // Reset
};

export class Logger {
  constructor(module = 'App') {
    this.module = module;
    this.level = LOG_LEVELS[SERVER_CONFIG.LOGGING.LEVEL] || LOG_LEVELS.info;
  }

  /**
   * Format log message
   * @param {string} level - Log level
   * @param {string} message - Log message
   * @param {any} data - Additional data
   * @returns {string} Formatted message
   */
  formatMessage(level, message, data) {
    const timestamp = new Date().toISOString();
    const color = COLORS[level] || '';
    const reset = COLORS.reset;
    
    let formatted = `${color}[${timestamp}] [${level.toUpperCase()}] [${this.module}] ${message}${reset}`;
    
    if (data !== undefined) {
      formatted += `\n${JSON.stringify(data, null, 2)}`;
    }
    
    return formatted;
  }

  /**
   * Log error message
   * @param {string} message - Error message
   * @param {any} data - Additional data
   */
  error(message, data) {
    if (this.level >= LOG_LEVELS.error) {
      console.error(this.formatMessage('error', message, data));
    }
  }

  /**
   * Log warning message
   * @param {string} message - Warning message
   * @param {any} data - Additional data
   */
  warn(message, data) {
    if (this.level >= LOG_LEVELS.warn) {
      console.warn(this.formatMessage('warn', message, data));
    }
  }

  /**
   * Log info message
   * @param {string} message - Info message
   * @param {any} data - Additional data
   */
  info(message, data) {
    if (this.level >= LOG_LEVELS.info) {
      console.log(this.formatMessage('info', message, data));
    }
  }

  /**
   * Log debug message
   * @param {string} message - Debug message
   * @param {any} data - Additional data
   */
  debug(message, data) {
    if (this.level >= LOG_LEVELS.debug && SERVER_CONFIG.LOGGING.ENABLE_DEBUG) {
      console.log(this.formatMessage('debug', message, data));
    }
  }
}

/**
 * Create a logger instance for a module
 * @param {string} module - Module name
 * @returns {Logger} Logger instance
 */
export function createLogger(module) {
  return new Logger(module);
}

export default Logger;
