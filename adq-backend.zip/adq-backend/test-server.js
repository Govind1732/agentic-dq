/**
 * Simple test script to verify the server is working
 */

console.log('🧪 Testing ADQ Backend Server...');

// Test HTTP endpoints
async function testHttpEndpoints() {
  console.log('\n📡 Testing HTTP endpoints...');
  
  try {
    // Test health endpoint
    const healthResponse = await fetch('http://localhost:3001/api/health');
    const healthData = await healthResponse.json();
    console.log('✅ Health check:', healthData.status);
    
    // Test info endpoint
    const infoResponse = await fetch('http://localhost:3001/api/info');
    const infoData = await infoResponse.json();
    console.log('✅ Info endpoint:', infoData.name);
    
  } catch (error) {
    console.error('❌ HTTP test failed:', error.message);
  }
}

// Run tests
async function runTests() {
  await testHttpEndpoints();
  console.log('\n🎉 Basic HTTP tests completed!');
  console.log('💡 For WebSocket testing, use the React frontend or browser console');
  process.exit(0);
}

runTests().catch(console.error);
