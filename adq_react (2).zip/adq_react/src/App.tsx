import { useReducer, useEffect, useCallback, useRef } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import InputBar from "./components/InputBar";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { useWebSocket } from "./hooks/useWebSocket";
import { appReducer, initialState } from "./reducers/appReducer";
// import { useConversationPersistence } from "./hooks/useConversationPersistence";
import type { Message, Conversation } from "./types";
import { generateId } from "./utils";
import { MESSAGE_TYPES } from "./types";

function App() {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const { socket, isConnected, connectionError, sendMessage, reconnect } = useWebSocket();
  const initializedRef = useRef(false);

  // Memoize the conversation loading callback
  // const handleLoadConversations = useCallback((conversations: Conversation[]) => {
  //   dispatch({ type: "LOAD_CONVERSATIONS", payload: conversations });
  // }, []);

  // Add conversation persistence
  // useConversationPersistence({
  //   conversations: state.conversations,
  //   onLoadConversations: handleLoadConversations,
  // });

  // Initialize with a default conversation (only once)
  useEffect(() => {
    // Use a small delay to ensure persistence hook has run first
    const timer = setTimeout(() => {
      if (!initializedRef.current && state.conversations.length === 0) {
        initializedRef.current = true;
        
        // Create intro message directly in useEffect to avoid dependency issues
        const introMessage: Message = {
          id: generateId(),
          type: MESSAGE_TYPES.BOT_INTRODUCTION,
          content: `Hello! 👋\nI can help you find the root cause of data quality issues using AI analysis.\n\nDescribe your issue, e.g.:\n"I see low volumes of netadds on dla_sum_fact"\n\nOr share details like this:`,
          role: "assistant",
          timestamp: new Date(),
          sample_input: {
            failed_table: "vz-it-np-gk1v-dev-cwlspr-0.vzw_uda_prd_tbls.port_sum_fact_adg",
            failed_column: "port_out_cnt",
            db_type: "GCP",
            validation_query: "select activity_dt, FORMAT_DATE('%A', cast(activity_dt as date)) day_of_week, activity_cd, sum(port_in_cnt) as port_in, sum(winback_cnt) as winback, sum(rollback_cnt) as roll_back, sum(port_out_cnt) as port_out from vz-it-np-gk1v-dev-cwlspr-0.vzw_uda_prd_tbls.port_sum_fact_adg where activity_dt = '2025-07-06' group by 1,2,3 order by 3,2",
            execution_date: "2025-07-06",
            sd_threshold: 3,
            expected_std_dev: 377,
            expected_value: 11477,
            actual_value: 12584,
          },
        };
        
        // const defaultConversation: Conversation = {
        //   id: generateId(),
        //   title: "New Chat",
        //   lastMessage: "Welcome to DQ Assistant",
        //   timestamp: new Date(),
        //   messages: [introMessage],
        // };

        // dispatch({ type: "ADD_CONVERSATION", payload: defaultConversation });
        // dispatch({ type: "SET_ACTIVE_CONVERSATION", payload: defaultConversation.id });
        dispatch({ type: "SET_MESSAGES", payload: [introMessage] });
      }
    }, 100);

    return () => clearTimeout(timer);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Update connection status
  useEffect(() => {
    dispatch({ type: "SET_CONNECTION_STATUS", payload: isConnected });
  }, [isConnected]);

  // WebSocket message handler with better error handling
  useEffect(() => {
    if (!socket) return;

    const handleMessage = (data: unknown) => {
      console.log("Received WebSocket message:", data);

      if (data && typeof data === "object" && "type" in data) {
        const messageData = data as Record<string, unknown>;

        try {
          if (messageData.type === "process_step") {
            const stepMessage: Message = {
              id: generateId(),
              content: (messageData.content as string) || "Processing step...",
              role: "assistant",
              type: MESSAGE_TYPES.STEP,
              timestamp: new Date(),
            };

            dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
          }

          if (messageData.type === "final_response") {
            let botMessage: Message;

            if (
              messageData.root_cause &&
              typeof messageData.root_cause === "object"
            ) {
              const rootCause = messageData.root_cause as Record<
                string,
                unknown
              >;
              botMessage = {
                id: generateId(),
                content:
                  (messageData.content as string) || "Analysis complete.",
                role: "assistant",
                type: MESSAGE_TYPES.ROOT_CAUSE_SUMMARY,
                timestamp: new Date(),
                root_cause: {
                  summary: (rootCause.summary as string) || "Analysis complete",
                  mismatch_count: rootCause.mismatch_count as number,
                  match_count: rootCause.match_count as number,
                },
                feedback_options: Array.isArray(messageData.feedback_options)
                  ? (messageData.feedback_options as string[])
                  : ["Yes", "No", "Partially"],
                extension_questions: Array.isArray(
                  messageData.extension_questions
                )
                  ? (messageData.extension_questions as string[])
                  : [],
              };
            } else if (Array.isArray(messageData.feedback_options)) {
              botMessage = {
                id: generateId(),
                content:
                  (messageData.content as string) ||
                  "How can I help you further?",
                role: "assistant",
                type: MESSAGE_TYPES.FEEDBACK_AND_EXTENSIONS,
                timestamp: new Date(),
                feedback_options: messageData.feedback_options as string[],
                extension_questions: Array.isArray(
                  messageData.extension_questions
                )
                  ? (messageData.extension_questions as string[])
                  : [],
              };
            } else {
              const content = messageData.content;
              botMessage = {
                id: generateId(),
                content:
                  typeof content === "string"
                    ? content
                    : JSON.stringify(content, null, 2),
                role: "assistant",
                type: MESSAGE_TYPES.MESSAGE,
                timestamp: new Date(),
                isJson: typeof content !== "string",
              };
            }

            dispatch({ type: "ADD_MESSAGE", payload: botMessage });
            dispatch({ type: "SET_LOADING", payload: false });
          }

          if (messageData.type === "acknowledgment") {
            const ackMessage: Message = {
              id: generateId(),
              content:
                (messageData.content as string) ||
                (messageData.message as string) ||
                "Processing your request...",
              role: "assistant",
              type: MESSAGE_TYPES.ACKNOWLEDGMENT,
              timestamp: new Date(),
            };

            dispatch({ type: "ADD_MESSAGE", payload: ackMessage });
          }

          if (messageData.type === "error") {
            const errorMessage: Message = {
              id: generateId(),
              content:
                (messageData.message as string) || "Backend error occurred.",
              role: "assistant",
              type: MESSAGE_TYPES.ERROR,
              timestamp: new Date(),
            };

            dispatch({ type: "ADD_MESSAGE", payload: errorMessage });
            dispatch({ type: "SET_LOADING", payload: false });
          }
        } catch (error) {
          console.error("Error processing WebSocket message:", error);
          const errorMessage: Message = {
            id: generateId(),
            content: "Error processing server response.",
            role: "assistant",
            type: MESSAGE_TYPES.ERROR,
            timestamp: new Date(),
          };

          dispatch({ type: "ADD_MESSAGE", payload: errorMessage });
          dispatch({ type: "SET_LOADING", payload: false });
        }
      }
    };

    socket.on("process_step", handleMessage);
    socket.on("final_response", handleMessage);
    socket.on("acknowledgment", handleMessage);
    socket.on("error", handleMessage);

    return () => {
      socket.off("process_step", handleMessage);
      socket.off("final_response", handleMessage);
      socket.off("acknowledgment", handleMessage);
      socket.off("error", handleMessage);
    };
  }, [socket]);

  // Send user input to backend via WebSocket and update state
  const handleSendMessage = useCallback(
    (content: string) => {
      let parsedContent: string | Record<string, unknown> = content;
      let isJson = false;

      // Safe JSON parsing with validation
      if (content.trim().startsWith("{") || content.trim().startsWith("[")) {
        try {
          const parsed = JSON.parse(content);
          if (typeof parsed === "object" && parsed !== null) {
            parsedContent = parsed;
            isJson = true;
          }
        } catch (error) {
          // Keep as string if not valid JSON
          console.warn("Invalid JSON provided:", error);
        }
      }

      // Add user message to the current conversation
      const userMessage: Message = {
        id: generateId(),
        content:
          typeof parsedContent === "string"
            ? parsedContent
            : JSON.stringify(parsedContent, null, 2),
        role: "user",
        timestamp: new Date(),
        isJson: isJson,
      };

      dispatch({ type: "ADD_MESSAGE", payload: userMessage });
      dispatch({ type: "SET_LOADING", payload: true });

      // Update conversation title if it's the first user message in the default conversation
      if (state.activeConversationId && state.conversations.length > 0) {
        const currentConversation = state.conversations.find(
          (c) => c.id === state.activeConversationId
        );
        if (currentConversation && currentConversation.title === "New Chat") {
          const newTitle =
            typeof parsedContent === "string"
              ? parsedContent.length > 30
                ? parsedContent.substring(0, 30) + "..."
                : parsedContent
              : "JSON Analysis";

          dispatch({
            type: "UPDATE_CONVERSATION",
            payload: {
              id: state.activeConversationId,
              updates: { title: newTitle },
            },
          });
        }
      }

      // Send message to backend via WebSocket
      if (isConnected && socket) {
        try {
          sendMessage({ message: parsedContent });
        } catch (error) {
          console.error("Failed to send message:", error);
          const errorMessage: Message = {
            id: generateId(),
            content: "Failed to send message. Please try again.",
            role: "assistant",
            type: MESSAGE_TYPES.ERROR,
            timestamp: new Date(),
          };

          dispatch({ type: "ADD_MESSAGE", payload: errorMessage });
          dispatch({ type: "SET_LOADING", payload: false });
        }
      } else {
        // Add error message if not connected
        const errorMessage: Message = {
          id: generateId(),
          content:
            connectionError ||
            "Not connected to backend. Please check your connection.",
          role: "assistant",
          type: MESSAGE_TYPES.ERROR,
          timestamp: new Date(),
        };

        dispatch({ type: "ADD_MESSAGE", payload: errorMessage });
        dispatch({ type: "SET_LOADING", payload: false });
      }
    },
    [
      state.activeConversationId,
      state.conversations,
      isConnected,
      socket,
      sendMessage,
      connectionError,
    ]
  );

  // Handle sample input from bot introduction
  const handleSampleInput = useCallback(
    (sampleData: unknown) => {
      const jsonString = JSON.stringify(sampleData, null, 2);
      handleSendMessage(jsonString);
    },
    [handleSendMessage]
  );

  // Handle feedback responses
  const handleFeedback = useCallback(
    (feedback: string) => {
      handleSendMessage(feedback);
    },
    [handleSendMessage]
  );

  // Handle extension questions
  const handleExtensionQuestion = useCallback(
    (question: string) => {
      handleSendMessage(question);
    },
    [handleSendMessage]
  );

  const handleNewChat = useCallback(() => {
    // Create intro message directly here to avoid dependency issues
    // const introMessage: Message = {
    //   id: generateId(),
    //   type: MESSAGE_TYPES.BOT_INTRODUCTION,
    //   content: `Hello! 👋\nI can help you find the root cause of data quality issues using AI analysis.\n\nDescribe your issue, e.g.:\n"I see low volumes of netadds on dla_sum_fact"\n\nOr share details like this:`,
    //   role: "assistant",
    //   timestamp: new Date(),
    //   sample_input: {
    //     failed_table: "vz-it-np-gk1v-dev-cwlspr-0.vzw_uda_prd_tbls.port_sum_fact_adg",
    //     failed_column: "port_out_cnt",
    //     db_type: "GCP",
    //     validation_query: "select activity_dt, FORMAT_DATE('%A', cast(activity_dt as date)) day_of_week, activity_cd, sum(port_in_cnt) as port_in, sum(winback_cnt) as winback, sum(rollback_cnt) as roll_back, sum(port_out_cnt) as port_out from vz-it-np-gk1v-dev-cwlspr-0.vzw_uda_prd_tbls.port_sum_fact_adg where activity_dt = '2025-07-06' group by 1,2,3 order by 3,2",
    //     execution_date: "2025-07-06",
    //     sd_threshold: 3,
    //     expected_std_dev: 377,
    //     expected_value: 11477,
    //     actual_value: 12584,
    //   },
    // };
    
    // const newConversation: Conversation = {
    //   id: generateId(),
    //   title: "New Chat",
    //   lastMessage: "Welcome to DQ Assistant",
    //   timestamp: new Date(),
    //   messages: [introMessage],
    // };

    // dispatch({ type: "ADD_CONVERSATION", payload: newConversation });
    // dispatch({ type: "SET_ACTIVE_CONVERSATION", payload: newConversation.id });
    // dispatch({ type: "SET_MESSAGES", payload: [introMessage] });
    // dispatch({ type: "SET_LOADING", payload: false });
    // dispatch({ type: "TOGGLE_SIDEBAR" });
  }, []);

  const handleSelectConversation = useCallback(
    (conversationId: string) => {
      const conversation = state.conversations.find(
        (c) => c.id === conversationId
      );
      if (conversation) {
        dispatch({ type: "SET_MESSAGES", payload: conversation.messages });
        dispatch({ type: "SET_ACTIVE_CONVERSATION", payload: conversationId });
        dispatch({ type: "SET_LOADING", payload: false });
        dispatch({ type: "TOGGLE_SIDEBAR" });
      }
    },
    [state.conversations]
  );

  const handleSidebarHover = useCallback((isHovering: boolean) => {
    dispatch({ type: "SET_SIDEBAR_HOVER", payload: isHovering });
  }, []);

  // Handle dark mode toggle
  const handleToggleDarkMode = useCallback(() => {
    console.log('Dark mode toggle called');
    dispatch({ type: "TOGGLE_DARK_MODE" });
  }, []);

  // Apply dark mode to document
  // useEffect(() => {
  //   console.log('Applying dark mode:', state.ui.darkMode);
  //   console.log('Document classes before:', document.documentElement.className);
  //   if (state.ui.darkMode) {
  //     document.documentElement.setAttribute('data-theme', 'dark');
  //     document.documentElement.classList.add('dark');
  //   } else {
  //     document.documentElement.removeAttribute('data-theme');
  //     document.documentElement.classList.remove('dark');
  //   }
  //   console.log('Document classes after:', document.documentElement.className);
  // }, [state.ui.darkMode]);

  // Determine if sidebar should be shown (open on mobile, or hovered on desktop)
  const shouldShowSidebar = state.ui.sidebarOpen || state.ui.sidebarHovered;

  return (
    <ErrorBoundary>
      <div className="flex h-screen bg-white dark:bg-gray-900">
        <Sidebar
          conversations={state.conversations}
          currentConversationId={state.activeConversationId}
          onNewChat={handleNewChat}
          onSelectConversation={handleSelectConversation}
          isOpen={shouldShowSidebar}
          onToggle={() => dispatch({ type: "TOGGLE_SIDEBAR" })}
          onHover={handleSidebarHover}
          darkMode={state.ui.darkMode}
          onToggleDarkMode={handleToggleDarkMode}
        />
        <div className="flex flex-1 flex-col">
          <ChatWindow
            messages={state.chatState.messages}
            isLoading={state.chatState.isLoading}
            onSampleInput={handleSampleInput}
            onFeedback={handleFeedback}
            onExtensionQuestion={handleExtensionQuestion}
          />
          <InputBar
            onSendMessage={handleSendMessage}
            isLoading={state.chatState.isLoading}
            disabled={!isConnected}
            placeholder={
              isConnected
                ? "What do you want to build?"
                : connectionError || "Connecting..."
            }
          />

          {/* Connection Error */}
          {connectionError && !isConnected && (
            <div className="mx-4 mb-4 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg p-4 text-gray-800 dark:text-gray-200 text-sm flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                  <svg className="w-4 h-4 text-gray-600 dark:text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <p className="font-medium">Connection Lost</p>
                  <p className="text-xs opacity-75">{connectionError}</p>
                </div>
              </div>
              <button
                onClick={reconnect}
                className="px-4 py-2 bg-gray-800 dark:bg-gray-600 text-white rounded-lg text-xs font-medium hover:bg-gray-900 dark:hover:bg-gray-500 transition-colors"
              >
                Reconnect
              </button>
            </div>
          )}
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default App;
