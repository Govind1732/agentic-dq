import React, { useEffect, useRef, memo, useMemo } from 'react';
import ChatMessage from './ChatMessage';
import { Sparkles } from 'lucide-react';
import type { Message } from '../types';
import { MESSAGE_TYPES } from '../types';
import { generateId } from '../utils';

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  onSampleInput?: (sampleData: unknown) => void;
  onFeedback?: (feedback: string) => void;
  onExtensionQuestion?: (question: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = memo(({ 
  messages, 
  isLoading, 
  onSampleInput, 
  onFeedback, 
  onExtensionQuestion 
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Always ensure intro message is at the top
  const displayMessages = useMemo(() => {
    const hasIntroMessage = messages.some(msg => msg.type === MESSAGE_TYPES.BOT_INTRODUCTION);
    
    if (hasIntroMessage) {
      // If intro message exists, display all messages as-is
      return messages;
    } else if (messages.length > 0) {
      // If there are messages but no intro, prepend the intro message
      const introMessage: Message = {
        id: 'intro-' + generateId(),
        type: MESSAGE_TYPES.BOT_INTRODUCTION,
        content: `Hello! 👋\nI can help you find the root cause of data quality issues using AI analysis.\n\nDescribe your issue, e.g.:\n"I see low volumes of netadds on dla_sum_fact"\n\nOr share details like this:`,
        role: "assistant",
        timestamp: new Date(),
        sample_input: {
          failed_table: "vz-it-np-gk1v-dev-cwlspr-0.vzw_uda_prd_tbls.port_sum_fact_adg",
          failed_column: "port_out_cnt",
          db_type: "GCP",
          validation_query: "select activity_dt, FORMAT_DATE('%A', cast(activity_dt as date)) day_of_week, activity_cd, sum(port_in_cnt) as port_in, sum(winback_cnt) as winback, sum(rollback_cnt) as roll_back, sum(port_out_cnt) as port_out from vz-it-np-gk1v-dev-cwlspr-0.vzw_uda_prd_tbls.port_sum_fact_adg where activity_dt = '2025-07-06' group by 1,2,3 order by 3,2",
          execution_date: "2025-07-06",
          sd_threshold: 3,
          expected_std_dev: 377,
          expected_value: 11477,
          actual_value: 12584,
        },
      };
      return [introMessage, ...messages];
    } else {
      // If no messages, return the existing messages (which should include intro from App.tsx)
      return messages;
    }
  }, [messages]);

  return (
    <div className="flex-1 flex flex-col bg-white dark:bg-gray-900 relative">
      <div
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto custom-scrollbar"
      >
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          {displayMessages.map((message) => (
            <ChatMessage 
              key={message.id}
              message={message}
              onSampleInput={onSampleInput}
              onFeedback={onFeedback}
              onExtensionQuestion={onExtensionQuestion}
            />
          ))}

          {isLoading && (
            <div className="flex gap-4 animate-fade-in">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-gray-800 dark:bg-gray-600 text-white rounded-lg flex items-center justify-center">
                  <Sparkles className="w-4 h-4 animate-pulse" />
                </div>
              </div>
              <div className="bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100 rounded-lg px-4 py-3 max-w-xs">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-gray-600 dark:bg-gray-400 rounded-full animate-pulse" />
                    <div className="w-2 h-2 bg-gray-500 dark:bg-gray-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                    <div className="w-2 h-2 bg-gray-600 dark:bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                  </div>
                  <span className="text-sm">Analyzing...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>
    </div>
  );
});

ChatWindow.displayName = 'ChatWindow';
export default ChatWindow;
