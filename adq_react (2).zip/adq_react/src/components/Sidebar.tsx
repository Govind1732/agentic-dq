import React, { memo, useState, useRef, useEffect } from 'react';
import { Plus, MessageSquare, Menu, X, Clock, User, Sun, Moon, ChevronDown } from 'lucide-react';
import type { Conversation } from '../types';

interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onNewChat: () => void;
  onSelectConversation: (conversationId: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  onHover: (isHovering: boolean) => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
}

const Sidebar: React.FC<SidebarProps> = memo(({
  conversations,
  currentConversationId,
  onNewChat,
  onSelectConversation,
  isOpen,
  onToggle,
  onHover,
  darkMode = false,
  onToggleDarkMode,
}) => {
  const [showThemeDropdown, setShowThemeDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowThemeDropdown(false);
      }
    };

    if (showThemeDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showThemeDropdown]);
  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString();
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-25 z-40 md:hidden"
          onClick={onToggle}
        />
      )}

      {/* Mobile toggle button */}
      <button
        onClick={onToggle}
        className="fixed top-4 left-4 z-50 md:hidden bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg p-2 shadow-sm"
      >
        {isOpen ? <X className="w-5 h-5 text-gray-700 dark:text-gray-200" /> : <Menu className="w-5 h-5 text-gray-700 dark:text-gray-200" />}
      </button>

      {/* Sidebar */}
      <div
        className={`
          fixed md:relative h-full bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 z-50 transition-transform duration-200
          ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
          ${isOpen ? 'w-80' : 'w-0 md:w-16 md:hover:w-80'}
        `}
        onMouseEnter={() => onHover(true)}
        onMouseLeave={() => onHover(false)}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <button
              onClick={onNewChat}
              className="w-full bg-gray-900 dark:bg-gray-700 text-white rounded-lg px-4 py-2 flex items-center gap-2 hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span className={`${isOpen ? '' : 'md:hidden'}`}>New Chat</span>
            </button>
          </div>

          {/* Conversations */}
          <div className="flex-1 overflow-y-auto p-2">
            {conversations.length === 0 ? (
              <div className={`p-4 text-center text-gray-500 dark:text-gray-400 ${isOpen ? '' : 'hidden'}`}>
                <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No conversations yet</p>
              </div>
            ) : (
              <div className="space-y-1">
                {conversations.map((conversation) => (
                  <button
                    key={conversation.id}
                    onClick={() => onSelectConversation(conversation.id)}
                    className={`
                      w-full text-left p-3 rounded-lg transition-colors group
                      ${currentConversationId === conversation.id
                        ? 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                      }
                    `}
                  >
                    <div className="flex items-start gap-3">
                      <MessageSquare className="w-4 h-4 mt-0.5 flex-shrink-0" />
                      <div className={`min-w-0 flex-1 ${isOpen ? '' : 'hidden'}`}>
                        <p className="font-medium truncate">{conversation.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Clock className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatTime(conversation.timestamp)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate mt-1">
                          {conversation.lastMessage}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Footer - Profile Section */}
          <div className={`p-4 border-t border-gray-200 dark:border-gray-700 ${isOpen ? '' : 'hidden'}`}>
            <div className="relative" ref={dropdownRef}>
              {/* Profile Button */}
              <button
                onClick={() => setShowThemeDropdown(!showThemeDropdown)}
                className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                <div className="w-8 h-8 bg-gray-800 dark:bg-gray-600 text-white rounded-full flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Govind</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Data Quality Assistant</p>
                </div>
                <ChevronDown 
                  className={`w-4 h-4 text-gray-400 dark:text-gray-500 transition-transform ${
                    showThemeDropdown ? 'rotate-180' : ''
                  }`} 
                />
              </button>

              {/* Theme Dropdown */}
              {showThemeDropdown && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg py-2">
                  <button
                    onClick={() => {
                      console.log('Theme toggle clicked, current darkMode:', darkMode);
                      onToggleDarkMode?.();
                      setShowThemeDropdown(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    {darkMode ? (
                      <>
                        <Sun className="w-4 h-4" />
                        <span>Light Theme</span>
                      </>
                    ) : (
                      <>
                        <Moon className="w-4 h-4" />
                        <span>Dark Theme</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
});

Sidebar.displayName = 'Sidebar';
export default Sidebar;
