interface AppConfig {
  websocketUrl: string;
  websocketTimeout: number;
  maxReconnectAttempts: number;
  reconnectDelay: number;
  maxReconnectDelay: number;
  isDevelopment: boolean;
  isProduction: boolean;
}

const config: AppConfig = {
  websocketUrl: import.meta.env.VITE_WEBSOCKET_URL || 'http://localhost:3001',
  websocketTimeout: Number(import.meta.env.VITE_WEBSOCKET_TIMEOUT) || 10000,
  maxReconnectAttempts: Number(import.meta.env.VITE_MAX_RECONNECT_ATTEMPTS) || 5,
  reconnectDelay: Number(import.meta.env.VITE_RECONNECT_DELAY) || 1000,
  maxReconnectDelay: Number(import.meta.env.VITE_MAX_RECONNECT_DELAY) || 30000,
  isDevelopment: import.meta.env.DEV,
  isProduction: import.meta.env.PROD,
};

export default config;

// Type-safe environment variables
declare global {
  interface ImportMetaEnv {
    readonly VITE_WEBSOCKET_URL?: string;
    readonly VITE_WEBSOCKET_TIMEOUT?: string;
    readonly VITE_MAX_RECONNECT_ATTEMPTS?: string;
    readonly VITE_RECONNECT_DELAY?: string;
    readonly VITE_MAX_RECONNECT_DELAY?: string;
  }

  interface ImportMeta {
    readonly env: ImportMetaEnv;
  }
}
