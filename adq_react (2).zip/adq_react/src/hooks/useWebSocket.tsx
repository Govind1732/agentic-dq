import { useEffect, useState, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import config from '../config/environment';
import { calculateBackoffDelay } from '../utils';
import { WEBSOCKET_EVENTS } from '../types';

interface UseWebSocketReturn {
  socket: Socket | null;
  isConnected: boolean;
  connectionError: string | null;
  sendMessage: (message: Record<string, unknown>) => void;
  reconnect: () => void;
  isReconnecting: boolean;
  connectionAttempts: number;
}

export function useWebSocket(url?: string): UseWebSocketReturn {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const maxReconnectAttempts = config.maxReconnectAttempts;
  const socketUrlRef = useRef(url || config.websocketUrl);
  const isManualDisconnect = useRef(false);
  const isMountedRef = useRef(true);
  const socketInstanceRef = useRef<Socket | null>(null);
  const lastSendTimeRef = useRef<number>(0);
  const SEND_COOLDOWN = 1000; // 1 second cooldown between sends

  const sendMessage = useCallback((message: Record<string, unknown>) => {
    if (socketInstanceRef.current && isConnected) {
      // Validate message before sending
      if (!message || typeof message !== 'object') {
        console.warn('Invalid message format');
        return;
      }
      
      // Rate limiting: prevent rapid duplicate sends
      const now = Date.now();
      if (now - lastSendTimeRef.current < SEND_COOLDOWN) {
        console.warn('Rate limited: Please wait before sending another message');
        return;
      }
      lastSendTimeRef.current = now;
      
      console.log('Sending message via WebSocket:', message);
      socketInstanceRef.current.emit(WEBSOCKET_EVENTS.START_PROCESS, message);
    } else {
      console.warn('Cannot send message: WebSocket not connected');
    }
  }, [isConnected]);

  const reconnect = useCallback(() => {
    if (!isMountedRef.current) return;
    
    setConnectionAttempts(0);
    isManualDisconnect.current = false;
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    if (socketInstanceRef.current) {
      socketInstanceRef.current.removeAllListeners();
      socketInstanceRef.current.disconnect();
      socketInstanceRef.current = null;
    }
    
    setSocket(null);
    setIsConnected(false);
    setConnectionError('Reconnecting...');
    
    // Trigger reconnection by setting a flag
    setIsReconnecting(true);
  }, []);

  useEffect(() => {
    // Prevent duplicate connections in React Strict Mode
    if (!isReconnecting && socketInstanceRef.current) {
      console.log('⚠️ Socket already exists, skipping duplicate connection');
      return;
    }
    
    // Additional check to prevent rapid duplicate connections
    if (socketInstanceRef.current?.connected) {
      console.log('⚠️ Socket already connected, skipping');
      return;
    }
    
    const createSocketConnection = (): Socket | null => {
      if (!isMountedRef.current) return null;
      
      try {
        console.log('%c🔄 Attempting to connect to WebSocket:', socketUrlRef.current);
        
        const socketInstance = io(socketUrlRef.current, {
          transports: ['polling'], // Use polling only for now to ensure stable connection
          timeout: config.websocketTimeout,
          forceNew: true,
          reconnection: false, // We handle this manually
          autoConnect: true,
          upgrade: false, // Disable upgrade to prevent WebSocket issues
          rememberUpgrade: false,
          withCredentials: true,
          // Add explicit Engine.IO version for compatibility
          path: '/socket.io/',
          // Add additional debugging options
          ackTimeout: 10000,
          retries: 3
        });
        
        console.log('%c🔧 Socket.IO instance created:', 'color: gray', socketInstance);

        const attemptReconnection = (): void => {
          if (!isMountedRef.current) return;
          
          setConnectionAttempts(prev => {
            const newAttempts = prev + 1;
            
            if (newAttempts >= maxReconnectAttempts) {
              setConnectionError('Max reconnection attempts reached. Please refresh the page.');
              setIsReconnecting(false);
              return newAttempts;
            }

            if (reconnectTimeoutRef.current || isManualDisconnect.current) {
              return newAttempts;
            }

            const delay = calculateBackoffDelay(
              newAttempts,
              config.reconnectDelay,
              config.maxReconnectDelay
            );
            
            setConnectionError(`Reconnecting... (attempt ${newAttempts}/${maxReconnectAttempts})`);
            
            reconnectTimeoutRef.current = window.setTimeout(() => {
              if (!isMountedRef.current) return;
              reconnectTimeoutRef.current = null;
              setIsReconnecting(true);
            }, delay);
            
            return newAttempts;
          });
        };

        socketInstance.on('connect', () => {
          if (!isMountedRef.current) return;
          
          console.log('%c🟢 Connected to WebSocket server:', socketUrlRef.current);
          console.log('%c🔗 Socket ID:', socketInstance.id);
          console.log('%c🔗 Transport:', socketInstance.io.engine.transport.name);
          setIsConnected(true);
          setIsReconnecting(false);
          setConnectionError(null);
          setSocket(socketInstance);
          socketInstanceRef.current = socketInstance;
          setConnectionAttempts(0);
          isManualDisconnect.current = false;
          
          if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
            reconnectTimeoutRef.current = null;
          }
        });

        // Add listeners for all Socket.IO events to debug "info not coming" issue
        socketInstance.onAny((eventName, ...args) => {
          console.log('%c📨 Received event:', eventName, args);
        });

        // Add specific listeners for common events
        socketInstance.on('message', (data) => {
          console.log('%c💬 Received message:', data);
        });

        socketInstance.on('data', (data) => {
          console.log('%c📊 Received data:', data);
        });

        socketInstance.on('server_info', (data) => {
          console.log('%c📋 Received server info:', data);
        });

        socketInstance.on('process_step', (data) => {
          console.log('%c� Process step:', 'color: gray', data);
        });

        socketInstance.on('final_response', (data) => {
          console.log('%c✅ Final response:', data);
        });

        socketInstance.on('error', (error) => {
          console.error('%c❌ Socket error:', 'color: red', error);
        });

        socketInstance.on('disconnect', (reason) => {
          if (!isMountedRef.current) return;
          
          console.log('%c🔴 Disconnected from WebSocket server:', 'color: red', reason);
          setIsConnected(false);
          setSocket(null);
          socketInstanceRef.current = null;
          
          if (reason === 'io server disconnect') {
            setConnectionError('Server disconnected the connection');
            isManualDisconnect.current = true;
            setIsReconnecting(false);
          } else if (reason === 'io client disconnect') {
            setConnectionError('Client disconnected');
            isManualDisconnect.current = true;
            setIsReconnecting(false);
          } else {
            // Attempt automatic reconnection for other reasons
            setConnectionError('Connection lost, attempting to reconnect...');
            attemptReconnection();
          }
        });

        socketInstance.on('connect_error', (error) => {
          if (!isMountedRef.current) return;
          
          console.error('%c🔴 WebSocket connection error:', 'color: red', error);
          console.error('%c🔍 Error details:', 'color: gray', JSON.stringify(error, Object.getOwnPropertyNames(error)));
          
          // Cast error to unknown then to object to access Socket.IO specific properties
          const socketError = error as unknown as { type?: string; description?: string; context?: string };
          console.error('%c🔍 Error type:', 'color: gray', socketError.type);
          console.error('%c🔍 Error description:', 'color: gray', socketError.description);
          console.error('%c🔍 Error context:', 'color: gray', socketError.context);
          console.error('%c🔍 Error message:', 'color: red', error.message);
          
          setIsConnected(false);
          setSocket(null);
          socketInstanceRef.current = null;
          setConnectionError(`Connection failed: ${error.message || socketError.description || 'Unknown error'}`);
          attemptReconnection();
        });

        return socketInstance;
      } catch (error) {
        console.error('Failed to create WebSocket connection:', error);
        setConnectionError('Failed to create connection');
        setIsReconnecting(false);
        return null;
      }
    };

    isMountedRef.current = true;
    const socketInstance = createSocketConnection();
    setIsReconnecting(false);

    return () => {
      if (socketInstance) {
        socketInstance.removeAllListeners();
        socketInstance.disconnect();
      }
    };
  }, [isReconnecting, maxReconnectAttempts]);

  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
      
      if (socketInstanceRef.current) {
        socketInstanceRef.current.removeAllListeners();
        socketInstanceRef.current.disconnect();
        socketInstanceRef.current = null;
      }
      
      setSocket(null);
      setIsConnected(false);
    };
  }, []);

  return { 
    socket, 
    isConnected, 
    connectionError, 
    sendMessage, 
    reconnect, 
    isReconnecting, 
    connectionAttempts 
  };
}
