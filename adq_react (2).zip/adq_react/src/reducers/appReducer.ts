import type { Message, Conversation, ChatState, LineageNode } from '../types';

export interface AppState {
  conversations: Conversation[];
  activeConversationId: string | null;
  chatState: ChatState;
  ui: {
    sidebarOpen: boolean;
    sidebarHovered: boolean;
    darkMode: boolean;
    isConnected: boolean;
    isReconnecting: boolean;
    connectionAttempts: number;
  };
  error: {
    hasError: boolean;
    message: string | null;
    lastErrorTimestamp: number | null;
  };
  performance: {
    lastMessageTimestamp: number | null;
    messageCount: number;
  };
}

export type AppAction =
  | { type: 'SET_CONVERSATIONS'; payload: Conversation[] }
  | { type: 'LOAD_CONVERSATIONS'; payload: Conversation[] }
  | { type: 'ADD_CONVERSATION'; payload: Conversation }
  | { type: 'UPDATE_CONVERSATION'; payload: { id: string; updates: Partial<Conversation> } }
  | { type: 'DELETE_CONVERSATION'; payload: string }
  | { type: 'SET_ACTIVE_CONVERSATION'; payload: string | null }
  | { type: 'ADD_MESSAGE'; payload: Message }
  | { type: 'UPDATE_MESSAGE'; payload: { id: string; updates: Partial<Message> } }
  | { type: 'DELETE_MESSAGE'; payload: string }
  | { type: 'SET_MESSAGES'; payload: Message[] }
  | { type: 'CLEAR_MESSAGES' }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_CURRENT_STEP'; payload: number | null }
  | { type: 'SET_LINEAGE_TREE'; payload: LineageNode | null }
  | { type: 'SET_FEEDBACK_OPTIONS'; payload: string[] }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'SET_SIDEBAR_OPEN'; payload: boolean }
  | { type: 'SET_SIDEBAR_HOVER'; payload: boolean }
  | { type: 'TOGGLE_DARK_MODE' }
  | { type: 'SET_DARK_MODE'; payload: boolean }
  | { type: 'SET_CONNECTION_STATUS'; payload: boolean }
  | { type: 'SET_RECONNECTING'; payload: boolean }
  | { type: 'INCREMENT_CONNECTION_ATTEMPTS' }
  | { type: 'RESET_CONNECTION_ATTEMPTS' }
  | { type: 'SET_ERROR'; payload: { message: string } }
  | { type: 'CLEAR_ERROR' }
  | { type: 'RESET_CHAT_STATE' }
  | { type: 'RESET_ALL_STATE' };

export const initialState: AppState = {
  conversations: [],
  activeConversationId: null,
  chatState: {
    messages: [],
    isLoading: false,
    currentStep: null,
    lineageTree: null,
    feedbackOptions: []
  },
  ui: {
    sidebarOpen: false,
    sidebarHovered: false,
    darkMode: (() => {
      if (typeof window !== 'undefined') {
        const saved = localStorage.getItem('darkMode');
        if (saved !== null) {
          return JSON.parse(saved);
        }
        return window.matchMedia('(prefers-color-scheme: dark)').matches;
      }
      return false;
    })(),
    isConnected: false,
    isReconnecting: false,
    connectionAttempts: 0,
  },
  error: {
    hasError: false,
    message: null,
    lastErrorTimestamp: null,
  },
  performance: {
    lastMessageTimestamp: null,
    messageCount: 0,
  }
};

export function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_CONVERSATIONS':
      return { ...state, conversations: action.payload };
    
    case 'LOAD_CONVERSATIONS':
      // Only load if we don't have conversations yet to avoid overwriting new ones
      return { 
        ...state, 
        conversations: state.conversations.length === 0 ? action.payload : state.conversations 
      };
    
    case 'ADD_CONVERSATION': {
      const newConversations = [action.payload, ...state.conversations];
      // Limit to 50 conversations for performance
      const limitedConversations = newConversations.slice(0, 50);
      
      return { 
        ...state, 
        conversations: limitedConversations,
        error: { ...state.error, hasError: false }
      };
    }
    
    case 'UPDATE_CONVERSATION':
      return {
        ...state,
        conversations: state.conversations.map(conv =>
          conv.id === action.payload.id
            ? { ...conv, ...action.payload.updates }
            : conv
        )
      };

    case 'DELETE_CONVERSATION':
      return {
        ...state,
        conversations: state.conversations.filter(conv => conv.id !== action.payload),
        activeConversationId: state.activeConversationId === action.payload 
          ? (state.conversations.length > 1 ? state.conversations.find(c => c.id !== action.payload)?.id || null : null)
          : state.activeConversationId
      };
    
    case 'SET_ACTIVE_CONVERSATION':
      return { 
        ...state, 
        activeConversationId: action.payload,
        error: { ...state.error, hasError: false }
      };
    
    case 'ADD_MESSAGE': {
      const newMessage = action.payload;
      const timestamp = Date.now();
      const updatedMessages = [...state.chatState.messages, newMessage];
      
      // Limit messages to 1000 for performance
      const limitedMessages = updatedMessages.slice(-1000);
      
      // Update the active conversation's messages
      const updatedConversations = state.activeConversationId
        ? state.conversations.map(conv =>
            conv.id === state.activeConversationId
              ? { 
                  ...conv, 
                  messages: limitedMessages,
                  lastMessage: (newMessage.content?.slice(0, 100) || '') + 
                    (newMessage.content && newMessage.content.length > 100 ? '...' : ''),
                  timestamp: new Date()
                }
              : conv
          )
        : state.conversations;
      
      return {
        ...state,
        conversations: updatedConversations,
        chatState: {
          ...state.chatState,
          messages: limitedMessages
        },
        performance: {
          lastMessageTimestamp: timestamp,
          messageCount: state.performance.messageCount + 1
        },
        error: { ...state.error, hasError: false }
      };
    }

    case 'UPDATE_MESSAGE':
      return {
        ...state,
        chatState: {
          ...state.chatState,
          messages: state.chatState.messages.map(msg =>
            msg.id === action.payload.id
              ? { ...msg, ...action.payload.updates }
              : msg
          )
        }
      };

    case 'DELETE_MESSAGE':
      return {
        ...state,
        chatState: {
          ...state.chatState,
          messages: state.chatState.messages.filter(msg => msg.id !== action.payload)
        }
      };
    
    case 'SET_MESSAGES': {
      return {
        ...state,
        chatState: { ...state.chatState, messages: action.payload }
      };
    }

    case 'CLEAR_MESSAGES':
      return {
        ...state,
        chatState: { ...state.chatState, messages: [] }
      };
    
    case 'SET_LOADING':
      return {
        ...state,
        chatState: { ...state.chatState, isLoading: action.payload }
      };
    
    case 'SET_CURRENT_STEP':
      return {
        ...state,
        chatState: { ...state.chatState, currentStep: action.payload }
      };
    
    case 'SET_LINEAGE_TREE':
      return {
        ...state,
        chatState: { ...state.chatState, lineageTree: action.payload }
      };
    
    case 'SET_FEEDBACK_OPTIONS':
      return {
        ...state,
        chatState: { ...state.chatState, feedbackOptions: action.payload }
      };
    
    case 'TOGGLE_SIDEBAR':
      return {
        ...state,
        ui: { ...state.ui, sidebarOpen: !state.ui.sidebarOpen }
      };

    case 'SET_SIDEBAR_OPEN':
      return {
        ...state,
        ui: { ...state.ui, sidebarOpen: action.payload }
      };
    
    case 'SET_SIDEBAR_HOVER':
      return {
        ...state,
        ui: { ...state.ui, sidebarHovered: action.payload }
      };
    
    case 'TOGGLE_DARK_MODE': {
      const newDarkMode = !state.ui.darkMode;
      // Save to localStorage
      if (typeof window !== 'undefined') {
        localStorage.setItem('darkMode', JSON.stringify(newDarkMode));
      }
      return {
        ...state,
        ui: { ...state.ui, darkMode: newDarkMode }
      };
    }

    case 'SET_DARK_MODE': {
      // Save to localStorage
      if (typeof window !== 'undefined') {
        localStorage.setItem('darkMode', JSON.stringify(action.payload));
      }
      return {
        ...state,
        ui: { ...state.ui, darkMode: action.payload }
      };
    }
    
    case 'SET_CONNECTION_STATUS':
      return {
        ...state,
        ui: { 
          ...state.ui, 
          isConnected: action.payload,
          isReconnecting: false
        },
        error: action.payload ? { ...state.error, hasError: false } : state.error
      };

    case 'SET_RECONNECTING':
      return {
        ...state,
        ui: { ...state.ui, isReconnecting: action.payload }
      };

    case 'INCREMENT_CONNECTION_ATTEMPTS':
      return {
        ...state,
        ui: { ...state.ui, connectionAttempts: state.ui.connectionAttempts + 1 }
      };

    case 'RESET_CONNECTION_ATTEMPTS':
      return {
        ...state,
        ui: { ...state.ui, connectionAttempts: 0 }
      };

    case 'SET_ERROR':
      return {
        ...state,
        error: {
          hasError: true,
          message: action.payload.message,
          lastErrorTimestamp: Date.now()
        }
      };

    case 'CLEAR_ERROR':
      return {
        ...state,
        error: {
          hasError: false,
          message: null,
          lastErrorTimestamp: null
        }
      };
    
    case 'RESET_CHAT_STATE':
      return {
        ...state,
        chatState: {
          messages: [],
          isLoading: false,
          currentStep: null,
          lineageTree: null,
          feedbackOptions: []
        },
        error: { ...state.error, hasError: false }
      };

    case 'RESET_ALL_STATE':
      return {
        ...initialState,
        ui: {
          ...initialState.ui,
          darkMode: state.ui.darkMode // Preserve theme preference
        }
      };
    default:
      return state;
  }
}
