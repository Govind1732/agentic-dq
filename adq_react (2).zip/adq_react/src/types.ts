export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  isJson?: boolean;
  type?: 'bot_introduction' | 'acknowledgment' | 'step' | 'message' | 'root_cause_summary' | 'feedback_and_extensions' | 'user_input' | 'error';
  step?: number;
  emoji?: string;
  title?: string;
  sample_input?: {
    table_name?: string;
    column_name?: string;
    db_type?: string;
    failed_rule?: string;
    threshold_of_z_score?: number;
    expected_SD?: number;
    expected_value?: number;
    actual_value?: number;
    start_date?: string;
    end_date?: string;
    // Legacy support
    failed_table?: string;
    failed_column?: string;
    validation_query?: string;
    expected_std_dev?: number;
    sd_threshold?: number;
    execution_date?: string;
  };
  root_cause?: {
    summary: string;
    mismatch_count?: number;
    match_count?: number;
  };
  feedback_options?: string[];
  extension_questions?: string[];
}

export interface LineageNode {
  id: string;
  name: string;
  type: string;
  children?: LineageNode[];
  metadata?: Record<string, unknown>;
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  currentStep?: number | null;
  lineageTree?: LineageNode | null;
  feedbackOptions?: string[];
}

export interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  messages: Message[];
}

export interface WebSocketMessage {
  type: string;
  content?: string;
  message?: string;
  step?: number;
  emoji?: string;
  title?: string;
  root_cause?: {
    summary?: string;
    mismatch_count?: number;
    match_count?: number;
  };
  feedback_options?: string[];
  extension_questions?: string[];
}

// Type guards for runtime validation
export function isValidWebSocketMessage(data: unknown): data is WebSocketMessage {
  return (
    typeof data === 'object' &&
    data !== null &&
    'type' in data &&
    typeof (data as { type: unknown }).type === 'string'
  );
}

export function isValidMessage(data: unknown): data is Partial<Message> {
  return (
    typeof data === 'object' &&
    data !== null &&
    (!('id' in data) || typeof (data as { id: unknown }).id === 'string') &&
    (!('content' in data) || typeof (data as { content: unknown }).content === 'string') &&
    (!('role' in data) || ['user', 'assistant'].includes((data as { role: unknown }).role as string))
  );
}

// Constants for message types
export const MESSAGE_TYPES = {
  BOT_INTRODUCTION: 'bot_introduction',
  ACKNOWLEDGMENT: 'acknowledgment', 
  STEP: 'step',
  MESSAGE: 'message',
  ROOT_CAUSE_SUMMARY: 'root_cause_summary',
  FEEDBACK_AND_EXTENSIONS: 'feedback_and_extensions',
  USER_INPUT: 'user_input',
  ERROR: 'error'
} as const;

export const WEBSOCKET_EVENTS = {
  PROCESS_STEP: 'process_step',
  FINAL_RESPONSE: 'final_response',
  ACKNOWLEDGMENT: 'acknowledgment',
  ERROR: 'error',
  START_PROCESS: 'start_process'
} as const;
