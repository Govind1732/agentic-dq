/**
 * Utility functions for enhanced robustness and type safety
 */

import type { Message, WebSocketMessage } from '../types';

/**
 * Safe JSON parsing with error handling
 */
export function safeJsonParse<T = unknown>(jsonString: string): T | null {
  try {
    return JSON.parse(jsonString) as T;
  } catch (error) {
    console.warn('Failed to parse JSON:', error);
    return null;
  }
}

/**
 * Safe JSON stringification
 */
export function safeJsonStringify(obj: unknown, space?: number): string {
  try {
    return JSON.stringify(obj, null, space);
  } catch (error) {
    console.warn('Failed to stringify object:', error);
    return String(obj);
  }
}

/**
 * Debounce function to limit rapid function calls
 */
export function debounce<T extends (...args: unknown[]) => void>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: number | undefined;

  return (...args: Parameters<T>) => {
    if (timeoutId !== undefined) {
      clearTimeout(timeoutId);
    }
    timeoutId = window.setTimeout(() => func(...args), delay);
  };
}

/**
 * Throttle function to limit function execution frequency
 */
export function throttle<T extends (...args: unknown[]) => void>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;

  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

/**
 * Generate unique ID
 */
export function generateId(): string {
  return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Validate message content for basic safety
 */
export function sanitizeMessageContent(content: string): string {
  if (typeof content !== 'string') {
    return String(content);
  }
  
  // Basic sanitization - remove potentially harmful content
  return content
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
    .trim();
}

/**
 * Create a safe message object with validation
 */
export function createSafeMessage(
  content: string,
  role: 'user' | 'assistant',
  type?: Message['type'],
  additionalProps?: Partial<Message>
): Message {
  return {
    id: generateId(),
    content: sanitizeMessageContent(content),
    role,
    timestamp: new Date(),
    type: type || 'message',
    ...additionalProps
  };
}

/**
 * Validate WebSocket message structure
 */
export function validateWebSocketMessage(data: unknown): WebSocketMessage | null {
  if (!data || typeof data !== 'object') {
    return null;
  }

  const msg = data as Record<string, unknown>;
  
  if (typeof msg.type !== 'string') {
    return null;
  }

  return {
    type: msg.type,
    content: typeof msg.content === 'string' ? msg.content : undefined,
    message: typeof msg.message === 'string' ? msg.message : undefined,
    step: typeof msg.step === 'number' ? msg.step : undefined,
    emoji: typeof msg.emoji === 'string' ? msg.emoji : undefined,
    title: typeof msg.title === 'string' ? msg.title : undefined,
    root_cause: msg.root_cause && typeof msg.root_cause === 'object' ? 
      msg.root_cause as WebSocketMessage['root_cause'] : undefined,
    feedback_options: Array.isArray(msg.feedback_options) ? 
      msg.feedback_options.filter(item => typeof item === 'string') : undefined,
    extension_questions: Array.isArray(msg.extension_questions) ? 
      msg.extension_questions.filter(item => typeof item === 'string') : undefined
  };
}

/**
 * Exponential backoff calculation
 */
export function calculateBackoffDelay(attempt: number, baseDelay: number, maxDelay: number): number {
  const delay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
  // Add jitter to prevent thundering herd
  return delay + Math.random() * 1000;
}

/**
 * Format timestamp for display
 */
export function formatTimestamp(date: Date): string {
  try {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(date);
  } catch {
    return date.toLocaleTimeString();
  }
}

/**
 * Local storage utilities with error handling
 */
export const storage = {
  set<T>(key: string, value: T): boolean {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.warn(`Failed to save to localStorage: ${key}`, error);
      return false;
    }
  },

  get<T>(key: string): T | null {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.warn(`Failed to read from localStorage: ${key}`, error);
      return null;
    }
  },

  remove(key: string): boolean {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.warn(`Failed to remove from localStorage: ${key}`, error);
      return false;
    }
  }
};
