import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    // Enable modern builds for better performance
    target: 'esnext',
    minify: 'esbuild',
    // Split chunks for better caching
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          ui: ['lucide-react', 'clsx'],
          markdown: ['react-markdown', 'remark-gfm'],
          socket: ['socket.io-client'],
        },
      },
    },
    // Reduce bundle size
    sourcemap: false,
    cssCodeSplit: true,
  },
  server: {
    port: 3000,
    host: true,
    open: true,
  },
  preview: {
    port: 3000,
    host: true,
  },
  // Optimize dependencies
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'react-markdown',
      'remark-gfm',
      'lucide-react',
      'socket.io-client',
      'clsx',
    ],
  },
  // Define environment variables
  define: {
    __APP_VERSION__: JSON.stringify('1.0.0'),
  },
})
