import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import InputBar from './components/InputBar';
import type { ChatState, Message, Conversation } from './types.ts';
import { useWebSocket } from './hooks/useWebSocket';
import ThemeSwitcher from './components/ThemeSwitcher.tsx';
import Header from './components/Header.tsx';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarHovered, setSidebarHovered] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<
    string | null
  >(null);
  const introMessage: Message = {
    id: 'intro',
    content: `Hi John Doe, great to see you\nI can quickly find the root cause of your data issues using AI-driven analysis.\nDescribe your issue, e.g.:\n“I see low volumes of netadds on dla_sum_fact\nShare an issue details similar to this:\n\n{\n   "table_name" : <Fully qualified table name>,\n   "column_name" : <Column name>,\n   "db_type" : <GCP/Teradata>,\n   "failed_rule": <SQL that contains the validation>,\n   "threshold of Z-Score" :\n   "expected_SD" :\n   "expected_value" :\n   "actual_value" :\n   "Start Date":\n   "End Date":\n}`,
    role: 'assistant',
    timestamp: new Date(),
  };
  const [chatState, setChatState] = useState<ChatState>({
    messages: [introMessage],
    isLoading: false,
  });
  const { socket, isConnected } = useWebSocket('http://localhost:3001');
  // Send user input to backend via WebSocket and update chatState with backend response
  const handleSendMessage = (content: string) => {
    let parsedContent: string | object = content;
    let isJson = false;
    try {
      const json = JSON.parse(content);
      parsedContent = json;
      isJson = true;
    } catch {
      // Not valid JSON, treat as plain text
    }

    // If this is the first message in a new conversation, create a new conversation
    if (!currentConversationId && chatState.messages.length === 0) {
      const titleContent =
        typeof parsedContent === 'string'
          ? parsedContent
          : JSON.stringify(parsedContent);
      const newConversation: Conversation = {
        id: Date.now().toString(),
        title:
          titleContent.slice(0, 50) + (titleContent.length > 50 ? '...' : ''),
        lastMessage:
          typeof parsedContent === 'string' ? parsedContent : '[JSON]',
        timestamp: new Date(),
        messages: [],
      };
      setConversations((prev) => [newConversation, ...prev]);
      setCurrentConversationId(newConversation.id);
    }

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content:
        typeof parsedContent === 'string'
          ? parsedContent
          : JSON.stringify(parsedContent, null, 2),
      role: 'user',
      timestamp: new Date(),
      isJson: isJson,
    };

    setChatState((prev) => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isLoading: true,
    }));

    // Send message to backend via WebSocket
    if (isConnected && socket) {
      socket.emit('start_process', { message: parsedContent });
    } else {
      // Add error message if not connected
      const errorMessage: Message = {
        id: Date.now().toString() + '_error',
        content: 'Not connected to backend. Please check your connection.',
        role: 'assistant',
        timestamp: new Date(),
      };
      setChatState((prev) => ({
        ...prev,
        messages: [...prev.messages, errorMessage],
        isLoading: false,
      }));
    }
  };
  // Listen for backend responses and update chatState
  useEffect(() => {
    if (!socket) return;

    const handleFinalResponse = (data: any) => {
      const botMessage: Message = {
        id: Date.now().toString() + '_bot',
        content:
          typeof data.content === 'string'
            ? data.content
            : JSON.stringify(data.content, null, 2),
        role: 'assistant',
        timestamp: new Date(),
        isJson: typeof data.content !== 'string',
      };
      setChatState((prev) => ({
        ...prev,
        messages: [...prev.messages, botMessage],
        isLoading: false,
      }));

      // Update conversation
      if (currentConversationId) {
        setConversations((prev) =>
          prev.map((conv) =>
            conv.id === currentConversationId
              ? {
                  ...conv,
                  lastMessage:
                    botMessage.content.slice(0, 100) +
                    (botMessage.content.length > 100 ? '...' : ''),
                  timestamp: new Date(),
                  messages: [...chatState.messages, botMessage],
                }
              : conv
          )
        );
      }
    };

    socket.on('final_response', handleFinalResponse);

    // Optionally handle process_step, error, etc.
    const handleProcessStep = (data: any) => {
      // You can show intermediate steps if desired
      // Example: setChatState with a status message
    };
    socket.on('process_step', handleProcessStep);

    const handleError = (data: any) => {
      const errorMessage: Message = {
        id: Date.now().toString() + '_error',
        content: data.message || 'Backend error occurred.',
        role: 'assistant',
        timestamp: new Date(),
      };
      setChatState((prev) => ({
        ...prev,
        messages: [...prev.messages, errorMessage],
        isLoading: false,
      }));
    };
    socket.on('error', handleError);

    return () => {
      socket.off('final_response', handleFinalResponse);
      socket.off('process_step', handleProcessStep);
      socket.off('error', handleError);
    };
  }, [socket, currentConversationId, chatState.messages]);

  const handleNewChat = () => {
    setChatState({
      messages: [],
      isLoading: false,
    });
    setCurrentConversationId(null);
    setSidebarOpen(false);
  };

  const handleSelectConversation = (conversationId: string) => {
    const conversation = conversations.find((c) => c.id === conversationId);
    if (conversation) {
      setChatState({
        messages: conversation.messages,
        isLoading: false,
      });
      setCurrentConversationId(conversationId);
      setSidebarOpen(false);
    }
  };

  const handleSidebarHover = (isHovering: boolean) => {
    setSidebarHovered(isHovering);
  };

  // Determine if sidebar should be shown (open on mobile, or hovered on desktop)
  const shouldShowSidebar = sidebarOpen || sidebarHovered;

  return (
    <div className="flex h-screen">
      {/* <ThemeSwitcher /> */}
      <Sidebar
        conversations={conversations}
        currentConversationId={currentConversationId}
        onNewChat={handleNewChat}
        onSelectConversation={handleSelectConversation}
        isOpen={shouldShowSidebar}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        onHover={handleSidebarHover}
      />
      <div className="flex flex-1 flex-col">
        {/* <Header /> */}
        <ChatWindow
          messages={chatState.messages}
          isLoading={chatState.isLoading}
        />
        <InputBar
          onSendMessage={handleSendMessage}
          isLoading={chatState.isLoading}
        />
      </div>
    </div>
  );
}

export default App;
