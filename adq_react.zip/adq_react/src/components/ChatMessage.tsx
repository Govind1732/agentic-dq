import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import type { Message } from '../types';
import { Bot, User } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div
      className={`mb-6 flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      {!isUser && (
        <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gray-700">
          <Bot className="h-4 w-4 text-gray-300" />
        </div>
      )}

      <div
        className={`max-w-[80%] rounded-2xl px-4 py-3 md:max-w-[70%] ${
          isUser
            ? 'ml-auto bg-blue-600 text-white'
            : 'bg-gray-800 text-gray-100'
        }`}
      >
        {isUser ? (
          <p className="text-sm leading-relaxed">{message.content}</p>
        ) : (
          <div className="prose prose-invert prose-sm prose-pre:bg-gray-900 prose-pre:border prose-pre:border-gray-700 prose-code:text-blue-400 prose-strong:text-white prose-ul:text-gray-100 prose-ol:text-gray-100 max-w-none text-sm leading-relaxed">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                p: ({ children }) => (
                  <p className="mb-2 last:mb-0">{children}</p>
                ),
                ul: ({ children }) => (
                  <ul className="mb-2 space-y-1 last:mb-0">{children}</ul>
                ),
                ol: ({ children }) => (
                  <ol className="mb-2 space-y-1 last:mb-0">{children}</ol>
                ),
                li: ({ children }) => (
                  <li className="text-gray-100">{children}</li>
                ),
                code: ({ node, children }) =>
                  node && (node as any).inline ? (
                    <code className="rounded bg-gray-900 px-1.5 py-0.5 font-mono text-xs text-blue-400">
                      {children}
                    </code>
                  ) : (
                    <code className="text-gray-100">{children}</code>
                  ),
                pre: ({ children }) => (
                  <pre className="my-3 overflow-x-auto rounded-lg border border-gray-700 bg-gray-900 p-3">
                    {children}
                  </pre>
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
        )}
      </div>

      {isUser && (
        <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-blue-600">
          <User className="h-4 w-4 text-white" />
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
