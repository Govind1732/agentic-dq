import React, { useEffect, useRef } from 'react';
import ChatMessage from './ChatMessage';
import type { Message } from '../types';

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'end',
    });
  };
  console.log('ChatWindow rendered', messages);
  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div
      ref={chatContainerRef}
      className="flex-1 overflow-y-auto pt-16 lg:ml-8 lg:pt-4 dark:bg-black"
      style={{
        scrollbarWidth: 'thin',
        scrollbarColor: '#374151 transparent',
      }}
    >
      <div className="mx-auto max-w-6xl bg-white px-4 lg:px-6 dark:bg-black">
        {/* {messages.length === 0 && (
          <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
            <div className="mb-8">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600">
                <span className="text-2xl font-bold text-white">G</span>
              </div>
              <h1 className="mb-2 text-2xl font-medium text-gray-100 md:text-3xl">
                Hello, I'm Gemini
              </h1>
              <p className="mx-auto max-w-md text-gray-400">
                I'm here to help you with questions, creative projects, and
                learning new things. What would you like to explore today?
              </p>
            </div>
            <div className="grid w-full max-w-2xl grid-cols-1 gap-3 md:grid-cols-2">
              <div className="cursor-pointer rounded-xl border border-gray-700 bg-gray-900 p-4 transition-colors hover:bg-gray-800">
                <p className="text-sm text-gray-300">
                  ✨ Help me write a creative story
                </p>
              </div>
              <div className="cursor-pointer rounded-xl border border-gray-700 bg-gray-900 p-4 transition-colors hover:bg-gray-800">
                <p className="text-sm text-gray-300">
                  💡 Explain a complex concept
                </p>
              </div>
              <div className="cursor-pointer rounded-xl border border-gray-700 bg-gray-900 p-4 transition-colors hover:bg-gray-800">
                <p className="text-sm text-gray-300">
                  🔧 Help with coding problems
                </p>
              </div>
              <div className="cursor-pointer rounded-xl border border-gray-700 bg-gray-900 p-4 transition-colors hover:bg-gray-800">
                <p className="text-sm text-gray-300">
                  📚 Research and summarize
                </p>
              </div>
            </div>
          </div>
        )} */}

        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}

        {isLoading && (
          <div className="mb-6 flex gap-3">
            <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gray-700">
              <div className="h-4 w-4 animate-pulse rounded-full bg-gray-300"></div>
            </div>
            <div className="rounded-2xl bg-gray-800 px-4 py-3 text-gray-100">
              <div className="flex gap-1">
                <div className="h-2 w-2 animate-bounce rounded-full bg-gray-400"></div>
                <div
                  className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                  style={{ animationDelay: '0.1s' }}
                ></div>
                <div
                  className="h-2 w-2 animate-bounce rounded-full bg-gray-400"
                  style={{ animationDelay: '0.2s' }}
                ></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default ChatWindow;
