const Header = () => {
  return (
    <>
      {/* <h1 className="text-md border border-white pl-10 font-bold dark:bg-black dark:text-white">
        RCA Agent
      </h1> */}
      <header className="w-full border dark:bg-black dark:text-white">
        RCA Agent
      </header>
    </>
  );
};

export default Header;
