import React, { useState, useRef } from 'react';
import type { KeyboardEvent } from 'react';
import { Send, Loader2, Plus, Mic, X } from 'lucide-react';

interface SelectedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  file: File;
}

interface InputBarProps {
  onSendMessage: (message: string, files?: File[]) => void;
  isLoading: boolean;
}

const InputBar: React.FC<InputBarProps> = ({ onSendMessage, isLoading }) => {
  const [message, setMessage] = useState('');
  const [selectedFiles, setSelectedFiles] = useState<SelectedFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isRecording, setIsRecording] = useState(false);
  // Use 'any' type for recognitionRef to avoid TypeScript errors
  const recognitionRef = useRef<any>(null);

  // Speech-to-text handler
  const handleMicClick = () => {
    if (
      !('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)
    ) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    console.log('recognition', recognition);
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setMessage((prev) => (prev ? prev + ' ' + transcript : transcript));
      // setMessage(transcript);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleSend = () => {
    if ((message.trim() || selectedFiles.length > 0) && !isLoading) {
      const files = selectedFiles.map((sf) => sf.file);
      onSendMessage(message.trim(), files);
      setMessage('');
      setSelectedFiles([]);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      const file = files[0];
      const newFile: SelectedFile = {
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: file.type,
        size: file.size,
        file,
      };
      setSelectedFiles([newFile]); // Only allow one file
    }

    // Reset the input so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeFile = (fileId: string) => {
    setSelectedFiles((prev) => prev.filter((f) => f.id !== fileId));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return '🖼️';
    if (type.startsWith('video/')) return '🎥';
    if (type.startsWith('audio/')) return '🎵';
    if (type.includes('json')) return '🗄️';
    if (type.includes('pdf')) return '📄';
    if (type.includes('text')) return '📝';
    return '📎';
  };

  return (
    <div className="border-t border-gray-800 p-2 lg:left-8 dark:bg-black">
      <div className="mx-auto max-w-4xl">
        <div className="relative rounded-2xl border border-gray-700 bg-gray-900 transition-colors focus-within:border-blue-600">
          {/* Selected Files Display */}
          {selectedFiles.length > 0 && (
            <div className="border-b border-gray-700 px-4 pt-3 pb-2">
              <div className="flex flex-wrap gap-2">
                {selectedFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center gap-2 rounded-lg bg-gray-800 px-3 py-2 text-sm"
                  >
                    <span className="text-lg">{getFileIcon(file.type)}</span>
                    <div className="flex min-w-0 flex-col">
                      <span className="max-w-32 truncate text-gray-200">
                        {file.name}
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatFileSize(file.size)}
                      </span>
                    </div>
                    <button
                      onClick={() => removeFile(file.id)}
                      className="text-gray-400 transition-colors hover:text-gray-200"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Input Area */}
          <div className="flex items-end gap-2 p-2">
            {/* File Upload Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading}
              className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-transparent transition-colors hover:bg-gray-800 disabled:opacity-50"
            >
              <Plus className="h-5 w-5 text-gray-400" />
            </button>

            {/* Text Input */}
            <div className="relative flex-1">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="What do you want to build?"
                disabled={isLoading}
                className="max-h-32 min-h-[32px] w-full resize-none border-none bg-transparent py-2 text-sm leading-relaxed text-gray-100 placeholder-gray-400 outline-none disabled:opacity-50"
                rows={1}
                style={{
                  height: 'auto',
                  minHeight: '32px',
                }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height =
                    Math.min(target.scrollHeight, 128) + 'px';
                }}
              />
            </div>

            {/* Mic Button */}
            <button
              type="button"
              disabled={isLoading}
              onClick={handleMicClick}
              className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-transparent transition-colors hover:bg-gray-800 disabled:opacity-50 ${isRecording ? 'bg-blue-900' : ''}`}
              aria-label={isRecording ? 'Stop recording' : 'Start recording'}
            >
              <Mic
                className={`h-5 w-5 ${isRecording ? 'animate-pulse text-blue-400' : 'text-gray-400'}`}
              />
            </button>

            {/* Send Button */}
            <button
              onClick={handleSend}
              disabled={
                (!message.trim() && selectedFiles.length === 0) || isLoading
              }
              className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-blue-600 transition-colors hover:bg-blue-700 disabled:bg-gray-700 disabled:opacity-50 disabled:hover:bg-gray-700"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin text-white" />
              ) : (
                <Send className="h-4 w-4 text-white" />
              )}
            </button>
          </div>

          {/* Hidden File Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,text/plain,application/json"
            onChange={handleFileSelect}
            className="hidden"
            multiple={false}
          />
        </div>
      </div>
    </div>
  );
};

export default InputBar;
