import React from 'react';
import { Plus, MessageSquare, Settings, Menu, X } from 'lucide-react';
import type { Conversation } from '../types';

interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onNewChat: () => void;
  onSelectConversation: (conversationId: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  onHover: (isHovering: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  currentConversationId,
  onNewChat,
  onSelectConversation,
  isOpen,
  onToggle,
  onHover,
}) => {
  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) {
      return 'Today';
    } else if (days === 1) {
      return 'Yesterday';
    } else if (days < 7) {
      return `${days} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="bg-opacity-50 fixed inset-0 z-40 lg:hidden dark:bg-black"
          onClick={onToggle}
        />
      )}

      {/* Mobile menu button */}
      <button
        onClick={onToggle}
        className="fixed top-4 left-4 z-50 flex h-10 w-10 items-center justify-center rounded-lg bg-gray-800 transition-colors hover:bg-gray-700 lg:hidden"
      >
        {isOpen ? (
          <X className="h-5 w-5 text-gray-300" />
        ) : (
          <Menu className="h-5 w-5 text-gray-300" />
        )}
      </button>

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 z-[100] h-full w-80 transform border-r border-gray-800 bg-gray-950 transition-all duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full lg:-translate-x-72'} `}
        onMouseEnter={() => onHover(true)}
        onMouseLeave={() => onHover(false)}
      >
        {/* Hover trigger area for desktop */}
        <div
          className="absolute top-0 -right-4 z-10 hidden h-full w-4 lg:block"
          onMouseEnter={() => onHover(true)}
        />

        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="border-b border-gray-800 p-4">
            <h2 className="text-lg font-semibold text-gray-300">RCA Agent</h2>
          </div>
          <div className="border-b border-gray-800 p-4">
            <button
              onClick={onNewChat}
              className="group flex w-full items-center gap-3 rounded-xl bg-gray-900 px-4 py-3 transition-colors hover:bg-gray-800"
            >
              <Plus className="h-5 w-5 text-gray-400 group-hover:text-gray-300" />
              <span className="font-medium text-gray-300">New chat</span>
            </button>
          </div>

          {/* Conversations */}
          <div className="flex-1 overflow-y-auto">
            <div className="p-2">
              {conversations.length === 0 ? (
                <div className="py-8 text-center">
                  <MessageSquare className="mx-auto mb-2 h-8 w-8 text-gray-600" />
                  <p className="text-sm text-gray-500">No conversations yet</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {conversations.map((conversation) => (
                    <button
                      key={conversation.id}
                      onClick={() => onSelectConversation(conversation.id)}
                      className={`group w-full rounded-lg p-3 text-left transition-colors ${
                        currentConversationId === conversation.id
                          ? 'bg-gray-800 text-gray-100'
                          : 'text-gray-300 hover:bg-gray-900'
                      } `}
                    >
                      <div className="flex items-start gap-3">
                        <MessageSquare className="mt-0.5 h-4 w-4 flex-shrink-0 text-gray-500" />
                        <div className="min-w-0 flex-1">
                          <p className="mb-1 truncate text-sm font-medium">
                            {conversation.title}
                          </p>
                          <p className="truncate text-xs text-gray-500">
                            {conversation.lastMessage}
                          </p>
                          <p className="mt-1 text-xs text-gray-600">
                            {formatTime(conversation.timestamp)}
                          </p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="border-t border-gray-800 p-4">
            <button className="group flex w-full items-center gap-3 rounded-xl px-4 py-3 transition-colors hover:bg-gray-900">
              <Settings className="h-5 w-5 text-gray-400 group-hover:text-gray-300" />
              <span className="text-gray-400 group-hover:text-gray-300">
                Settings
              </span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
