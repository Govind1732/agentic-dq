type Theme = 'light' | 'dark' | 'system';

interface ThemeButtonGroupProps {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const themes: Theme[] = ['light', 'dark', 'system'];

export default function ThemeButtonGroup({
  theme,
  setTheme,
}: ThemeButtonGroupProps) {
  return (
    <div className="flex gap-2">
      {themes.map((t) => (
        <button
          key={t}
          className={`rounded border px-3 py-1 ${theme === t ? 'bg-sky-700 text-white' : 'bg-white text-black dark:bg-black dark:text-white'}`}
          onClick={() => setTheme(t)}
        >
          {t.charAt(0).toUpperCase() + t.slice(1)}
        </button>
      ))}
    </div>
  );
}
