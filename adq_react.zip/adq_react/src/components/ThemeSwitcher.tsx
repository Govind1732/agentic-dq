import { useEffect, useState } from 'react';
import ThemeButtonGroup from './ThemeButtonGroup';

const THEME_KEY = 'theme-mode';
const themes = ['light', 'dark', 'system'] as const;
type Theme = (typeof themes)[number];

function getSystemTheme(): 'light' | 'dark' {
  if (window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
  return 'light';
}

function getInitialTheme(): Theme {
  const stored = localStorage.getItem(THEME_KEY) as Theme | null;
  if (stored === 'light' || stored === 'dark') return stored;
  return 'system';
}

function applyTheme(theme: Theme) {
  const root = window.document.documentElement;
  let mode = theme;
  if (theme === 'system') mode = getSystemTheme();
  if (mode === 'dark') {
    root.classList.add('dark');
    root.classList.remove('light');
  } else {
    root.classList.add('light');
    root.classList.remove('dark');
  }
}

export default function ThemeSwitcher() {
  const [theme, setTheme] = useState<Theme>(getInitialTheme());

  useEffect(() => {
    applyTheme(theme);
    localStorage.setItem(THEME_KEY, theme);
    if (theme === 'system') {
      const handler = () => {
        applyTheme('system');
      };
      window
        .matchMedia('(prefers-color-scheme: dark)')
        .addEventListener('change', handler);
      return () => {
        window
          .matchMedia('(prefers-color-scheme: dark)')
          .removeEventListener('change', handler);
      };
    }
  }, [theme]);

  return (
    <div className="flex items-center gap-2 py-2">
      <span className="font-medium">Theme:</span>
      <ThemeButtonGroup theme={theme} setTheme={setTheme} />
    </div>
  );
}
