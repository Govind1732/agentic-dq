import { useState, useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

export const CONNECTION_STATES = {
  DISCONNECTED: 'disconnected',
  CONNECTING: 'connecting',
  CONNECTED: 'connected',
  RECONNECTING: 'reconnecting',
  ERROR: 'error',
} as const;

type CONNECTION_STATES = typeof CONNECTION_STATES[keyof typeof CONNECTION_STATES];

interface UseWebSocketOptions {
  maxReconnectAttempts?: number;
  reconnectDelay?: number;
  socketOptions?: Record<string, any>;
}

export function useWebSocket(
  url: string,
  options: UseWebSocketOptions = {}
): {
  socket: Socket | null;
  connectionState: CONNECTION_STATES;
  isConnected: boolean;
  sendMessage: (event: string, data: any) => boolean;
  reconnect: () => void;
} {
  const [connectionState, setConnectionState] = useState<CONNECTION_STATES>(CONNECTION_STATES.DISCONNECTED);
  const [socket, setSocket] = useState<Socket | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = options.maxReconnectAttempts || 5;
  const reconnectDelay = options.reconnectDelay || 1000;

  useEffect(() => {
    let currentSocket: Socket | null = null;

    const connect = () => {
      if (currentSocket?.connected) return;
      setConnectionState(CONNECTION_STATES.CONNECTING);
      currentSocket = io(url, {
        transports: ['websocket'],
        timeout: 20000,
        ...(options.socketOptions || {}),
      });

      currentSocket.on('connect', () => {
        console.log('WebSocket connected');
        setConnectionState(CONNECTION_STATES.CONNECTED);
        reconnectAttempts.current = 0;
        setSocket(currentSocket);
      });

      currentSocket.on('disconnect', (reason: string) => {
        console.log('WebSocket disconnected:', reason);
        setConnectionState(CONNECTION_STATES.DISCONNECTED);
        if (reason === 'io server disconnect') return;
        // Attempt reconnection
        if (reconnectAttempts.current < maxReconnectAttempts) {
          setConnectionState(CONNECTION_STATES.RECONNECTING);
          reconnectAttempts.current++;
          setTimeout(() => {
            connect();
          }, reconnectDelay * Math.pow(2, reconnectAttempts.current));
        } else {
          setConnectionState(CONNECTION_STATES.ERROR);
        }
      });

      currentSocket.on('connect_error', (error: any) => {
        console.error('WebSocket connection error:', error);
        if (reconnectAttempts.current < maxReconnectAttempts) {
          setConnectionState(CONNECTION_STATES.RECONNECTING);
          reconnectAttempts.current++;
          setTimeout(() => {
            connect();
          }, reconnectDelay * Math.pow(2, reconnectAttempts.current));
        } else {
          setConnectionState(CONNECTION_STATES.ERROR);
        }
      });
    };

    connect();
    return () => {
      if (currentSocket) {
        currentSocket.close();
      }
    };
  }, [url, maxReconnectAttempts, reconnectDelay, options.socketOptions]);

  const sendMessage = useCallback((event: string, data: any) => {
    if (socket?.connected) {
      socket.emit(event, data);
      return true;
    }
    return false;
  }, [socket]);

  const reconnect = useCallback(() => {
    if (socket) {
      socket.close();
    }
    reconnectAttempts.current = 0;
    // The useEffect will handle reconnection
  }, [socket]);

  return {
    socket,
    connectionState,
    isConnected: connectionState === CONNECTION_STATES.CONNECTED,
    sendMessage,
    reconnect,
  };
}
