import type { Message } from '../types';

// Mock responses for demonstration
const mockResponses = [
  "Hello! I'm here to help you with any questions you might have. What would you like to know?",
  "That's an interesting question! Let me think about that for a moment...",
  "I understand what you're asking. Here's my thoughts on that:",
  "Great question! Here are a few key points to consider:\n\n• **First point**: This is important because...\n• **Second point**: You should also think about...\n• **Third point**: Don't forget that...",
  "Here's some code that might help:\n\n```javascript\nfunction example() {\n  console.log('Hello, world!');\n  return 'This is a code example';\n}\n```",
  "I appreciate you asking! **Here's what I think**: This is a complex topic that involves several factors. Let me break it down for you.",
];

class ChatService {
  private getRandomResponse(): string {
    return mockResponses[Math.floor(Math.random() * mockResponses.length)];
  }

  async sendMessage(message: string): Promise<Message> {
    // Simulate API delay
    await new Promise((resolve) =>
      setTimeout(resolve, 500 + Math.random() * 1000)
    );

    return {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      content: `You asked: "${message}"\n\n${this.getRandomResponse()}`,
      role: 'assistant',
      timestamp: new Date(),
    };
  }
}

export const chatService = new ChatService();
export default chatService;
