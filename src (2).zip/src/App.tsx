import { useReducer, useEffect, useCallback } from "react";
import Sidebar from "./components/Sidebar";
import { ChatWindow } from "./components/ChatWindow";
import InputBar from "./components/InputBar";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useWebSocket } from "./hooks/useWebSocket";
import { appReducer, initialState } from "./reducers/appReducer";
import type {
  Message,
  ProgressStep,
  AnalysisResult,
  TableData,
  Conversation,
} from "./types";
import { generateId } from "./utils";
import { MESSAGE_TYPES } from "./types";

function App() {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const {
    socket,
    isConnected,
    sendMessage,
    createNewConversation,
    selectConversation,
    requestConversations,
  } = useWebSocket();

  // WebSocket message handlers for RCA functionality
  const handleMessage = (data: unknown) => {
    if (data && typeof data === "object" && "type" in data) {
      const messageData = data as Record<string, unknown>;
      console.log("Received WebSocket message:", messageData);

      if (messageData.type === "acknowledgment") {
        // Handle acknowledgment message
        const ackMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Hello!",
          role: "assistant",
          timestamp: new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: ackMessage });
        dispatch({ type: "SET_LOADING", payload: false });
      } else if (messageData.type === "step_result") {
        // Handle new 3-step workflow results
        const stepMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Step completed...",
          role: "assistant",
          type: MESSAGE_TYPES.STEP,
          timestamp: new Date().toISOString(),
          stepNumber: messageData.step_number as number,
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
      } else if (messageData.type === "process_step") {
        const stepMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Processing step...",
          role: "assistant",
          type: MESSAGE_TYPES.STEP,
          timestamp: new Date().toISOString(),
          stepNumber: messageData.step_number as number,
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
      } else if (messageData.type === "node_response") {
        // Handle real-time node responses
        const nodeMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Node completed...",
          role: "assistant",
          type: MESSAGE_TYPES.NODE_RESPONSE,
          timestamp: new Date().toISOString(),
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: nodeMessage });
      } else if (messageData.type === "final_response") {
        const finalMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Analysis complete.",
          role: "assistant",
          type: MESSAGE_TYPES.FINAL,
          timestamp: new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: finalMessage });
        dispatch({ type: "SET_LOADING", payload: false });
      }
    }
  };

  // RCA-specific message handlers
  const handleRCAMessage = useCallback((data: Record<string, unknown>) => {
    console.log("Received RCA message:", data);
    const rcaMessage: Message = {
      id: generateId(),
      type: (data.type as string) || "bot",
      content: data.content as string,
      role: "assistant",
      timestamp: (data.timestamp as string) || new Date().toISOString(),
    };
    dispatch({ type: "ADD_MESSAGE", payload: rcaMessage });
  }, []);

  const handleRCAProgress = useCallback(
    (data: Record<string, unknown>) => {
      console.log("Received RCA progress:", data);
      const progressStep: ProgressStep = {
        step: data.step as string,
        status: data.status as "started" | "completed" | "failed",
        details: (data.details as Record<string, unknown>) || {},
        timestamp: (data.timestamp as string) || new Date().toISOString(),
      };

      // Check if step already exists
      const existingStep = state.progressSteps.find(
        (step) => step.step === progressStep.step
      );
      if (existingStep) {
        dispatch({ type: "UPDATE_PROGRESS_STEP", payload: progressStep });
      } else {
        dispatch({ type: "ADD_PROGRESS_STEP", payload: progressStep });
      }

      if (data.status === "started") {
        dispatch({ type: "SET_CURRENT_STEP", payload: data.step as string });
      }
    },
    [state.progressSteps]
  );

  const handleAnalysisResult = useCallback((data: Record<string, unknown>) => {
    console.log("Received analysis result:", data);
    const analysisResult: AnalysisResult = {
      id: Date.now(),
      layer: data.layer as string,
      table: data.table as string,
      column: data.column as string,
      sql_query: data.sql_query as string,
      reasoning: data.reasoning as string,
      inference: data.inference as string,
      timestamp: (data.timestamp as string) || new Date().toISOString(),
    };
    dispatch({ type: "ADD_ANALYSIS_RESULT", payload: analysisResult });

    // Generate flow diagram data for lineage traversal steps
    if (data.layer && data.layer !== "L0") {
      const stepNumber = parseInt((data.layer as string).replace("L", ""), 10);
      const flowNode = {
        id: `${data.table}.${data.column}`,
        table: data.table as string,
        column: data.column as string,
        step: stepNumber,
        status: data.inference?.toString().includes("DISCREPANCY")
          ? ("deviation" as const)
          : ("normal" as const),
        value: Math.random() * 1000, // This should come from actual data
        expectedValue: Math.random() * 1000, // This should come from actual data
        deviationPercentage: Math.random() * 20 - 10, // This should come from actual data
      };

      dispatch({ type: "ADD_FLOW_NODE", payload: flowNode });
    }
  }, []);

  const handleTableData = useCallback((data: Record<string, unknown>) => {
    console.log("Received table data:", data);
    const tableData: TableData = {
      id: Date.now(),
      title: data.title as string,
      data: data.data as unknown[],
      timestamp: (data.timestamp as string) || new Date().toISOString(),
    };
    dispatch({ type: "ADD_TABLE_DATA", payload: tableData });
  }, []);

  const handleFinalReport = useCallback((data: Record<string, unknown>) => {
    console.log("Received final report:", data);
    const metadata = data.metadata as Record<string, unknown> | undefined;
    dispatch({ type: "SET_FINAL_REPORT", payload: metadata?.report || data });
    dispatch({ type: "SET_PROCESSING", payload: false });
  }, []);

  const handleError = useCallback((data: Record<string, unknown>) => {
    console.error("Received error:", data);
    const errorMessage: Message = {
      id: generateId(),
      type: MESSAGE_TYPES.ERROR,
      content:
        (data.message as string) ||
        (data.content as string) ||
        "An error occurred",
      role: "assistant",
      timestamp: (data.timestamp as string) || new Date().toISOString(),
    };
    dispatch({ type: "ADD_MESSAGE", payload: errorMessage });
    dispatch({ type: "SET_PROCESSING", payload: false });
  }, []);

  // Conversation handlers
  const handleConversationCreated = useCallback(
    (data: Record<string, unknown>) => {
      console.log("Conversation created:", data);
      if (data.conversation && data.conversations) {
        const conversation = data.conversation as Conversation;
        const conversations = data.conversations as Conversation[];
        dispatch({ type: "SET_CONVERSATIONS", payload: conversations });
        dispatch({
          type: "SET_CURRENT_CONVERSATION",
          payload: conversation.id,
        });
      }
    },
    []
  );

  const handleConversationSelected = useCallback(
    (data: Record<string, unknown>) => {
      console.log("Conversation selected:", data);
      if (data.conversation) {
        const conversation = data.conversation as Conversation;
        dispatch({
          type: "SET_CURRENT_CONVERSATION",
          payload: conversation.id,
        });
        dispatch({
          type: "UPDATE_CONVERSATION",
          payload: { id: conversation.id, messages: conversation.messages },
        });
      }
    },
    []
  );

  const handleConversationsList = useCallback(
    (data: Record<string, unknown>) => {
      console.log("Conversations list:", data);
      if (data.conversations) {
        const conversations = data.conversations as Conversation[];
        dispatch({ type: "SET_CONVERSATIONS", payload: conversations });
      }
    },
    []
  );

  const handleChatResponse = useCallback(
    (data: Record<string, unknown>) => {
      console.log("Chat response:", data);
      if (data.conversationId === state.currentConversationId) {
        const message: Message = {
          id: generateId(),
          content: data.message as string,
          role: "assistant",
          timestamp: (data.timestamp as string) || new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: message });
      }
    },
    [state.currentConversationId]
  );

  const handleRCAStarted = useCallback(
    (data: Record<string, unknown>) => {
      console.log("RCA started:", data);
      if (data.conversationId === state.currentConversationId) {
        const message: Message = {
          id: generateId(),
          content: data.message as string,
          role: "assistant",
          timestamp: (data.timestamp as string) || new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: message });
        dispatch({ type: "SET_PROCESSING", payload: true });
      }
    },
    [state.currentConversationId]
  );

  const handleRCAUpdate = useCallback(
    (data: Record<string, unknown>) => {
      console.log("RCA update:", data);
      if (data.conversationId === state.currentConversationId) {
        const messageData = data.message as Message;
        dispatch({ type: "ADD_MESSAGE", payload: messageData });
      }
    },
    [state.currentConversationId]
  );

  const handleRCACompleted = useCallback(
    (data: Record<string, unknown>) => {
      console.log("RCA completed:", data);
      if (data.conversationId === state.currentConversationId) {
        const message: Message = {
          id: generateId(),
          content: data.message as string,
          role: "assistant",
          timestamp: (data.timestamp as string) || new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: message });
        dispatch({ type: "SET_PROCESSING", payload: false });
      }
    },
    [state.currentConversationId]
  );

  const handleRCAError = useCallback(
    (data: Record<string, unknown>) => {
      console.error("RCA error:", data);
      if (data.conversationId === state.currentConversationId) {
        const errorMessage: Message = {
          id: generateId(),
          content: data.message as string,
          role: "assistant",
          type: MESSAGE_TYPES.ERROR,
          timestamp: (data.timestamp as string) || new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: errorMessage });
        dispatch({ type: "SET_PROCESSING", payload: false });
      }
    },
    [state.currentConversationId]
  );

  // Set up WebSocket listeners for both regular and RCA functionality
  useEffect(() => {
    if (socket) {
      // Original handlers
      socket.on("process_step", handleMessage);
      socket.on("final_response", handleMessage);
      socket.on("acknowledgment", handleMessage);
      socket.on("welcomeMessage", handleMessage);

      // Conversation handlers
      socket.on("conversation_created", handleConversationCreated);
      socket.on("conversation_selected", handleConversationSelected);
      socket.on("conversations_list", handleConversationsList);
      socket.on("chat_response", handleChatResponse);
      socket.on("rca_started", handleRCAStarted);
      socket.on("rca_update", handleRCAUpdate);
      socket.on("rca_completed", handleRCACompleted);
      socket.on("rca_error", handleRCAError);

      // RCA-specific handlers
      socket.on("message", handleRCAMessage);
      socket.on("progress", handleRCAProgress);
      socket.on("analysis_result", handleAnalysisResult);
      socket.on("table_data", handleTableData);
      socket.on("step_result", (data: Record<string, unknown>) => {
        console.log("Received step result:", data);
        // Handle structured step results from Python
        if (data.data && typeof data.data === "object") {
          const stepData = data.data as Record<string, unknown>;
          const stepMessage: Message = {
            id: generateId(),
            content: `📋 ${stepData.step_type} - ${stepData.table}.${stepData.column}`,
            role: "assistant",
            type: MESSAGE_TYPES.STEP,
            timestamp: (data.timestamp as string) || new Date().toISOString(),
            stepNumber: stepData.step_number as number,
            stepTitle: `Layer ${stepData.step_number} Analysis`,
            stepData: stepData,
          };
          dispatch({ type: "ADD_MESSAGE", payload: stepMessage });

          // Update flow diagram with step result
          const flowNode = {
            id: `${stepData.table}.${stepData.column}`,
            table: stepData.table as string,
            column: stepData.column as string,
            step: stepData.step_number as number,
            status:
              stepData.status === "deviation"
                ? ("deviation" as const)
                : ("completed" as const),
            value: 0, // Extract from result if available
            expectedValue: 0,
            deviationPercentage: 0,
          };
          dispatch({ type: "ADD_FLOW_NODE", payload: flowNode });
        }
      });
      socket.on("lineage_graph", (data: Record<string, unknown>) => {
        console.log("Received lineage graph:", data);
        // Initialize flow diagram with lineage data
        if (data.data && typeof data.data === "object") {
          const graphData = data.data as Record<string, unknown>;
          if (graphData.nodes && Array.isArray(graphData.nodes)) {
            // Convert lineage graph to flow diagram format
            const flowNodes = graphData.nodes.map(
              (node: Record<string, unknown>, index: number) => ({
                id: (node.id as string) || `node_${index}`,
                table:
                  (node.label as string) ||
                  (node.id as string) ||
                  `table_${index}`,
                column:
                  node.type === "column" ? (node.label as string) : "main",
                step: index,
                status: "normal" as const,
                value: 0,
                expectedValue: 0,
                deviationPercentage: 0,
              })
            );

            // Add all nodes to flow diagram
            flowNodes.forEach(
              (node: {
                id: string;
                table: string;
                column: string;
                step: number;
                status: "normal";
                value: number;
                expectedValue: number;
                deviationPercentage: number;
              }) => {
                dispatch({ type: "ADD_FLOW_NODE", payload: node });
              }
            );
          }
        }
      });
      socket.on("node_status_update", (data: Record<string, unknown>) => {
        console.log("Received node status update:", data);
        // Update specific node status in flow diagram
        if (data.data && typeof data.data === "object") {
          const nodeData = data.data as Record<string, unknown>;
          if (nodeData.nodeId && nodeData.status) {
            const nodeId = nodeData.nodeId as string;
            const status = nodeData.status as string;
            const flowNode = {
              id: nodeId,
              table: nodeId.split(".")[0] || nodeId,
              column: nodeId.split(".")[1] || "main",
              step: Date.now(), // Use timestamp as step for real-time updates
              status:
                status === "checking"
                  ? ("checking" as const)
                  : status === "mismatch"
                  ? ("deviation" as const)
                  : status === "match"
                  ? ("completed" as const)
                  : ("normal" as const),
              value: (nodeData.value as number) || 0,
              expectedValue: (nodeData.expectedValue as number) || 0,
              deviationPercentage:
                (nodeData.deviationPercentage as number) || 0,
            };
            dispatch({ type: "ADD_FLOW_NODE", payload: flowNode });
          }
        }
      });
      socket.on("final_report", handleFinalReport);
      socket.on("error", handleError);

      return () => {
        // Original cleanup
        socket.off("process_step", handleMessage);
        socket.off("final_response", handleMessage);
        socket.off("acknowledgment", handleMessage);
        socket.off("welcomeMessage", handleMessage);

        // Conversation cleanup
        socket.off("conversation_created", handleConversationCreated);
        socket.off("conversation_selected", handleConversationSelected);
        socket.off("conversations_list", handleConversationsList);
        socket.off("chat_response", handleChatResponse);
        socket.off("rca_started", handleRCAStarted);
        socket.off("rca_update", handleRCAUpdate);
        socket.off("rca_completed", handleRCACompleted);
        socket.off("rca_error", handleRCAError);

        // RCA cleanup
        socket.off("message", handleRCAMessage);
        socket.off("progress", handleRCAProgress);
        socket.off("analysis_result", handleAnalysisResult);
        socket.off("table_data", handleTableData);
        socket.off("step_result");
        socket.off("lineage_graph");
        socket.off("node_status_update");
        socket.off("final_report", handleFinalReport);
        socket.off("error", handleError);
      };
    }
  }, [
    socket,
    handleRCAMessage,
    handleRCAProgress,
    handleAnalysisResult,
    handleTableData,
    handleFinalReport,
    handleError,
    handleConversationCreated,
    handleConversationSelected,
    handleConversationsList,
    handleChatResponse,
    handleRCAStarted,
    handleRCAUpdate,
    handleRCACompleted,
    handleRCAError,
  ]);

  // Welcome message and conversation initialization
  useEffect(() => {
    if (socket && isConnected) {
      // Request existing conversations only once when connected
      console.log("🔄 Requesting conversations on connection");
      requestConversations();
    }
  }, [socket, isConnected, requestConversations]);

  // Handle initial conversation creation and welcome message
  useEffect(() => {
    if (socket && isConnected) {
      // Create initial conversation if none exists
      if (state.conversations.length === 0 && !state.currentConversationId) {
        createNewConversation("Welcome Chat", "chat");
      }

      // Send welcome message if no messages in current conversation
      if (state.currentConversationId && state.messages.length === 0) {
        const welcomeMessage: Message = {
          id: generateId(),
          content: `Hi Govind, great to see you 👋

I can quickly find the root cause of your data issues using AI-driven analysis.

Describe your issue, e.g.:
"I see low volumes of netadds on dla_sum_fact"

Share an issue details similar to this:
{
  "table_name": "<Fully qualified table name>",
  "column_name": "<Column name>",
  "db_type": "<GCP/Teradata>",
  "failed_rule": "<SQL that contains the validation>",
  "threshold_of_zscore": "<threshold value>",
  "expected_SD": "<expected standard deviation>",
  "expected_value": "<expected value>",
  "actual_value": "<actual value>",
  "start_date": "<start date>",
  "end_date": "<end date>"
}`,
          role: "assistant",
          timestamp: new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: welcomeMessage });
      }
    }
  }, [
    socket,
    isConnected,
    state.conversations.length,
    state.currentConversationId,
    state.messages.length,
    createNewConversation,
  ]);

  const handleSendMessage = (message: string) => {
    // Ensure we have a current conversation
    if (!state.currentConversationId) {
      // Create a new conversation for this message
      createNewConversation("New Chat", "chat");
      return;
    }

    const userMessage: Message = {
      id: generateId(),
      content: message,
      role: "user",
      timestamp: new Date().toISOString(),
    };

    dispatch({ type: "ADD_MESSAGE", payload: userMessage });
    dispatch({ type: "SET_LOADING", payload: true });

    if (isConnected && state.currentConversationId) {
      console.log("Sending user message:", userMessage);
      sendMessage(state.currentConversationId, message);
    }
  };

  const handleNewChat = () => {
    // Create a new conversation
    createNewConversation("New Chat", "chat");
    dispatch({ type: "RESET_RCA_STATE" });
  };

  return (
    <ThemeProvider>
      <ErrorBoundary>
        <div className="h-screen flex overflow-hidden bg-white dark:bg-gray-900">
          <Sidebar
            onNewChat={handleNewChat}
            conversations={state.conversations}
            currentConversationId={state.currentConversationId}
            onSelectConversation={selectConversation}
          />

          <main className="flex flex-1 flex-col min-h-0">
            <div className="flex flex-col h-full min-h-0">
              <ChatWindow
                messages={state.messages}
                isLoading={state.isLoading}
                isProcessing={state.isProcessing}
                progressSteps={state.progressSteps}
                tableData={state.tableData}
                finalReport={state.finalReport}
                currentStep={state.currentStep}
                flowDiagramData={state.flowDiagramData || undefined}
              />
              <InputBar
                onSendMessage={handleSendMessage}
                isLoading={state.isLoading}
                disabled={state.isLoading}
                placeholder={
                  state.isLoading
                    ? "Loading..."
                    : "Describe your data quality issue..."
                }
              />
            </div>
          </main>
        </div>
      </ErrorBoundary>
    </ThemeProvider>
  );
}

export default App;
