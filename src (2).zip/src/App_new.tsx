import { useReducer, useEffect, useState } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import InputBar from "./components/InputBar";
import FreeTestingInterface from "./components/FreeTestingInterface";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { useWebSocket } from "./hooks/useWebSocket";
import { appReducer, initialState } from "./reducers/appReducer";
import type { Message } from "./types";
import { generateId } from "./utils";
import { MESSAGE_TYPES } from "./types";

function App() {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const { socket, isConnected } = useWebSocket();
  const [isFreeTestingMode, setIsFreeTestingMode] = useState(false);

  // WebSocket message handler
  const handleMessage = (data: unknown) => {
    if (data && typeof data === "object" && "type" in data) {
      const messageData = data as Record<string, unknown>;
      console.log("Received WebSocket message:", messageData);
      if (messageData.type === "acknowledgment") {
        // Handle acknowledgment message
        const ackMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Hello!",
          role: "assistant",
          timestamp: new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: ackMessage });
        dispatch({ type: "SET_LOADING", payload: false });
      } else if (messageData.type === "step_result") {
        // Handle new 3-step workflow results
        const stepMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Step completed...",
          role: "assistant",
          type: MESSAGE_TYPES.STEP,
          timestamp: new Date().toISOString(),
          stepNumber: messageData.step_number as number,
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
      } else if (messageData.type === "process_step") {
        const stepMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Processing step...",
          role: "assistant",
          type: MESSAGE_TYPES.STEP,
          timestamp: new Date().toISOString(),
          stepNumber: messageData.step_number as number,
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
      } else if (messageData.type === "node_response") {
        // Handle real-time node responses
        const nodeMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Node completed...",
          role: "assistant",
          type: MESSAGE_TYPES.NODE_RESPONSE,
          timestamp: new Date().toISOString(),
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: nodeMessage });
      } else if (messageData.type === "final_response") {
        const finalMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Analysis complete.",
          role: "assistant",
          type: MESSAGE_TYPES.FINAL,
          timestamp: new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: finalMessage });
        dispatch({ type: "SET_LOADING", payload: false });
      }
    }
  };

  // Set up WebSocket listeners
  useEffect(() => {
    if (socket) {
      socket.on("process_step", handleMessage);
      socket.on("final_response", handleMessage);
      socket.on("acknowledgment", handleMessage);
      socket.on("welcomeMessage", handleMessage);
      return () => {
        socket.off("process_step", handleMessage);
        socket.off("final_response", handleMessage);
        socket.off("acknowledgment", handleMessage);
        socket.off("welcomeMessage", handleMessage);
      };
    }
  }, [socket]);

  // Welcome message effect - adds welcome message when connected and no messages exist
  useEffect(() => {
    if (socket && isConnected && state.messages.length === 0) {
      const welcomeMessage: Message = {
        id: generateId(),
        content: `Hi Govind, great to see you 👋

I can quickly find the root cause of your data issues using AI-driven analysis.

Describe your issue, e.g.:
"I see low volumes of netadds on dla_sum_fact"

Share an issue details similar to this:
{
  "table_name": "<Fully qualified table name>",
  "column_name": "<Column name>",
  "db_type": "<GCP/Teradata>",
  "failed_rule": "<SQL that contains the validation>",
  "threshold_of_zscore": "<threshold value>",
  "expected_SD": "<expected standard deviation>",
  "expected_value": "<expected value>",
  "actual_value": "<actual value>",
  "start_date": "<start date>",
  "end_date": "<end date>"
}`,
        role: "assistant",
        timestamp: new Date().toISOString(),
      };
      dispatch({ type: "ADD_MESSAGE", payload: welcomeMessage });
    }
  }, [socket, isConnected, state.messages.length, dispatch]);

  const handleSendMessage = (message: string) => {
    const userMessage: Message = {
      id: generateId(),
      content: message,
      role: "user",
      timestamp: new Date().toISOString(),
    };

    dispatch({ type: "ADD_MESSAGE", payload: userMessage });
    dispatch({ type: "SET_LOADING", payload: true });

    // Send message via WebSocket
    if (socket && isConnected) {
      socket.emit("acknowledgment", userMessage);
    }
  };

  const handleNewChat = () => {};

  // If free testing mode is enabled, render the Free Testing Interface
  if (isFreeTestingMode) {
    return (
      <ErrorBoundary>
        <div className="min-h-screen bg-gray-100">
          {/* Mode Toggle */}
          <div className="bg-white shadow-sm border-b px-6 py-3 flex justify-between items-center">
            <h1 className="text-lg font-semibold text-gray-800">
              Agentic Data Quality Analysis - Free Testing Mode
            </h1>
            <button
              onClick={() => setIsFreeTestingMode(false)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
            >
              Switch to Chat Mode
            </button>
          </div>
          <FreeTestingInterface />
        </div>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="h-screen flex overflow-hidden">
        <Sidebar onNewChat={handleNewChat} />

        <main className="flex flex-1 flex-col">
          {/* Mode Toggle */}
          <div className="bg-white shadow-sm border-b px-6 py-3 flex justify-between items-center">
            <h1 className="text-lg font-semibold text-gray-800">
              Chat Interface
            </h1>
            <button
              onClick={() => setIsFreeTestingMode(true)}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm"
            >
              🧪 Free Testing Mode
            </button>
          </div>

          <div className="flex flex-col h-full flex-1">
            <div className="flex-1 overflow-y-auto">
              <ChatWindow
                messages={state.messages}
                isLoading={state.isLoading}
              />
            </div>
            <InputBar
              onSendMessage={handleSendMessage}
              isLoading={state.isLoading}
              disabled={state.isLoading}
              placeholder={
                state.isLoading
                  ? "Loading..."
                  : "Describe your data quality issue..."
              }
            />
          </div>
        </main>
      </div>
    </ErrorBoundary>
  );
}

export default App;
