import React, { useState, useEffect } from "react";
import { useWebSocket } from "../hooks/useWebSocket";
import type { Message } from "../types";
import { generateId } from "../utils";

interface AnalysisResult {
  parsed_dq_info?: Record<string, unknown>;
  initial_check_result?: Record<string, unknown>;
  analysis_results?: Record<string, unknown>;
  anamoly_node_response?: string | Record<string, unknown>;
}

interface SampleIssue {
  name: string;
  content: string;
}

const FreeTestingInterface: React.FC = () => {
  const [selectedSample, setSelectedSample] = useState<string>("sample1");
  const [customInput, setCustomInput] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [results, setResults] = useState<AnalysisResult>({});
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeTab, setActiveTab] = useState<string>("input");
  const [systemStatus, setSystemStatus] = useState<string>("ready");

  const { socket, isConnected } = useWebSocket();

  const sampleIssues: Record<string, SampleIssue> = {
    sample1: {
      name: "Sample Issue 1 - Metric Anomaly",
      content: `I detected anomalies in our daily metrics:
{
  "table_name": "sample_fact_table",
  "column_name": "metric_value", 
  "db_type": "SQLite",
  "failed_rule": "SELECT AVG(metric_value) FROM sample_fact_table WHERE business_date >= '2024-01-01'",
  "threshold_of_zscore": "2.0",
  "expected_value": "100.0",
  "actual_value": "85.5",
  "start_date": "2024-01-01",
  "end_date": "2024-01-31"
}`,
    },
    sample2: {
      name: "Sample Issue 2 - Data Quality",
      content: `Data quality check failed on category distribution:
{
  "table_name": "sample_fact_table",
  "column_name": "category",
  "db_type": "SQLite", 
  "failed_rule": "SELECT category, COUNT(*) FROM sample_fact_table GROUP BY category",
  "expected_value": "4.0",
  "actual_value": "6.0",
  "start_date": "2024-01-01",
  "end_date": "2024-01-31"
}`,
    },
    custom: {
      name: "Custom Input",
      content: "",
    },
  };

  useEffect(() => {
    if (!socket) return;

    const handleMessage = (data: Record<string, unknown>) => {
      console.log("Received message:", data);

      const newMessage: Message = {
        id: generateId(),
        content: (data.content as string) || "Processing...",
        role: "assistant",
        timestamp: new Date().toISOString(),
        stepTitle: data.title as string,
        stepData: data.data as Record<string, unknown>,
      };

      setMessages((prev) => [...prev, newMessage]);

      // Handle different message types
      if (data.type === "acknowledgment") {
        setSystemStatus("running");
      } else if (data.type === "step_result") {
        // Update results based on step
        setResults((prev) => {
          const updated = { ...prev };
          if (data.step_number === 1) {
            updated.parsed_dq_info = data.data as Record<string, unknown>;
          } else if (data.step_number === 2) {
            updated.initial_check_result = data.data as Record<string, unknown>;
          } else if (data.step_number === 3) {
            updated.analysis_results = data.data as Record<string, unknown>;
          }
          return updated;
        });
      } else if (data.type === "node_response") {
        if (data.node_name === "anomaly_detection") {
          setResults((prev) => ({
            ...prev,
            anamoly_node_response: data.data as Record<string, unknown>,
          }));
        }
      } else if (data.type === "final_response") {
        setIsAnalyzing(false);
        setSystemStatus("complete");
      } else if (data.type === "error") {
        setIsAnalyzing(false);
        setSystemStatus("error");
      }
    };

    socket.on("acknowledgment", handleMessage);
    socket.on("process_step", handleMessage);
    socket.on("final_response", handleMessage);
    socket.on("error", handleMessage);

    return () => {
      socket.off("acknowledgment", handleMessage);
      socket.off("process_step", handleMessage);
      socket.off("final_response", handleMessage);
      socket.off("error", handleMessage);
    };
  }, [socket]);

  const runAnalysis = () => {
    if (!socket || !isConnected) {
      alert("Not connected to server. Please wait for connection.");
      return;
    }

    const inputData =
      selectedSample === "custom"
        ? customInput
        : sampleIssues[selectedSample].content;

    if (!inputData.trim()) {
      alert("Please enter a data quality issue to analyze");
      return;
    }

    setIsAnalyzing(true);
    setResults({});
    setMessages([]);
    setSystemStatus("starting");
    setActiveTab("results");

    // Send user message
    const userMessage: Message = {
      id: generateId(),
      content: inputData,
      role: "user",
      timestamp: new Date().toISOString(),
    };

    setMessages([userMessage]);

    // Send to backend
    socket.emit("start_process", { userMessage });
  };

  const testConnection = async () => {
    try {
      const response = await fetch("http://127.0.0.1:3001/api/health");
      const data = await response.json();
      alert(
        `✅ Server Status: ${data.status}\nConnections: ${data.connections}\nActive Processes: ${data.activeProcesses}`
      );
    } catch {
      alert(
        "❌ Could not connect to server. Make sure the Node.js server is running."
      );
    }
  };

  const getStatusColor = () => {
    switch (systemStatus) {
      case "ready":
        return "text-green-500";
      case "running":
        return "text-yellow-500";
      case "complete":
        return "text-blue-500";
      case "error":
        return "text-red-500";
      default:
        return "text-gray-500";
    }
  };

  const getStatusText = () => {
    switch (systemStatus) {
      case "ready":
        return "✅ Ready for testing";
      case "running":
        return "🔄 Analysis in progress...";
      case "complete":
        return "✅ Analysis complete!";
      case "error":
        return "❌ Error occurred";
      default:
        return "⏳ Initializing...";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            🔍 Agentic Data Quality Analysis - FREE Testing Version
          </h1>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
            <h3 className="font-semibold text-blue-800 mb-2">
              🎯 Completely FREE for Testing!
            </h3>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>
                ✅ <strong>No API keys required</strong> - Uses mock LLM
                responses
              </li>
              <li>
                ✅ <strong>No external services</strong> - Everything runs
                locally
              </li>
              <li>
                ✅ <strong>No paid dependencies</strong> - Only free Python
                packages
              </li>
              <li>
                ✅ <strong>Ready to test immediately</strong> - Sample data
                included
              </li>
            </ul>
          </div>

          {/* System Status */}
          <div className="flex items-center justify-between bg-gray-100 rounded-lg p-3">
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium">System Status:</span>
              <span className={`font-semibold ${getStatusColor()}`}>
                {getStatusText()}
              </span>
              <span
                className={`text-sm ${
                  isConnected ? "text-green-600" : "text-red-600"
                }`}
              >
                WebSocket: {isConnected ? "🟢 Connected" : "🔴 Disconnected"}
              </span>
            </div>
            <button
              onClick={testConnection}
              className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600"
            >
              🧪 Test Connection
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* Tab Navigation */}
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: "input", label: "📝 Input & Testing", icon: "📝" },
                { id: "results", label: "📊 Analysis Results", icon: "📊" },
                { id: "queries", label: "🧪 SQL Testing", icon: "🧪" },
                { id: "setup", label: "🛠️ Setup Guide", icon: "🛠️" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-2 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {/* Input Tab */}
            {activeTab === "input" && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-800">
                  Test Data Quality Analysis
                </h2>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Choose a sample issue or enter custom:
                  </label>
                  <select
                    value={selectedSample}
                    onChange={(e) => setSelectedSample(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    {Object.entries(sampleIssues).map(([key, issue]) => (
                      <option key={key} value={key}>
                        {issue.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Data Quality Issue Description:
                  </label>
                  <textarea
                    value={
                      selectedSample === "custom"
                        ? customInput
                        : sampleIssues[selectedSample].content
                    }
                    onChange={(e) => {
                      if (selectedSample === "custom") {
                        setCustomInput(e.target.value);
                      }
                    }}
                    disabled={selectedSample !== "custom"}
                    className="w-full h-64 p-4 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your data quality issue description..."
                  />
                </div>

                <div className="flex space-x-4">
                  <button
                    onClick={runAnalysis}
                    disabled={isAnalyzing || !isConnected}
                    className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {isAnalyzing ? "🔄 Running Analysis..." : "🚀 Run Analysis"}
                  </button>
                </div>
              </div>
            )}

            {/* Results Tab */}
            {activeTab === "results" && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-800">
                  Analysis Results
                </h2>

                {messages.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <p className="text-lg">No analysis results yet.</p>
                    <p>
                      Run an analysis from the Input & Testing tab to see
                      results here.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Messages */}
                    <div className="border border-gray-200 rounded-lg p-4 max-h-96 overflow-y-auto">
                      <h3 className="font-medium text-gray-700 mb-3">
                        Real-time Analysis Progress:
                      </h3>
                      <div className="space-y-2">
                        {messages.map((message) => (
                          <div
                            key={message.id}
                            className={`p-3 rounded-lg ${
                              message.role === "user"
                                ? "bg-blue-100 border-l-4 border-blue-500 ml-8"
                                : "bg-gray-100 border-l-4 border-gray-500 mr-8"
                            }`}
                          >
                            <div className="flex justify-between items-start mb-1">
                              <span className="font-medium text-sm">
                                {message.role === "user"
                                  ? "👤 You"
                                  : "🤖 ADQ Assistant"}
                                {message.stepTitle && ` - ${message.stepTitle}`}
                              </span>
                              <span className="text-xs text-gray-500">
                                {new Date(
                                  message.timestamp
                                ).toLocaleTimeString()}
                              </span>
                            </div>
                            <p className="text-sm whitespace-pre-wrap">
                              {message.content}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Detailed Results */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Parsed Information */}
                      <div className="bg-gray-50 rounded-lg p-4">
                        <h3 className="font-semibold text-gray-800 mb-3">
                          📋 Parsed Information
                        </h3>
                        <pre className="text-xs bg-white p-3 rounded border overflow-auto max-h-48">
                          {JSON.stringify(
                            results.parsed_dq_info || {},
                            null,
                            2
                          )}
                        </pre>
                      </div>

                      {/* Initial Check */}
                      <div className="bg-gray-50 rounded-lg p-4">
                        <h3 className="font-semibold text-gray-800 mb-3">
                          ✅ Initial Check
                        </h3>
                        <pre className="text-xs bg-white p-3 rounded border overflow-auto max-h-48">
                          {JSON.stringify(
                            results.initial_check_result || {},
                            null,
                            2
                          )}
                        </pre>
                      </div>

                      {/* Lineage Analysis */}
                      <div className="bg-gray-50 rounded-lg p-4">
                        <h3 className="font-semibold text-gray-800 mb-3">
                          🔍 Lineage Analysis
                        </h3>
                        <pre className="text-xs bg-white p-3 rounded border overflow-auto max-h-48">
                          {JSON.stringify(
                            results.analysis_results || {},
                            null,
                            2
                          )}
                        </pre>
                      </div>

                      {/* Anomaly Detection */}
                      <div className="bg-gray-50 rounded-lg p-4">
                        <h3 className="font-semibold text-gray-800 mb-3">
                          ⚠️ Anomaly Detection
                        </h3>
                        <pre className="text-xs bg-white p-3 rounded border overflow-auto max-h-48">
                          {JSON.stringify(
                            typeof results.anamoly_node_response === "string"
                              ? JSON.parse(
                                  results.anamoly_node_response || "{}"
                                )
                              : results.anamoly_node_response || {},
                            null,
                            2
                          )}
                        </pre>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* SQL Testing Tab */}
            {activeTab === "queries" && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-800">
                  Sample SQL Queries
                </h2>
                <div className="bg-gray-100 rounded-lg p-6">
                  <h3 className="font-medium text-gray-700 mb-4">
                    📚 Sample Queries You Can Try:
                  </h3>
                  <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-auto">
                    <pre>{`-- Check data distribution
SELECT category, COUNT(*) as count, AVG(metric_value) as avg_value
FROM sample_fact_table 
GROUP BY category;

-- Check for null values  
SELECT business_date, 
       COUNT(*) as total_records,
       COUNT(metric_value) as non_null_records
FROM sample_fact_table
GROUP BY business_date;

-- Anomaly detection
SELECT business_date, metric_value,
       ABS(metric_value - AVG(metric_value) OVER()) / STDDEV(metric_value) OVER() as z_score
FROM sample_fact_table
WHERE ABS(metric_value - AVG(metric_value) OVER()) / STDDEV(metric_value) OVER() > 2;

-- Data trends over time
SELECT business_date,
       AVG(metric_value) as daily_avg,
       COUNT(*) as record_count
FROM sample_fact_table
GROUP BY business_date
ORDER BY business_date DESC;`}</pre>
                  </div>
                  <p className="text-sm text-gray-600 mt-4">
                    These queries work on the sample SQLite database created
                    during analysis. The Python backend automatically creates
                    sample tables with realistic data for testing.
                  </p>
                </div>
              </div>
            )}

            {/* Setup Tab */}
            {activeTab === "setup" && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-800">
                  🛠️ Setup Instructions
                </h2>

                <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                  <h3 className="font-semibold text-green-800 mb-4">
                    Quick Setup (5 minutes):
                  </h3>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-green-700 mb-2">
                        1. Install Python packages (all completely free):
                      </h4>
                      <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-sm">
                        pip install pandas numpy networkx langchain-core
                        langgraph streamlit
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-green-700 mb-2">
                        2. Start the Node.js backend:
                      </h4>
                      <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-sm">
                        cd adq-node
                        <br />
                        npm install
                        <br />
                        npm start
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-green-700 mb-2">
                        3. Start the React frontend:
                      </h4>
                      <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-sm">
                        cd adq-react
                        <br />
                        npm install
                        <br />
                        npm run dev
                      </div>
                    </div>

                    <div className="bg-green-100 border border-green-300 rounded p-4">
                      <p className="text-green-800">
                        <strong>That's it!</strong> No API keys, no external
                        services, no configuration needed.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <h3 className="font-semibold text-blue-800 mb-4">
                    What you get:
                  </h3>
                  <ul className="space-y-2 text-blue-700">
                    <li>✅ Complete data quality analysis workflow</li>
                    <li>✅ Mock AI responses for testing</li>
                    <li>✅ SQLite database with sample data</li>
                    <li>✅ Anomaly detection algorithms</li>
                    <li>✅ Interactive web interface</li>
                    <li>✅ Real-time WebSocket communication</li>
                    <li>✅ Custom SQL query testing</li>
                  </ul>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                  <h3 className="font-semibold text-yellow-800 mb-4">
                    Perfect for:
                  </h3>
                  <ul className="space-y-2 text-yellow-700">
                    <li>🧪 Testing and prototyping</li>
                    <li>📚 Learning data quality concepts</li>
                    <li>🎯 Demonstrating workflows</li>
                    <li>🔧 Development and debugging</li>
                    <li>📋 Training and education</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FreeTestingInterface;
