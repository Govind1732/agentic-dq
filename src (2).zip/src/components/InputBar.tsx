import React, { useState, useRef, useCallback } from "react";
import type { KeyboardEvent } from "react";
import { ArrowUp, Plus, Mic, X } from "lucide-react";
import type { SelectedFile } from "../types/speechRecognition";
import { useSpeechRecognition } from "../hooks/useSpeechRecognition";
import { useThrottle } from "../hooks/useThrottle";
import {
  formatFileSize,
  getFileIcon,
  generateFileId,
  isSpeechRecognitionSupported,
} from "../utils/fileUtils";

interface InputBarProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  disabled?: boolean;
  placeholder?: string;
}

const InputBar: React.FC<InputBarProps> = ({
  onSendMessage,
  isLoading,
  disabled = false,
  placeholder = "Describe your data quality issue...",
}) => {
  const [message, setMessage] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<SelectedFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Custom hooks
  const { isRecording, startRecording, stopRecording } = useSpeechRecognition();
  const { throttle, canExecute } = useThrottle(1000);

  const handleMicClick = useCallback(() => {
    if (!isSpeechRecognitionSupported()) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isRecording) {
      stopRecording();
      return;
    }

    startRecording((transcript) => {
      setMessage((prev) => (prev ? prev + " " + transcript : transcript));
    });
  }, [isRecording, startRecording, stopRecording]);

  const handleSubmit = useCallback(() => {
    if (!message.trim() || isLoading || disabled) return;

    const success = throttle(() => {
      onSendMessage(message.trim());
      setMessage("");
      setSelectedFiles([]);

      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
        // Maintain focus after sending
        setTimeout(() => {
          textareaRef.current?.focus();
        }, 10);
      }
    });

    if (!success) {
      console.warn("Message sending throttled - please wait");
    }
  }, [message, isLoading, disabled, onSendMessage, throttle]);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setMessage(e.target.value);

      // Auto-resize textarea
      const textarea = e.target;
      textarea.style.height = "auto";
      textarea.style.height = Math.min(textarea.scrollHeight, 120) + "px";
    },
    []
  );

  const canSend = message.trim() && !isLoading && !disabled && canExecute();

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(e.target.files || []);
      if (files.length > 0) {
        const file = files[0];
        const newFile: SelectedFile = {
          id: generateFileId(),
          name: file.name,
          type: file.type,
          size: file.size,
          file,
        };
        setSelectedFiles([newFile]); // Only allow one file
      }

      // Reset the input so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    },
    []
  );

  const removeFile = useCallback((fileId: string) => {
    setSelectedFiles((prev) => prev.filter((f) => f.id !== fileId));
  }, []);

  return (
    <div className="border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-4">
      <div className="max-w-4xl mx-auto relative rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 shadow-sm transition-colors focus-within:border-blue-500 dark:focus-within:border-blue-400">
        {/* Selected Files Display */}
        {selectedFiles.length > 0 && (
          <div className="border-b border-gray-200 dark:border-gray-600 px-4 py-2">
            <div className="flex flex-wrap gap-2">
              {selectedFiles.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center gap-2 rounded-lg bg-gray-100 dark:bg-gray-700 px-3 py-2 text-sm"
                >
                  <span className="text-lg">{getFileIcon(file.type)}</span>
                  <div className="flex min-w-0 flex-col">
                    <span className="max-w-32 truncate text-gray-800 dark:text-gray-200">
                      {file.name}
                    </span>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {formatFileSize(file.size)}
                    </span>
                  </div>
                  <button
                    onClick={() => removeFile(file.id)}
                    className="text-gray-400 transition-colors hover:text-gray-600 dark:hover:text-gray-200 hover:cursor-pointer"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex items-center gap-2 p-3">
          {/* File Upload Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="flex-shrink-0 p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors disabled:opacity-50 hover:cursor-pointer"
            title="Attach file"
          >
            <Plus className="w-5 h-5" />
          </button>

          {/* Textarea Container */}
          <div className="flex-1">
            <textarea
              ref={textareaRef}
              value={message}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              disabled={disabled}
              rows={1}
              className="w-full px-3 py-2 bg-transparent text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 resize-none outline-none focus:outline-none border-none disabled:opacity-50"
              style={{
                height: "auto",
                minHeight: "40px",
                maxHeight: "120px",
                border: "none",
                outline: "none",
                boxShadow: "none",
              }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = "auto";
                target.style.height = Math.min(target.scrollHeight, 120) + "px";
              }}
            />
          </div>

          {/* Mic Button */}
          <button
            type="button"
            disabled={isLoading}
            onClick={handleMicClick}
            className={`flex-shrink-0 p-2 rounded-lg transition-colors disabled:opacity-50 ${
              isRecording
                ? "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400"
                : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
            }`}
            aria-label={isRecording ? "Stop recording" : "Start recording"}
          >
            <Mic className={`h-5 w-5 ${isRecording ? "animate-pulse" : ""}`} />
          </button>

          {/* Send Button */}
          <button
            onClick={handleSubmit}
            disabled={!canSend}
            className={`flex-shrink-0 p-2.5 rounded-lg transition-all duration-200 ${
              canSend
                ? "bg-white hover:bg-stone-200 text-black shadow-sm hover:shadow-md hover:cursor-pointer"
                : "bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 cursor-not-allowed"
            }`}
            title="Send message"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <ArrowUp className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".json,text/plain,application/json"
        onChange={handleFileSelect}
        className="hidden"
        multiple={false}
      />
    </div>
  );
};

export default InputBar;
