import React, { useState, useRef, useEffect } from "react";
import {
  Monitor,
  Sun,
  Moon,
  Settings,
  HelpCircle,
  ChevronRight,
} from "lucide-react";
import { useTheme, type Theme } from "../contexts/ThemeContext";

interface ProfileDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail: string;
  userName: string;
}

const ProfileDropdown: React.FC<ProfileDropdownProps> = ({
  isOpen,
  onClose,
  userEmail,
  userName,
}) => {
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { theme, setTheme, effectiveTheme } = useTheme();
  const [showThemeSubmenu, setShowThemeSubmenu] = useState(false);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        onClose();
        setShowThemeSubmenu(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const themeOptions: { value: Theme; label: string; icon: React.ReactNode }[] =
    [
      {
        value: "system",
        label: "System",
        icon: <Monitor className="w-4 h-4" />,
      },
      { value: "light", label: "Light", icon: <Sun className="w-4 h-4" /> },
      { value: "dark", label: "Dark", icon: <Moon className="w-4 h-4" /> },
    ];

  const handleThemeSelect = (selectedTheme: Theme) => {
    setTheme(selectedTheme);
    setShowThemeSubmenu(false);
    onClose();
  };

  return (
    <div
      ref={dropdownRef}
      className="absolute bottom-full left-0 mb-2 w-80 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50"
    >
      {/* User Info */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center">
            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
              {userName.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <p className="font-medium text-gray-900 dark:text-gray-100">
              {userName}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {userEmail}
            </p>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="py-2">
        {/* Theme Selection */}
        <div className="relative">
          <button
            onClick={() => setShowThemeSubmenu(!showThemeSubmenu)}
            className="w-full px-4 py-2 text-left flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <div className="flex items-center space-x-3">
              {effectiveTheme === "dark" ? (
                <Moon className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              ) : (
                <Sun className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              )}
              <span className="text-gray-700 dark:text-gray-300">Theme</span>
            </div>
            <ChevronRight
              className={`w-4 h-4 text-gray-400 transition-transform ${
                showThemeSubmenu ? "rotate-90" : ""
              }`}
            />
          </button>

          {/* Theme Submenu */}
          {showThemeSubmenu && (
            <div className="bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600">
              {themeOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleThemeSelect(option.value)}
                  className={`w-full px-8 py-2 text-left flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors ${
                    theme === option.value
                      ? "bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
                      : "text-gray-700 dark:text-gray-300"
                  }`}
                >
                  {option.icon}
                  <span>{option.label}</span>
                  {theme === option.value && (
                    <div className="ml-auto w-2 h-2 bg-blue-600 dark:bg-blue-400 rounded-full"></div>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Settings */}
        <button className="w-full px-4 py-2 text-left flex items-center space-x-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
          <Settings className="w-4 h-4 text-gray-600 dark:text-gray-400" />
          <span className="text-gray-700 dark:text-gray-300">Settings</span>
        </button>

        {/* Help */}
        <button className="w-full px-4 py-2 text-left flex items-center space-x-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
          <HelpCircle className="w-4 h-4 text-gray-600 dark:text-gray-400" />
          <span className="text-gray-700 dark:text-gray-300">Help</span>
        </button>
      </div>
    </div>
  );
};

export default ProfileDropdown;
