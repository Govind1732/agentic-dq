import React, { useEffect, useRef, useState } from "react";
import { Bot, User } from "lucide-react";
import type {
  Message,
  ProgressStep,
  TableData,
  FlowDiagramData,
} from "../types";
import { DataLineage } from "./DataLineage";

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  isProcessing?: boolean;
  progressSteps?: ProgressStep[];
  tableData?: TableData[];
  finalReport?: unknown | null;
  currentStep?: string;
  flowDiagramData?: FlowDiagramData;
  onSampleInput?: (sampleData: unknown) => void;
  onFeedback?: (feedback: string) => void;
  onExtensionQuestion?: (question: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({
  messages,
  isLoading,
  progressSteps = [],
}) => {
  const [copiedStates, setCopiedStates] = useState<{ [key: string]: boolean }>(
    {}
  );
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToTop = () => {
    scrollContainerRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, progressSteps]);

  // Add keyboard shortcuts for scrolling
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (
        event.target === scrollContainerRef.current ||
        scrollContainerRef.current?.contains(event.target as Node)
      ) {
        switch (event.key) {
          case "Home":
            event.preventDefault();
            scrollToTop();
            break;
          case "End":
            event.preventDefault();
            scrollToBottom();
            break;
          case "PageUp":
            event.preventDefault();
            scrollContainerRef.current?.scrollBy({
              top: -window.innerHeight * 0.8,
              behavior: "smooth",
            });
            break;
          case "PageDown":
            event.preventDefault();
            scrollContainerRef.current?.scrollBy({
              top: window.innerHeight * 0.8,
              behavior: "smooth",
            });
            break;
        }
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  const renderMessage = (
    message: Message,
    _index: number,
    messages: Message[]
  ) => {
    console.log("Rendering message:", message);
    // Function to copy text to clipboard
    const copyToClipboard = async (text: string, jsonIndex: number) => {
      const copyKey = `${message.id}-${jsonIndex}`;
      try {
        await navigator.clipboard.writeText(text);
        setCopiedStates((prev) => ({ ...prev, [copyKey]: true }));

        // Reset to "Copy" after 2 seconds
        setTimeout(() => {
          setCopiedStates((prev) => ({ ...prev, [copyKey]: false }));
        }, 1000);
      } catch (err) {
        console.error("Failed to copy text: ", err);
      }
    };

    // Function to render content with JSON styling
    const renderContentWithJSON = (content: string) => {
      // Split content by JSON blocks (content between { and })
      const parts = content.split(/(\{[\s\S]*?\})/);

      return parts.map((part, partIndex) => {
        // Check if this part is JSON
        if (part.trim().startsWith("{") && part.trim().endsWith("}")) {
          try {
            // Validate if it's proper JSON
            const jsonObj = JSON.parse(part);
            const formattedJSON = JSON.stringify(jsonObj, null, 2);
            const copyKey = `${message.id}-${partIndex}`;
            const isCopied = copiedStates[copyKey] || false;

            return (
              <div key={partIndex} className="my-4">
                <div className="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-sm">
                  <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-600">
                    <span className="text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide">
                      JSON Template
                    </span>
                    <button
                      onClick={() => copyToClipboard(formattedJSON, partIndex)}
                      className={`p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-700`}
                      title={isCopied ? "Copied!" : "Copy JSON"}
                    >
                      {isCopied ? (
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                      ) : (
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                          />
                        </svg>
                      )}
                    </button>
                  </div>
                  <div className="p-4">
                    <pre className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap font-mono overflow-x-auto">
                      {formattedJSON}
                    </pre>
                  </div>
                </div>
              </div>
            );
          } catch (e) {
            // If not valid JSON, treat as regular text
            console.warn("Invalid JSON:", e);
            return <span key={partIndex}>{part}</span>;
          }
        } else {
          // Regular text content
          return <span key={partIndex}>{part}</span>;
        }
      });
    };

    // ----- BOT NORMAL STATIC -----
    if (
      message.role === "bot" &&
      message.type === "normal" &&
      message.status === "static"
    ) {
      return (
        <div key={message.id} className="flex justify-start mb-4">
          <div className="flex items-start space-x-3 max-w-[85%]">
            <div className="text-gray-900 dark:text-gray-100 whitespace-pre-wrap break-words">
              {renderContentWithJSON(message.content)}
            </div>
          </div>
        </div>
      );
    }
    // ----- BOT NORMAL PROGRESS -----
    else if (
      message.role === "bot" &&
      message.type === "normal" &&
      message.status === "progress"
    ) {
      return (
        <div key={message.id} className="flex justify-start mb-4">
          <div className="flex items-start space-x-3 max-w-[85%]">
            <div className="text-gray-900 dark:text-gray-400 whitespace-pre-wrap break-words animate-pulse">
              {renderContentWithJSON(message.content)}
            </div>
          </div>
        </div>
      );
    }
    // ----- USER MESSAGE -----
    else if (message.role === "user" && message.type === "normal") {
      return (
        <div key={message.id} className="flex justify-end mb-4">
          <div className="flex items-start space-x-3 max-w-[85%]">
            <div className="bg-gray-100 dark:bg-blue-500 rounded-lg rounded-tr-sm p-4">
              <div className="text-gray-900 dark:text-gray-100 whitespace-pre-wrap break-words">
                {message.content}
              </div>
            </div>
            <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </div>
          </div>
        </div>
      );
    }
    // --- BOT STEPPER ---
    else if (message.role === "bot" && message.type === "stepper") {
      // group stepper messages by stepNumber
      const stepMessages = messages.filter((m) => m.type === "stepper");

      const grouped = stepMessages.reduce((acc, msg) => {
        const key = msg.stepNumber ?? msg.stepTitle ?? "misc";
        if (!acc[key]) acc[key] = [];
        acc[key].push(msg);
        return acc;
      }, {} as Record<string | number, Message[]>);

      return (
        <ol className="relative border-s border-gray-200 dark:border-gray-700 space-y-10">
          {Object.entries(grouped).map(([stepNum, group]) => {
            const titleObj = group.find((g) => g.stepTitle);

            return (
              <li key={stepNum} className="ms-6 relative">
                {/* Number circle OR special icon for final summary */}
                {titleObj?.stepTitle === "Final Root Cause Summary" ? (
                  <span className="absolute -start-3 flex items-center justify-center w-7 h-7 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 ring-4 ring-white dark:ring-gray-900">
                    {/* Document/Check icon */}
                    <svg
                      className="w-3.5 h-3.5"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="currentColor"
                      viewBox="0 0 18 20"
                    >
                      <path d="M16 1h-3.278A1.992 1.992 0 0 0 11 0H7a1.993 1.993 0 0 0-1.722 1H2a2 2 0 0 0-2 2v15a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2ZM7 2h4v3H7V2Zm5.7 8.289-3.975 3.857a1 1 0 0 1-1.393 0L5.3 12.182a1.002 1.002 0 1 1 1.4-1.436l1.328 1.289 3.28-3.181a1 1 0 1 1 1.392 1.435Z" />
                    </svg>
                  </span>
                ) : (
                  <span className="absolute -start-3 flex items-center justify-center w-7 h-7 rounded-full bg-green-200 dark:bg-green-700 text-xs font-semibold text-gray-900 dark:text-white ring-4 ring-white dark:ring-gray-900">
                    {stepNum}
                  </span>
                )}

                {/* Step Title */}
                {titleObj?.stepTitle && (
                  <h3 className="font-semibold leading-tight mb-1">
                    {titleObj.stepTitle}
                  </h3>
                )}

                {/* Step Content */}
                {group.map((c) => {
                  if (c.stepContent) {
                    return (
                      <p
                        key={c.id}
                        className="text-sm text-gray-600 dark:text-gray-400"
                      >
                        {c.stepContent}
                      </p>
                    );
                  }

                  if (c.stepComponent === "dataLineage") {
                    return (
                      <div key={c.id} className="my-4">
                        <DataLineage lineageData={c.lineageData} />
                      </div>
                    );
                  }

                  return null;
                })}
              </li>
            );
          })}
        </ol>
      );
    }

    // Default fallback for other message types
    return (
      <div key={message.id} className="w-full">
        <div className="flex justify-start mb-4">
          <div className="flex items-start space-x-3 max-w-[85%]">
            <div className="text-gray-900 dark:text-gray-100 whitespace-pre-wrap break-words">
              {message.role === "bot"
                ? renderContentWithJSON(message.content)
                : message.content}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900 min-h-0">
      {/* Messages */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto overflow-x-hidden px-4 pt-4 pb-0"
        style={{
          minHeight: 0,
          maxHeight: "100%",
        }}
        tabIndex={0}
      >
        <div className="max-w-4xl mx-auto space-y-4">
          {/* RCA Progress - shows step-by-step analysis as per Figma */}
          {/* {renderRCAProgress()} */}
          {messages.map(renderMessage)}

          {isLoading && (
            <div className="flex justify-start mb-4">
              <div className="flex items-start space-x-3 max-w-[85%]">
                {/* <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                </div> */}
                <div className="">
                  <div className="flex items-center space-x-2">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                    <span className="text-sm text-gray-500">Analyzing...</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Empty state */}
          {messages.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <Bot className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 dark:text-gray-400 text-lg">
                Start a conversation
              </p>
              <p className="text-gray-400 dark:text-gray-500 text-sm mt-2">
                Type your message below to begin
              </p>
            </div>
          )}
        </div>
        <div ref={messagesEndRef} className="pb-4" />
      </div>
    </div>
  );
};

export { ChatWindow };
export default ChatWindow;
