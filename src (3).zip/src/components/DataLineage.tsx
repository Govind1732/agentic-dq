import { useState, useEffect } from "react";
import { Database, GitBranch, ArrowRight, Circle, Square } from "lucide-react";

// React Flow compatible node interface - matches React Flow's expected structure
interface ReactFlowNode {
  id: string;
  type?: string; // React Flow node type ('default', 'input', 'output', etc.)
  data: {
    label: string;
    nodeType?: "table" | "column"; // Our internal classification
    originalId?: string;
    level?: number;
    parentId?: string;
    children?: string[];
    [key: string]: unknown;
  };
  position: { x: number; y: number };
  // React Flow specific properties (for future compatibility)
  selected?: boolean;
  dragging?: boolean;
  dragHandle?: string;
  width?: number;
  height?: number;
  zIndex?: number;
}

// React Flow compatible edge interface - matches React Flow's expected structure
interface ReactFlowEdge {
  id: string;
  source: string;
  target: string;
  type?: string; // React Flow edge type ('default', 'straight', 'step', 'smoothstep', etc.)
  data?: {
    label?: string;
    transformation?: string;
    [key: string]: unknown;
  };
  // React Flow specific properties (for future compatibility)
  selected?: boolean;
  animated?: boolean;
  style?: Record<string, unknown>;
  markerEnd?: string;
  markerStart?: string;
}

// React Flow compatible data structure
interface ReactFlowData {
  nodes: ReactFlowNode[];
  edges: ReactFlowEdge[];
}

// Legacy format support (for backward compatibility)
interface LegacyLineageNode {
  id: string;
  type: "table" | "column";
  name: string;
  label?: string;
  level?: number;
  parentId?: string;
  children?: string[];
  position?: { x: number; y: number };
  data?: Record<string, unknown>;
  originalId?: string;
}

interface LegacyLineageConnection {
  from: string;
  to: string;
  label?: string;
  transformation?: string;
}

interface LegacyLineageData {
  nodes: LegacyLineageNode[];
  connections: LegacyLineageConnection[];
}

interface DataLineageProps {
  lineageData?: ReactFlowData | LegacyLineageData | Record<string, unknown>;
  isLoading?: boolean;
  title?: string;
  // React Flow compatibility props (for future migration)
  onNodeClick?: (event: React.MouseEvent, node: ReactFlowNode) => void;
  onEdgeClick?: (event: React.MouseEvent, edge: ReactFlowEdge) => void;
  onNodeDrag?: (event: React.MouseEvent, node: ReactFlowNode) => void;
  fitView?: boolean;
  nodeTypes?: Record<string, React.ComponentType>;
  edgeTypes?: Record<string, React.ComponentType>;
}

// Helper function to normalize data to React Flow format
function normalizeToReactFlow(
  data: Record<string, unknown> | ReactFlowData | LegacyLineageData | undefined
): ReactFlowData | null {
  if (!data) return null;

  // Already in React Flow format
  if ("nodes" in data && "edges" in data && !("connections" in data)) {
    const reactFlowData = data as ReactFlowData;
    // Ensure all nodes have proper React Flow structure
    const normalizedNodes: ReactFlowNode[] = reactFlowData.nodes.map(
      (node) => ({
        id: node.id,
        type: node.type || "default",
        data: {
          ...node.data,
          label: node.data.label || node.id,
          nodeType: inferNodeType(node.data.label || node.id),
          originalId: node.data.originalId,
          level: node.data.level,
          parentId: node.data.parentId,
          children: node.data.children,
        },
        position: node.position || { x: 0, y: 0 },
      })
    );

    const normalizedEdges: ReactFlowEdge[] = reactFlowData.edges.map(
      (edge) => ({
        id: edge.id,
        source: edge.source,
        target: edge.target,
        type: edge.type || "default",
        data: edge.data || {},
      })
    );

    return { nodes: normalizedNodes, edges: normalizedEdges };
  }

  // Legacy format with 'connections' instead of 'edges'
  if ("nodes" in data && "connections" in data) {
    const legacyData = data as LegacyLineageData;

    const reactFlowNodes: ReactFlowNode[] = legacyData.nodes.map((node) => ({
      id: node.id,
      type: "default",
      data: {
        label: node.label || node.name || node.id,
        nodeType: node.type || inferNodeType(node.name || node.id),
        originalId: node.originalId,
        level: node.level,
        parentId: node.parentId,
        children: node.children,
        ...node.data,
      },
      position: node.position || { x: 0, y: 0 },
    }));

    const reactFlowEdges: ReactFlowEdge[] = legacyData.connections.map(
      (conn, index) => ({
        id: `${conn.from}-${conn.to}-${index}`,
        source: conn.from,
        target: conn.to,
        type: "default",
        data: {
          label: conn.label,
          transformation: conn.transformation,
        },
      })
    );

    return { nodes: reactFlowNodes, edges: reactFlowEdges };
  }

  return null;
}

// Helper function to infer node type from name/id
function inferNodeType(name: string): "table" | "column" {
  // If it contains a dot, it's likely a column reference (table.column)
  if (name.includes(".")) {
    return "column";
  }
  // Otherwise, assume it's a table
  return "table";
}

// React Flow Migration Helper - uncomment when ready to migrate
/*
const ReactFlowMigrationComponent = ({ data }: { data: ReactFlowData }) => {
  return (
    <ReactFlow
      nodes={data.nodes}
      edges={data.edges}
      onNodeClick={(event, node) => handleNodeClick(node.id, node)}
      onEdgeClick={onEdgeClick}
      fitView={fitView}
      nodeTypes={nodeTypes}
      edgeTypes={edgeTypes}
    >
      <Background />
      <Controls />
      <MiniMap />
    </ReactFlow>
  );
};
*/

export const DataLineage = ({
  lineageData,
  isLoading = false,
  title = "Data Lineage",
  onNodeClick,
  onEdgeClick,
  fitView = true,
}: DataLineageProps) => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [data, setData] = useState<ReactFlowData | null>(null);

  // Handle lineage data from backend
  useEffect(() => {
    if (lineageData) {
      const normalized = normalizeToReactFlow(lineageData);
      setData(normalized);
    }
  }, [lineageData]);

  const handleNodeClick = (nodeId: string, node: ReactFlowNode) => {
    setSelectedNode(selectedNode === nodeId ? null : nodeId);

    // Call React Flow compatible callback if provided
    if (onNodeClick) {
      const syntheticEvent = {
        preventDefault: () => {},
        stopPropagation: () => {},
      } as React.MouseEvent;
      onNodeClick(syntheticEvent, node);
    }
  };

  // Calculate levels automatically based on parent-child relationships
  const calculateLevels = (nodes: ReactFlowNode[]): ReactFlowNode[] => {
    const nodeMap = new Map<string, ReactFlowNode>();
    const visited = new Set<string>();

    // Create a map for quick lookup
    nodes.forEach((node) => {
      nodeMap.set(node.id, {
        ...node,
        data: { ...node.data, level: 0 },
      });
    });

    // Function to recursively calculate levels
    const calculateNodeLevel = (nodeId: string): number => {
      if (visited.has(nodeId)) {
        // Circular dependency detected, return current level
        return nodeMap.get(nodeId)?.data.level || 0;
      }

      visited.add(nodeId);
      const node = nodeMap.get(nodeId);

      if (!node) return 0;

      if (!node.data.parentId) {
        // Root node
        node.data.level = 0;
        return 0;
      }

      // Calculate parent level first, then set this node's level
      const parentLevel = calculateNodeLevel(node.data.parentId);
      node.data.level = parentLevel + 1;

      return node.data.level;
    };

    // Calculate levels for all nodes
    nodes.forEach((node) => {
      if (!visited.has(node.id)) {
        calculateNodeLevel(node.id);
      }
    });

    return Array.from(nodeMap.values());
  };

  // Calculate layout positions dynamically (React Flow compatible)
  const calculateLayout = (nodes: ReactFlowNode[]) => {
    // First, calculate levels for all nodes
    const nodesWithLevels = calculateLevels(nodes);

    const levels: { [key: number]: ReactFlowNode[] } = {};

    // Group nodes by level
    nodesWithLevels.forEach((node) => {
      const level = node.data.level || 0;
      if (!levels[level]) {
        levels[level] = [];
      }
      levels[level].push(node);
    });

    const baseY = 50;
    const levelHeight = 120;
    const baseX = 50;
    const nodeWidth = 200;

    return nodesWithLevels.map((node) => {
      const level = node.data.level || 0;
      const levelNodes = levels[level];
      const nodeIndex = levelNodes.indexOf(node);
      const totalNodesInLevel = levelNodes.length;

      return {
        ...node,
        position: {
          x: baseX + level * (nodeWidth + 100),
          y:
            baseY +
            nodeIndex * levelHeight -
            (totalNodesInLevel * levelHeight) / 2,
        },
      };
    });
  };

  // Build connections between nodes (React Flow compatible)
  const buildConnections = (nodes: ReactFlowNode[], edges: ReactFlowEdge[]) => {
    return edges.map((edge) => {
      const sourceNode = nodes.find((n) => n.id === edge.source);
      const targetNode = nodes.find((n) => n.id === edge.target);

      return {
        ...edge,
        sourceNode,
        targetNode,
      };
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse"></div>
          <span className="text-gray-600 dark:text-gray-400">
            Loading lineage data...
          </span>
        </div>
      </div>
    );
  }

  if (!data || !data.nodes || data.nodes.length === 0) {
    return (
      <div className="flex items-center justify-center p-8 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="text-center">
          <Database className="w-12 h-12 text-gray-400 mx-auto mb-2" />
          <span className="text-gray-600 dark:text-gray-400">
            No lineage data available
          </span>
        </div>
      </div>
    );
  }

  const layoutNodes = calculateLayout(data.nodes);
  const enhancedConnections = buildConnections(layoutNodes, data.edges);

  return (
    <div className="w-full bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-2">
          <GitBranch className="w-5 h-5 text-blue-500" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            {title}
          </h3>
        </div>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          {data.nodes.length} nodes, {data.edges.length} connections
        </div>
      </div>

      {/* React Flow Compatible Metadata */}
      <div
        className="hidden"
        data-react-flow-compatible="true"
        data-fit-view={fitView}
      >
        {/* This div contains metadata for future React Flow migration */}
        <span data-node-types={JSON.stringify(Object.keys({}))}></span>
        <span data-edge-types={JSON.stringify(Object.keys({}))}></span>
      </div>

      {/* Lineage Visualization */}
      <div className="p-6">
        <div
          className="relative overflow-x-auto"
          style={{ minHeight: "400px" }}
        >
          <svg
            width="100%"
            height="400"
            viewBox="0 0 1200 400"
            className="border border-gray-100 dark:border-gray-700 rounded"
          >
            {/* Background pattern */}
            <defs>
              <pattern
                id="grid"
                width="20"
                height="20"
                patternUnits="userSpaceOnUse"
              >
                <path
                  d="M 20 0 L 0 0 0 20"
                  fill="none"
                  stroke="#f1f5f9"
                  strokeWidth="0.5"
                />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />

            {/* Connections/Edges */}
            {enhancedConnections.map((conn, index) => {
              if (!conn.sourceNode?.position || !conn.targetNode?.position)
                return null;

              const x1 = conn.sourceNode.position.x + 100; // Center of source node
              const y1 = conn.sourceNode.position.y + 200 + 20; // Bottom of source node
              const x2 = conn.targetNode.position.x + 100; // Center of target node
              const y2 = conn.targetNode.position.y + 200; // Top of target node

              const handleEdgeClick = () => {
                if (onEdgeClick) {
                  const syntheticEvent = {
                    preventDefault: () => {},
                    stopPropagation: () => {},
                  } as React.MouseEvent;
                  onEdgeClick(syntheticEvent, conn);
                }
              };

              return (
                <g
                  key={`edge-${conn.id || index}`}
                  onClick={handleEdgeClick}
                  className="cursor-pointer"
                >
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="#6b7280"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                  {conn.data?.transformation && (
                    <text
                      x={(x1 + x2) / 2}
                      y={(y1 + y2) / 2}
                      textAnchor="middle"
                      className="text-xs fill-gray-500"
                    >
                      {conn.data.transformation}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Arrow marker definition */}
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="7"
                refX="9"
                refY="3.5"
                orient="auto"
              >
                <polygon points="0 0, 10 3.5, 0 7" fill="#6b7280" />
              </marker>
            </defs>

            {/* Nodes */}
            {layoutNodes.map((node) => {
              if (!node.position) return null;

              const isTable = node.data.nodeType === "table";
              const isSelected = selectedNode === node.id;
              const x = node.position.x;
              const y = node.position.y + 200; // Offset for better positioning

              return (
                <g
                  key={node.id}
                  transform={`translate(${x}, ${y})`}
                  onClick={() => handleNodeClick(node.id, node)}
                  className="cursor-pointer"
                  data-node-id={node.id}
                  data-node-type={node.type}
                >
                  {/* Node background */}
                  <rect
                    width="200"
                    height="40"
                    rx="8"
                    fill={
                      isSelected ? "#3b82f6" : isTable ? "#f8fafc" : "#f1f5f9"
                    }
                    stroke={
                      isSelected ? "#1d4ed8" : isTable ? "#cbd5e1" : "#94a3b8"
                    }
                    strokeWidth="2"
                    className="transition-all duration-200 hover:shadow-lg"
                  />

                  {/* Node icon */}
                  {isTable ? (
                    <rect
                      x="8"
                      y="8"
                      width="24"
                      height="24"
                      rx="2"
                      fill={isSelected ? "white" : "#2563eb"}
                    />
                  ) : (
                    <circle
                      cx="20"
                      cy="20"
                      r="12"
                      fill={isSelected ? "white" : "#059669"}
                    />
                  )}

                  {/* Node text */}
                  <text
                    x="40"
                    y="25"
                    className={`text-sm font-medium ${
                      isSelected ? "fill-white" : "fill-gray-900"
                    }`}
                  >
                    {node.data.label && node.data.label.length > 20
                      ? `${node.data.label.substring(0, 20)}...`
                      : node.data.label}
                  </text>

                  {/* Node type badge */}
                  <rect
                    x="160"
                    y="4"
                    width="36"
                    height="16"
                    rx="8"
                    fill={isTable ? "#dbeafe" : "#dcfce7"}
                  />
                  <text
                    x="178"
                    y="14"
                    textAnchor="middle"
                    className={`text-xs font-medium ${
                      isTable ? "fill-blue-700" : "fill-green-700"
                    }`}
                  >
                    {isTable ? "TBL" : "COL"}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Legend */}
        <div className="mt-4 flex items-center justify-center space-x-8 text-sm text-gray-600 dark:text-gray-400">
          <div className="flex items-center space-x-2">
            <Square className="w-4 h-4 text-blue-600" />
            <span>Table</span>
          </div>
          <div className="flex items-center space-x-2">
            <Circle className="w-4 h-4 text-green-600" />
            <span>Column</span>
          </div>
          <div className="flex items-center space-x-2">
            <ArrowRight className="w-4 h-4 text-gray-500" />
            <span>Data Flow</span>
          </div>
        </div>

        {/* Selected Node Details */}
        {selectedNode && (
          <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">
              Node Details
            </h4>
            {(() => {
              const node = layoutNodes.find((n) => n.id === selectedNode);
              if (!node) return null;

              return (
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="font-medium">ID:</span> {node.id}
                  </div>
                  <div>
                    <span className="font-medium">Name:</span> {node.data.label}
                  </div>
                  <div>
                    <span className="font-medium">Type:</span>{" "}
                    {node.data.nodeType}
                  </div>
                  {node.data.parentId && (
                    <div>
                      <span className="font-medium">Parent:</span>{" "}
                      {node.data.parentId}
                    </div>
                  )}
                  <div>
                    <span className="font-medium">Level:</span>{" "}
                    {node.data.level || 0}
                  </div>
                  <div>
                    <span className="font-medium">React Flow Type:</span>{" "}
                    {node.type}
                  </div>
                  {node.data.originalId && (
                    <div>
                      <span className="font-medium">Original ID:</span>{" "}
                      {node.data.originalId}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
