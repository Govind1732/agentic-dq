import { useState, useCallback } from "react";

interface SpeechRecognitionHook {
  isRecording: boolean;
  startRecording: (onResult: (transcript: string) => void) => void;
  stopRecording: () => void;
}

export function useSpeechRecognition(): SpeechRecognitionHook {
  const [isRecording, setIsRecording] = useState(false);

  const startRecording = useCallback(
    (onResult: (transcript: string) => void) => {
      try {
        if (
          "webkitSpeechRecognition" in window ||
          "SpeechRecognition" in window
        ) {
          const SpeechRecognition =
            (window as Record<string, unknown>).SpeechRecognition ||
            (window as Record<string, unknown>).webkitSpeechRecognition;

          if (SpeechRecognition) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const recognition = new (SpeechRecognition as any)();

            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = "en-US";

            recognition.onstart = () => {
              setIsRecording(true);
            };

            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            recognition.onresult = (event: any) => {
              const transcript = event.results[0][0].transcript;
              onResult(transcript);
            };

            recognition.onend = () => {
              setIsRecording(false);
            };

            recognition.onerror = () => {
              setIsRecording(false);
            };

            recognition.start();
          }
        }
      } catch (error) {
        console.error("Speech recognition error:", error);
        setIsRecording(false);
      }
    },
    []
  );

  const stopRecording = useCallback(() => {
    setIsRecording(false);
  }, []);

  return {
    isRecording,
    startRecording,
    stopRecording,
  };
}
