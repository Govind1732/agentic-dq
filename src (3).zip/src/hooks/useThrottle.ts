import { useState, useCallback } from "react";

export const useThrottle = (delay: number = 1000) => {
  const [lastExecuted, setLastExecuted] = useState(0);

  const throttle = useCallback((callback: () => void) => {
    const now = Date.now();
    if (now - lastExecuted >= delay) {
      setLastExecuted(now);
      callback();
      return true;
    }
    return false;
  }, [delay, lastExecuted]);

  const canExecute = useCallback(() => {
    return Date.now() - lastExecuted >= delay;
  }, [delay, lastExecuted]);

  return { throttle, canExecute };
};
