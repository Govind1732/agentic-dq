import { useState, useCallback, useRef } from "react";

interface UseThrottleReturn {
  throttle: (fn: () => void) => boolean;
  canExecute: () => boolean;
}

export function useThrottle(delay: number): UseThrottleReturn {
  const [lastExecuted, setLastExecuted] = useState<number>(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const canExecute = useCallback(() => {
    const now = Date.now();
    return now - lastExecuted >= delay;
  }, [lastExecuted, delay]);

  const throttle = useCallback(
    (fn: () => void): boolean => {
      const now = Date.now();

      if (now - lastExecuted >= delay) {
        setLastExecuted(now);
        fn();
        return true;
      }

      // Clear existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      // Set new timeout for remaining time
      const remaining = delay - (now - lastExecuted);
      timeoutRef.current = setTimeout(() => {
        setLastExecuted(Date.now());
        fn();
      }, remaining);

      return false;
    },
    [lastExecuted, delay]
  );

  return { throttle, canExecute };
}
