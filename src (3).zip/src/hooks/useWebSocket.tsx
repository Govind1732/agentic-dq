import { useEffect, useState, useCallback } from "react";
import { io, Socket } from "socket.io-client";
import config from "../config/environment";

interface RCAData {
  failed_column: string;
  failed_table: string;
  validation_query: string;
  expected_value: number;
  expected_std_dev: number;
  actual_value: number;
  sd_threshold: number;
  agent_input: string;
}

interface UseWebSocketReturn {
  socket: Socket | null;
  isConnected: boolean;
  sendMessage: (conversationId: string, message: string) => void;
  startRCAProcess: (conversationId: string, rcaData: RCAData) => void;
  terminateProcess: () => void;
  createNewConversation: (title: string, type: "chat" | "rca") => void;
  selectConversation: (conversationId: string) => void;
  requestConversations: () => void;
}

export function useWebSocket(): UseWebSocketReturn {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  const sendMessage = useCallback(
    (conversationId: string, message: string) => {
      if (socket && isConnected) {
        socket.emit("send_chat_message", { conversationId, message });
      }
    },
    [socket, isConnected]
  );

  const startRCAProcess = useCallback(
    (conversationId: string, rcaData: RCAData) => {
      if (socket && isConnected) {
        console.log("Starting RCA process with data:", rcaData);
        socket.emit("start_rca", { conversationId, data: rcaData });
      }
    },
    [socket, isConnected]
  );

  const terminateProcess = useCallback(() => {
    if (socket && isConnected) {
      socket.emit("terminate_process");
    }
  }, [socket, isConnected]);

  const createNewConversation = useCallback(
    (title: string, type: "chat" | "rca" = "chat") => {
      if (socket && isConnected) {
        socket.emit("create_new_conversation", { title, type });
      }
    },
    [socket, isConnected]
  );

  const selectConversation = useCallback(
    (conversationId: string) => {
      if (socket && isConnected) {
        socket.emit("select_conversation", { conversationId });
      }
    },
    [socket, isConnected]
  );

  const requestConversations = useCallback(() => {
    if (socket && isConnected) {
      console.log("📡 Emitting get_conversations to server");
      socket.emit("get_conversations");
    }
  }, [socket, isConnected]);

  useEffect(() => {
    const newSocket = io(config.websocketUrl, {
      transports: ["polling", "websocket"],
      autoConnect: true,
    });

    newSocket.on("connect", () => {
      console.log("✅ Connected to WebSocket");
      setSocket(newSocket);
      setIsConnected(true);
    });

    newSocket.on("disconnect", () => {
      console.log("❌ Disconnected from WebSocket");
      setIsConnected(false);
    });

    newSocket.on("connect_error", (error) => {
      console.error("🔴 Connection error:", error);
      setIsConnected(false);
    });

    return () => {
      newSocket.removeAllListeners();
      newSocket.disconnect();
    };
  }, []);

  return {
    socket,
    isConnected,
    sendMessage,
    startRCAProcess,
    terminateProcess,
    createNewConversation,
    selectConversation,
    requestConversations,
  };
}
