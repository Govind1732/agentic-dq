export interface Message {
  id: string;
  content: string;
  status?: 'progress' | 'static';
  role: 'user' | 'bot';
  timestamp: string;
  isJson?: boolean;
  type: 'normal' | 'stepper';
  stepNumber?: number;
  stepTitle?: string;
  stepContent?: string;
  stepComponent?: string;
  lineageData?: Record<string, unknown>;
  stepData?: Record<string, unknown>;
  sample_input?: Record<string, unknown>;
  feedback_options?: string[];
  extension_questions?: string[];
}

export interface Conversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  messages: Message[];
  type: 'chat' | 'rca';
}

export const MESSAGE_TYPES = {
  BOT_INTRODUCTION: "bot_introduction",
  STEP: "step",
  NODE_RESPONSE: "node_response",
  MESSAGE: "message",
  FINAL: "final_response",
  RCA_PROGRESS: "rca_progress",
  RCA_RESULT: "rca_result",
  RCA_TABLE: "rca_table",
  ERROR: "error",
  STEP_TITLE: "step_title",
} as const;

export interface ProgressStep {
  step: string;
  status: 'started' | 'completed' | 'failed';
  details: Record<string, unknown>;
  timestamp: string;
}

export interface AnalysisResult {
  id: number;
  layer: string;
  table: string;
  column: string;
  sql_query: string;
  reasoning: string;
  inference: string;
  timestamp: string;
}

export interface TableData {
  id: number;
  title: string;
  data: unknown[];
  timestamp: string;
}

export interface LineageNode {
  id: string;
  table: string;
  column: string;
  step: number;
  status: 'checking' | 'completed' | 'failed' | 'deviation' | 'normal';
  value?: number;
  expectedValue?: number;
  deviationPercentage?: number;
}

export interface LineageEdge {
  from: string;
  to: string;
  transformation?: string;
}

export interface FlowDiagramData {
  nodes: LineageNode[];
  edges: LineageEdge[];
  currentStep: number;
}

export interface RCAData {
  failed_column: string;
  failed_table: string;
  validation_query: string;
  expected_value: number;
  expected_std_dev: number;
  actual_value: number;
  sd_threshold: number;
  agent_input: string;
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  sidebarOpen: boolean;
  isProcessing: boolean;
  progressSteps: ProgressStep[];
  analysisResults: AnalysisResult[];
  tableData: TableData[];
  finalReport: unknown | null;
  currentStep: string;
  flowDiagramData?: FlowDiagramData;
  conversations: Conversation[];
  currentConversationId: string | null;
}