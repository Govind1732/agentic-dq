import { useReducer, useEffect, useRef } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import InputBar from "./components/InputBar";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { useWebSocket } from "./hooks/useWebSocket";
import { appReducer, initialState } from "./reducers/appReducer";
import type { Message } from "./types";
import { generateId } from "./utils";
import { MESSAGE_TYPES } from "./types";

function App() {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const { socket, isConnected, sendMessage } = useWebSocket();
  const initializedRef = useRef(false);

  // Initialize with a default conversation
  useEffect(() => {
    if (!initializedRef.current && state.conversations.length === 0) {
      initializedRef.current = true;

      const introMessage: Message = {
        id: generateId(),
        type: MESSAGE_TYPES.BOT_INTRODUCTION,
        content: `Hello! 👋\nI can help you find the root cause of data quality issues using AI analysis.\n\nDescribe your issue or share details to get started.`,
        role: "assistant",
        timestamp: new Date(),
        sample_input: {
          failed_table: "example_table",
          failed_column: "column_name",
          db_type: "GCP",
        },
      };

      dispatch({ type: "NEW_CONVERSATION" });
      dispatch({ type: "ADD_MESSAGE", payload: introMessage });
    }
  }, [state.conversations.length]);

  // WebSocket message handler
  const handleMessage = (data: unknown) => {
    if (data && typeof data === "object" && "type" in data) {
      const messageData = data as Record<string, unknown>;

      if (messageData.type === "process_step") {
        const stepMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Processing step...",
          role: "assistant",
          type: MESSAGE_TYPES.STEP,
          timestamp: new Date(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
      }

      if (messageData.type === "final_response") {
        const finalMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Analysis complete.",
          role: "assistant",
          type: MESSAGE_TYPES.FINAL,
          timestamp: new Date(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: finalMessage });
        dispatch({ type: "SET_LOADING", payload: false });
      }
    }
  };

  // Set up WebSocket listeners
  useEffect(() => {
    if (socket) {
      socket.on("process_step", handleMessage);
      socket.on("final_response", handleMessage);
      return () => {
        socket.off("process_step", handleMessage);
        socket.off("final_response", handleMessage);
      };
    }
  }, [socket]);

  const handleSendMessage = (message: string) => {
    const userMessage: Message = {
      id: generateId(),
      content: message,
      role: "user",
      timestamp: new Date(),
    };

    dispatch({ type: "ADD_MESSAGE", payload: userMessage });
    dispatch({ type: "SET_LOADING", payload: true });

    if (isConnected) {
      sendMessage({ message });
    }
  };

  const handleSampleInput = (sampleData: unknown) => {
    if (typeof sampleData === "object" && sampleData !== null) {
      const message = JSON.stringify(sampleData, null, 2);
      handleSendMessage(message);
    }
  };

  const handleFeedback = (feedback: string) => {
    console.log("User feedback:", feedback);
  };

  const handleExtensionQuestion = (question: string) => {
    handleSendMessage(question);
  };

  const handleNewChat = () => {
    dispatch({ type: "NEW_CONVERSATION" });
  };

  const handleSelectConversation = () => {
    handleNewChat();
  };

  const handleSidebarHover = (isHovering: boolean) => {
    dispatch({ type: "SET_SIDEBAR_HOVER", payload: isHovering });
  };

  const handleToggleDarkMode = () => {
    dispatch({ type: "TOGGLE_DARK_MODE" });
  };

  const handleToggleSidebar = () => {
    dispatch({ type: "TOGGLE_SIDEBAR" });
  };

  const currentConversation = state.conversations.find(
    (conv) => conv.id === state.activeConversationId
  );

  return (
    <ErrorBoundary>
      <div
        className={`h-screen flex overflow-hidden ${
          state.darkMode ? "dark" : ""
        }`}
      >
        <Sidebar
          conversations={state.conversations}
          currentConversationId={state.activeConversationId}
          onNewChat={handleNewChat}
          onSelectConversation={handleSelectConversation}
          isOpen={state.sidebarOpen}
          onToggle={handleToggleSidebar}
          onHover={handleSidebarHover}
          darkMode={state.darkMode}
          onToggleDarkMode={handleToggleDarkMode}
        />

        <div className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900">
          <div className="flex-1 flex flex-col">
            <ChatWindow
              messages={currentConversation?.messages || []}
              isLoading={state.isLoading}
              onSampleInput={handleSampleInput}
              onFeedback={handleFeedback}
              onExtensionQuestion={handleExtensionQuestion}
            />

            <InputBar
              onSendMessage={handleSendMessage}
              isLoading={state.isLoading}
            />
          </div>
        </div>

        {state.sidebarHover && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-10 lg:hidden" />
        )}
      </div>
    </ErrorBoundary>
  );
}

export default App;

export interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onNewChat: () => void;
  onSelectConversation: () => void;
  isOpen: boolean;
  onToggle: () => void;
  onHover: (isHovering: boolean) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}
