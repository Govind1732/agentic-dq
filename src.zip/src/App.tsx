import { useReducer, useEffect, useRef } from "react";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import InputBar from "./components/InputBar";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { useWebSocket } from "./hooks/useWebSocket";
import { appReducer, initialState } from "./reducers/appReducer";
import type { Message } from "./types";
import { generateId } from "./utils";
import { MESSAGE_TYPES } from "./types";

function App() {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const { socket, isConnected, sendMessage } = useWebSocket();

  // WebSocket message handler
  const handleMessage = (data: unknown) => {
    if (data && typeof data === "object" && "type" in data) {
      const messageData = data as Record<string, unknown>;

      if (messageData.type === "step_result") {
        // Handle new 3-step workflow results
        const stepMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Step completed...",
          role: "assistant",
          type: MESSAGE_TYPES.STEP,
          timestamp: new Date().toISOString(),
          stepNumber: messageData.step_number as number,
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
      } else if (messageData.type === "process_step") {
        const stepMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Processing step...",
          role: "assistant",
          type: MESSAGE_TYPES.STEP,
          timestamp: new Date().toISOString(),
          stepNumber: messageData.step_number as number,
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: stepMessage });
      } else if (messageData.type === "node_response") {
        // Handle real-time node responses
        const nodeMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Node completed...",
          role: "assistant",
          type: MESSAGE_TYPES.NODE_RESPONSE,
          timestamp: new Date().toISOString(),
          stepTitle: messageData.title as string,
          stepData: messageData.data as Record<string, unknown>,
        };
        dispatch({ type: "ADD_MESSAGE", payload: nodeMessage });
      } else if (messageData.type === "final_response") {
        const finalMessage: Message = {
          id: generateId(),
          content: (messageData.content as string) || "Analysis complete.",
          role: "assistant",
          type: MESSAGE_TYPES.FINAL,
          timestamp: new Date().toISOString(),
        };
        dispatch({ type: "ADD_MESSAGE", payload: finalMessage });
        dispatch({ type: "SET_LOADING", payload: false });
      }
    }
  };

  // Set up WebSocket listeners
  useEffect(() => {
    if (socket) {
      socket.on("process_step", handleMessage);
      socket.on("final_response", handleMessage);
      return () => {
        socket.off("process_step", handleMessage);
        socket.off("final_response", handleMessage);
      };
    }
  }, [socket]);

  const handleSendMessage = (message: string) => {
    const userMessage: Message = {
      id: generateId(),
      content: message,
      role: "user",
      timestamp: new Date().toISOString(),
    };

    dispatch({ type: "ADD_MESSAGE", payload: userMessage });
    dispatch({ type: "SET_LOADING", payload: true });

    if (isConnected) {
      console.log("Sending user message:", userMessage);
      sendMessage({ userMessage });
    }
  };

  const handleNewChat = () => {};

  const handleToggleSidebar = () => {
    dispatch({ type: "TOGGLE_SIDEBAR" });
  };

  return (
    <ErrorBoundary>
      <div className="h-screen flex">
        <Sidebar
          onNewChat={handleNewChat}
          isOpen={state.sidebarOpen}
          onToggle={handleToggleSidebar}
        />

        <main className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900">
          <ChatWindow messages={state.messages} isLoading={state.isLoading} />
          <InputBar
            onSendMessage={handleSendMessage}
            isLoading={state.isLoading}
          />
        </main>
      </div>
    </ErrorBoundary>
  );
}

export default App;
