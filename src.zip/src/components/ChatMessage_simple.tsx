import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { Bot, User, Copy, Check, Play } from "lucide-react";
import type { Message } from "../types";
import { MESSAGE_TYPES } from "../types";

interface ChatMessageProps {
  message: Message;
  onSampleInput?: (sampleData: unknown) => void;
  onFeedback?: (feedback: string) => void;
  onExtensionQuestion?: (question: string) => void;
}

const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  onSampleInput,
  onFeedback,
  onExtensionQuestion,
}) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === "user";

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error("Failed to copy:", error);
    }
  };

  const handleSampleInput = () => {
    if (message.sample_input && onSampleInput) {
      onSampleInput(message.sample_input);
    }
  };

  return (
    <div className={`flex gap-4 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="flex-shrink-0">
          <div className="w-8 h-8 bg-gray-800 dark:bg-gray-600 text-white rounded-lg flex items-center justify-center">
            <Bot className="w-4 h-4" />
          </div>
        </div>
      )}

      <div className={`max-w-3xl ${isUser ? "order-first" : ""}`}>
        <div
          className={`
            rounded-lg px-4 py-3 ${
              isUser
                ? "bg-gray-900 dark:bg-gray-700 text-white ml-auto"
                : "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100"
            }
          `}
        >
          <div className="prose prose-sm max-w-none dark:prose-invert">
            <div className="text-sm leading-relaxed">
              <ReactMarkdown>{message.content}</ReactMarkdown>
            </div>
          </div>

          {/* Sample input button for intro message */}
          {message.type === MESSAGE_TYPES.BOT_INTRODUCTION &&
            message.sample_input && (
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                <button
                  onClick={handleSampleInput}
                  className="w-full px-4 py-3 rounded-lg text-sm bg-gray-800 dark:bg-gray-600 text-white hover:bg-gray-700 dark:hover:bg-gray-500 transition-colors flex items-center gap-2"
                >
                  <Play className="w-4 h-4" />
                  Try this example
                </button>
              </div>
            )}

          {/* Feedback options */}
          {message.feedback_options && message.feedback_options.length > 0 && (
            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                Was this helpful?
              </p>
              <div className="flex gap-2">
                {message.feedback_options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => onFeedback?.(option)}
                    className="px-3 py-1.5 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 dark:text-gray-200 transition-colors"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Extension questions */}
          {message.extension_questions &&
            message.extension_questions.length > 0 && (
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  You might also ask:
                </p>
                <div className="space-y-2">
                  {message.extension_questions.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => onExtensionQuestion?.(question)}
                      className="block w-full text-left px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 dark:text-gray-200 transition-colors"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}
        </div>

        {/* Message actions */}
        <div className="flex items-center gap-2 mt-2">
          <span className="text-xs text-gray-500 dark:text-gray-400">
            {message.timestamp.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </span>

          {!isUser && (
            <button
              onClick={handleCopy}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-1 rounded transition-colors"
              title="Copy message"
            >
              {copied ? (
                <Check className="w-3 h-3" />
              ) : (
                <Copy className="w-3 h-3" />
              )}
            </button>
          )}
        </div>
      </div>

      {isUser && (
        <div className="flex-shrink-0">
          <div className="w-8 h-8 bg-gray-600 dark:bg-gray-500 text-white rounded-lg flex items-center justify-center">
            <User className="w-4 h-4" />
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
