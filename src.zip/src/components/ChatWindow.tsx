import React, { useEffect, useRef } from "react";
import type { Message } from "../types";

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  onSampleInput?: (sampleData: unknown) => void;
  onFeedback?: (feedback: string) => void;
  onExtensionQuestion?: (question: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
  return (
    <>
      {messages.map((message) => (
        <div key={message.id}>
          <p className="text-gray-800 dark:text-gray-200">{message.content}</p>
        </div>
      ))}
    </>
  );
};

export default ChatWindow;
