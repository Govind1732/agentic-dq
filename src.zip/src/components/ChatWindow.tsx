// import React, { useEffect, useRef, useState } from "react";
// import {
//   Bot,
//   User,
//   CheckCircle,
//   AlertCircle,
//   Clock,
//   Activity,
//   FileText,
//   Download,
//   ArrowDown,
//   Database,
//   TrendingUp,
//   TrendingDown,
//   GitBranch,
//   ThumbsUp,
//   ThumbsDown,
// } from "lucide-react";
// import type {
//   Message,
//   ProgressStep,
//   TableData,
//   FlowDiagramData,
//   LineageNode,
// } from "../types";

// interface ChatWindowProps {
//   messages: Message[];
//   isLoading: boolean;
//   isProcessing?: boolean;
//   progressSteps?: ProgressStep[];
//   tableData?: TableData[];
//   finalReport?: unknown | null;
//   currentStep?: string;
//   flowDiagramData?: FlowDiagramData;
//   onSampleInput?: (sampleData: unknown) => void;
//   onFeedback?: (feedback: string) => void;
//   onExtensionQuestion?: (question: string) => void;
// }

// // Flow Diagram Component matching the Figma design
// const FlowDiagram: React.FC<{ data: FlowDiagramData }> = ({ data }) => {
//   const { nodes, currentStep } = data;

//   const getStatusIcon = (status: LineageNode["status"]) => {
//     switch (status) {
//       case "checking":
//         return <Clock className="w-4 h-4 text-gray-600" />;
//       case "completed":
//         return <CheckCircle className="w-4 h-4 text-gray-600" />;
//       case "failed":
//         return <AlertCircle className="w-4 h-4 text-gray-600" />;
//       case "deviation":
//         return <TrendingDown className="w-4 h-4 text-gray-600" />;
//       case "normal":
//         return <TrendingUp className="w-4 h-4 text-gray-600" />;
//       default:
//         return <Database className="w-4 h-4 text-gray-500" />;
//     }
//   };

//   const getStatusColor = (status: LineageNode["status"]) => {
//     switch (status) {
//       case "checking":
//         return "border-gray-300 bg-gray-100 dark:bg-gray-800";
//       case "completed":
//         return "border-gray-300 bg-gray-100 dark:bg-gray-800";
//       case "failed":
//         return "border-gray-300 bg-gray-100 dark:bg-gray-800";
//       case "deviation":
//         return "border-gray-300 bg-gray-100 dark:bg-gray-800";
//       case "normal":
//         return "border-gray-300 bg-gray-100 dark:bg-gray-800";
//       default:
//         return "border-gray-300 bg-gray-50 dark:bg-gray-700";
//     }
//   };

//   return (
//     <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 mb-4">
//       <h3 className="text-lg font-semibold mb-4 flex items-center">
//         <GitBranch className="w-5 h-5 mr-2 text-gray-600" />
//         Data Lineage Flow Analysis
//       </h3>

//       <div className="space-y-4">
//         {nodes.map((node, index) => (
//           <div key={node.id} className="flex flex-col items-center">
//             <div
//               className={`
//               relative border-2 rounded-lg p-4 min-w-[200px] text-center transition-all
//               ${getStatusColor(node.status)}
//               ${
//                 node.step === currentStep
//                   ? "ring-2 ring-gray-500 shadow-lg"
//                   : ""
//               }
//             `}
//             >
//               <div className="flex items-center justify-center mb-2">
//                 {getStatusIcon(node.status)}
//                 <span className="ml-2 font-semibold text-sm">L{node.step}</span>
//               </div>
//               <div className="text-sm font-medium text-gray-800 dark:text-gray-200">
//                 {node.table.split(".").pop()}
//               </div>
//               <div className="text-xs text-gray-600 dark:text-gray-400">
//                 {node.column}
//               </div>

//               {node.value !== undefined && (
//                 <div className="mt-2 text-xs space-y-1">
//                   <div className="text-gray-700 dark:text-gray-300">
//                     Value:{" "}
//                     <span className="font-medium">{node.value.toFixed(2)}</span>
//                   </div>
//                   {node.expectedValue && (
//                     <div className="text-gray-600 dark:text-gray-400">
//                       Expected: {node.expectedValue.toFixed(2)}
//                     </div>
//                   )}
//                   {node.deviationPercentage !== undefined && (
//                     <div
//                       className={`font-semibold ${
//                         Math.abs(node.deviationPercentage) > 5
//                           ? "text-gray-800"
//                           : "text-gray-600"
//                       }`}
//                     >
//                       {node.deviationPercentage > 0 ? "+" : ""}
//                       {node.deviationPercentage.toFixed(1)}%
//                     </div>
//                   )}
//                 </div>
//               )}
//             </div>

//             {index < nodes.length - 1 && (
//               <ArrowDown className="w-6 h-6 text-gray-400 my-2" />
//             )}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// // Analysis Step Component styled per Figma design
// const AnalysisStep: React.FC<{
//   title: string;
//   status: "started" | "completed" | "failed";
//   description: string;
//   details?: string;
//   icon?: React.ReactNode;
// }> = ({ title, status, description, details, icon }) => {
//   const getStatusIcon = () => {
//     switch (status) {
//       case "completed":
//         return <CheckCircle className="w-5 h-5 text-gray-600" />;
//       case "failed":
//         return <AlertCircle className="w-5 h-5 text-gray-600" />;
//       default:
//         return <Clock className="w-5 h-5 text-gray-600" />;
//     }
//   };

//   const getStatusEmoji = () => {
//     switch (status) {
//       case "completed":
//         return "✅";
//       case "failed":
//         return "❌";
//       default:
//         return "🔎";
//     }
//   };

//   return (
//     <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 mb-3">
//       <div className="flex items-start space-x-3">
//         <div className="flex-shrink-0">{icon || getStatusIcon()}</div>
//         <div className="flex-grow">
//           <div className="flex items-center space-x-2 mb-2">
//             <span className="text-lg">{getStatusEmoji()}</span>
//             <h4 className="font-semibold text-sm text-gray-800 dark:text-gray-200">
//               {title}
//             </h4>
//             {status === "started" && (
//               <span className="text-xs text-gray-600 bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">
//                 In Progress
//               </span>
//             )}
//           </div>
//           <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
//             {description}
//           </p>
//           {details && (
//             <div className="text-xs text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 p-2 rounded mt-2">
//               <pre className="whitespace-pre-wrap font-mono">{details}</pre>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// const ChatWindow: React.FC<ChatWindowProps> = ({
//   messages,
//   isLoading,
//   progressSteps = [],
//   finalReport = null,
//   currentStep = "",
//   flowDiagramData,
// }) => {
//   const [feedback, setFeedback] = useState<string | null>(null);
//   const messagesEndRef = useRef<HTMLDivElement>(null);
//   const scrollContainerRef = useRef<HTMLDivElement>(null);

//   const scrollToBottom = () => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
//   };

//   const scrollToTop = () => {
//     scrollContainerRef.current?.scrollTo({ top: 0, behavior: "smooth" });
//   };

//   useEffect(() => {
//     scrollToBottom();
//   }, [messages, progressSteps]);

//   // Add keyboard shortcuts for scrolling
//   useEffect(() => {
//     const handleKeyDown = (event: KeyboardEvent) => {
//       if (
//         event.target === scrollContainerRef.current ||
//         scrollContainerRef.current?.contains(event.target as Node)
//       ) {
//         switch (event.key) {
//           case "Home":
//             event.preventDefault();
//             scrollToTop();
//             break;
//           case "End":
//             event.preventDefault();
//             scrollToBottom();
//             break;
//           case "PageUp":
//             event.preventDefault();
//             scrollContainerRef.current?.scrollBy({
//               top: -window.innerHeight * 0.8,
//               behavior: "smooth",
//             });
//             break;
//           case "PageDown":
//             event.preventDefault();
//             scrollContainerRef.current?.scrollBy({
//               top: window.innerHeight * 0.8,
//               behavior: "smooth",
//             });
//             break;
//         }
//       }
//     };

//     document.addEventListener("keydown", handleKeyDown);
//     return () => document.removeEventListener("keydown", handleKeyDown);
//   }, []);

//   const handleFeedback = (type: "positive" | "negative") => {
//     setFeedback(type);
//   };

//   const renderRCAProgress = () => {
//     if (!progressSteps || progressSteps.length === 0) return null;

//     const getCurrentStepDescription = (step: string) => {
//       switch (step) {
//         case "issue_summarizer":
//           return "I got your issue. Let me start analyzing the data to identify the root cause...";
//         case "parse_dq_query":
//           return "Analyzing the data quality query and extracting relevant information...";
//         case "initialize_trace":
//           return "Performing L0 statistical check and initializing the trace analysis...";
//         case "databuck_validation":
//           return "🔎 Looking for deviations in the record count where SMS & MMS < 10 in rev_sum_fact_bl...";
//         case "lineage_traversal":
//           return "Checking for upstream dependencies based on data lineage...";
//         case "final_report":
//           return "Generating consolidated Root Cause Analysis report...";
//         default:
//           return "Processing analysis step...";
//       }
//     };

//     const getStepTitle = (step: string) => {
//       switch (step) {
//         case "issue_summarizer":
//           return "Issue Analysis";
//         case "databuck_validation":
//           return "Deviation Analysis";
//         case "initialize_trace":
//           return "Historical Trend Analysis";
//         case "lineage_traversal":
//           return "Upstream Dependencies Check";
//         case "final_report":
//           return "Final Root Cause Summary";
//         default:
//           return step
//             .replace(/_/g, " ")
//             .replace(/\b\w/g, (l) => l.toUpperCase());
//       }
//     };

//     return (
//       <div className="space-y-4 mb-6">
//         <div className="bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg p-4">
//           <h3 className="text-lg font-semibold mb-3 flex items-center text-gray-800 dark:text-gray-200">
//             <Activity className="w-5 h-5 mr-2" />
//             Root Cause Analysis Progress
//           </h3>

//           {progressSteps.map((step, index) => (
//             <AnalysisStep
//               key={index}
//               title={getStepTitle(step.step)}
//               status={step.status}
//               description={getCurrentStepDescription(step.step)}
//               details={
//                 step.details ? JSON.stringify(step.details, null, 2) : undefined
//               }
//             />
//           ))}
//         </div>

//         {/* Flow Diagram for lineage traversal - shows the table/column flow as requested */}
//         {currentStep === "lineage_traversal" && flowDiagramData && (
//           <FlowDiagram data={flowDiagramData} />
//         )}
//       </div>
//     );
//   };

//   const renderFinalReport = () => {
//     if (!finalReport) return null;

//     return (
//       <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 mb-4">
//         <div className="flex items-center justify-between mb-4">
//           <h3 className="text-lg font-semibold flex items-center">
//             <FileText className="w-5 h-5 mr-2 text-gray-600" />
//             Final Root Cause Summary
//           </h3>
//           <button className="flex items-center space-x-2 px-3 py-1 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg text-sm transition-colors">
//             <Download className="w-4 h-4" />
//             <span>Export Report</span>
//           </button>
//         </div>

//         <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
//           <pre className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
//             {typeof finalReport === "string"
//               ? finalReport
//               : JSON.stringify(finalReport, null, 2)}
//           </pre>
//         </div>

//         {/* Feedback Section - styled per Figma design */}
//         <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
//           <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
//             Was this helpful?
//           </p>
//           <div className="flex items-center space-x-4">
//             <button
//               onClick={() => handleFeedback("positive")}
//               className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
//                 feedback === "positive"
//                   ? "bg-gray-200 text-gray-800 border border-gray-400"
//                   : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-300"
//               }`}
//             >
//               <ThumbsUp className="w-4 h-4" />
//               <span>👍</span>
//             </button>
//             <button
//               onClick={() => handleFeedback("negative")}
//               className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
//                 feedback === "negative"
//                   ? "bg-gray-200 text-gray-800 border border-gray-400"
//                   : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-300"
//               }`}
//             >
//               <ThumbsDown className="w-4 h-4" />
//               <span>👎</span>
//             </button>
//           </div>

//           {feedback === "positive" && (
//             <div className="mt-3 p-3 bg-gray-100 border border-gray-300 rounded-lg">
//               <p className="text-sm text-gray-700">
//                 👍 You have liked it! Thank you for your feedback.
//               </p>
//               <div className="mt-3 space-y-2">
//                 <p className="text-sm font-medium text-gray-800">
//                   Would you like to:
//                 </p>
//                 <div className="flex flex-wrap gap-2">
//                   <button className="px-3 py-1 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded text-sm transition-colors">
//                     Generate Summary Report
//                   </button>
//                   <button className="px-3 py-1 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded text-sm transition-colors">
//                     Start New Issue
//                   </button>
//                   <button className="px-3 py-1 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded text-sm transition-colors">
//                     Export Trace
//                   </button>
//                 </div>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     );
//   };

//   return (
//     <div className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900 min-h-0">
//       {/* Messages */}
//       <div
//         ref={scrollContainerRef}
//         className="flex-1 overflow-y-auto overflow-x-hidden px-4 pt-4 pb-0"
//         style={{
//           minHeight: 0,
//           maxHeight: "100%",
//         }}
//         tabIndex={0}
//       >
//         <div className="max-w-4xl mx-auto space-y-4">
//           {/* RCA Progress - shows step-by-step analysis as per Figma */}
//           {renderRCAProgress()}

//           {/* Regular Messages */}
//           {messages.map((message, index) => {
//             // Skip duplicate step titles that appear consecutively
//             if (
//               message.type === "step_title" &&
//               index > 0 &&
//               messages[index - 1]?.type === "step_title" &&
//               messages[index - 1]?.stepNumber === message.stepNumber &&
//               messages[index - 1]?.content === message.content
//             ) {
//               return null;
//             }

//             return (
//               <div key={message.id} className="w-full">
//                 {message.role === "assistant" ? (
//                   // Bot message - left aligned
//                   <div className="flex justify-start mb-4">
//                     <div className="flex items-start space-x-3 max-w-[85%]">
//                       {message.stepNumber && message.type === "step_title" && (
//                         <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center flex-shrink-0 text-xs text-gray-500 dark:text-gray-400">
//                           {message.stepNumber}
//                         </div>
//                       )}
//                       {/* <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center flex-shrink-0">
//                         <Bot className="w-5 h-5 text-gray-600 dark:text-gray-400" />
//                       </div> */}
//                       {/* <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4"> */}
//                         <p className="text-gray-900 dark:text-gray-100 whitespace-pre-wrap break-words">
//                           {message.content}
//                         </p>
//                       {/* </div> */}
//                     </div>
//                   </div>
//                 ) : (
//                   // User message - right aligned
//                   <div className="flex justify-end mb-4">
//                     <div className="flex items-start space-x-3 max-w-[85%]">
//                       <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-4">
//                         <p className="text-gray-900 dark:text-gray-100 whitespace-pre-wrap break-words">
//                           {message.content}
//                         </p>
//                       </div>
//                       <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center flex-shrink-0">
//                         <User className="w-5 h-5 text-gray-600 dark:text-gray-400" />
//                       </div>
//                     </div>
//                   </div>
//                 )}
//               </div>
//             );
//           })}

//           {/* Final Report */}
//           {renderFinalReport()}

//           {isLoading && (
//             <div className="flex justify-start mb-4">
//               <div className="flex items-start space-x-3 max-w-[85%]">
//                 <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center flex-shrink-0">
//                   <Bot className="w-5 h-5 text-gray-600 dark:text-gray-400" />
//                 </div>
//                 <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
//                   <div className="flex items-center space-x-2">
//                     <div className="flex space-x-1">
//                       <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
//                       <div
//                         className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
//                         style={{ animationDelay: "0.1s" }}
//                       ></div>
//                       <div
//                         className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
//                         style={{ animationDelay: "0.2s" }}
//                       ></div>
//                     </div>
//                     <span className="text-sm text-gray-500">Analyzing...</span>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )}

//           {/* Empty state */}
//           {messages.length === 0 && !isLoading && (
//             <div className="text-center py-12">
//               <Bot className="w-12 h-12 text-gray-400 mx-auto mb-4" />
//               <p className="text-gray-500 dark:text-gray-400 text-lg">
//                 Start a conversation
//               </p>
//               <p className="text-gray-400 dark:text-gray-500 text-sm mt-2">
//                 Type your message below to begin
//               </p>
//             </div>
//           )}
//         </div>
//         <div ref={messagesEndRef} className="pb-4" />
//       </div>
//     </div>
//   );
// };

// export { ChatWindow };
// export default ChatWindow;
export const ChatWindow = () => {
  return (
    <div className="chat-window ml-10">
      <p>I got your issue. Let me start analyzing the data to identify the root cause</p>
      <br/>
      <ol className="relative text-gray-500 border-s border-gray-200 dark:border-gray-700 dark:text-gray-400">
        <li className="mb-10 ms-6">
          <span className="absolute flex items-center justify-center w-8 h-8 bg-green-200 rounded-full -start-4 ring-4 ring-white dark:ring-gray-900 dark:bg-green-900">
            1
          </span>
          <h3 className="font-medium leading-tight">✅ Found Validation Rule for zero-usage cycles within the
rev_sum_fact_bl dataset.</h3>
          <p className="text-sm">
            Step details hereStep details hereStep details hereStep details
            hereStep details hereStep details hereStep details hereStep details
            hereStep details hereStep details here
          </p>
          <p className="text-sm">Step details here</p>
          <p className="text-sm">Step details here</p>
          <p className="text-sm">Step details here</p>
          <p className="text-sm">Step details here</p>
          <p className="text-sm">Step details here</p>
          <p className="text-sm">Step details here</p>
          <p className="text-sm">Step details here</p>
        </li>
        <li className="mb-10 ms-6">
          <span className="absolute flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full -start-4 ring-4 ring-white dark:ring-gray-900 dark:bg-gray-700">
            {/* <svg
              className="w-3.5 h-3.5 text-gray-500 dark:text-gray-400"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="currentColor"
              viewBox="0 0 20 16"
            >
              <path d="M18 0H2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2ZM6.5 3a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM3.014 13.021l.157-.625A3.427 3.427 0 0 1 6.5 9.571a3.426 3.426 0 0 1 3.322 2.805l.159.622-6.967.023ZM16 12h-3a1 1 0 0 1 0-2h3a1 1 0 0 1 0 2Zm0-3h-3a1 1 0 1 1 0-2h3a1 1 0 1 1 0 2Zm0-3h-3a1 1 0 1 1 0-2h3a1 1 0 1 1 0 2Z" />
            </svg> */}
            2
          </span>
          <h3 className="font-medium leading-tight">Account Info</h3>
          <p className="text-sm">Step details here</p>
        </li>
        {false && (
          <li className="mb-10 ms-6">
            <span className="absolute flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full -start-4 ring-4 ring-white dark:ring-gray-900 dark:bg-gray-700">
              <svg
                className="w-3.5 h-3.5 text-gray-500 dark:text-gray-400"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="currentColor"
                viewBox="0 0 18 20"
              >
                <path d="M16 1h-3.278A1.992 1.992 0 0 0 11 0H7a1.993 1.993 0 0 0-1.722 1H2a2 2 0 0 0-2 2v15a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2Zm-3 14H5a1 1 0 0 1 0-2h8a1 1 0 0 1 0 2Zm0-4H5a1 1 0 0 1 0-2h8a1 1 0 1 1 0 2Zm0-5H5a1 1 0 0 1 0-2h2V2h4v2h2a1 1 0 1 1 0 2Z" />
              </svg>
            </span>
            <h3 className="font-medium leading-tight">Review</h3>
            <p className="text-sm">Step details here</p>
          </li>
        )}

        <li className="ms-6">
          <span className="absolute flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full -start-4 ring-4 ring-white dark:ring-gray-900 dark:bg-gray-700">
            <svg
              className="w-3.5 h-3.5 text-gray-500 dark:text-gray-400"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="currentColor"
              viewBox="0 0 18 20"
            >
              <path d="M16 1h-3.278A1.992 1.992 0 0 0 11 0H7a1.993 1.993 0 0 0-1.722 1H2a2 2 0 0 0-2 2v15a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2ZM7 2h4v3H7V2Zm5.7 8.289-3.975 3.857a1 1 0 0 1-1.393 0L5.3 12.182a1.002 1.002 0 1 1 1.4-1.436l1.328 1.289 3.28-3.181a1 1 0 1 1 1.392 1.435Z" />
            </svg>
          </span>
          <h3 className="font-medium leading-tight">Confirmation</h3>
          <p className="text-sm">Step details here</p>
        </li>
      </ol>
    </div>
  );
};
export default ChatWindow;
