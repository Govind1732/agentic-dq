import React, { useState, useRef, useCallback } from "react";
import type { KeyboardEvent } from "react";
import { ArrowUp, Plus, Mic, X } from "lucide-react";

// Types for Speech Recognition API
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  [index: number]: SpeechRecognitionResult;
  length: number;
}

interface SpeechRecognitionResult {
  [index: number]: SpeechRecognitionAlternative;
  length: number;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

interface WebkitSpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives: number;
  onstart: ((this: WebkitSpeechRecognition, ev: Event) => void) | null;
  onend: ((this: WebkitSpeechRecognition, ev: Event) => void) | null;
  onerror: ((this: WebkitSpeechRecognition, ev: Event) => void) | null;
  onresult:
    | ((this: WebkitSpeechRecognition, ev: SpeechRecognitionEvent) => void)
    | null;
  start(): void;
  stop(): void;
}

declare global {
  interface Window {
    SpeechRecognition: new () => WebkitSpeechRecognition;
    webkitSpeechRecognition: new () => WebkitSpeechRecognition;
  }
}

interface InputBarProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  disabled?: boolean;
  placeholder?: string;
}

interface SelectedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  file: File;
}

const InputBar: React.FC<InputBarProps> = ({
  onSendMessage,
  isLoading,
  disabled = false,
  placeholder = "Describe your data quality issue...",
}) => {
  const [message, setMessage] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<SelectedFile[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [lastSentTime, setLastSentTime] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<WebkitSpeechRecognition | null>(null);

  // Throttle constant - minimum time between sends (in ms)
  const SEND_THROTTLE_MS = 1000;

  const handleMicClick = () => {
    if (
      !("webkitSpeechRecognition" in window || "SpeechRecognition" in window)
    ) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }

    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    console.log("recognition", recognition);
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      setMessage((prev) => (prev ? prev + " " + transcript : transcript));
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleSubmit = useCallback(() => {
    if (message.trim() && !isLoading && !disabled) {
      const now = Date.now();

      // Throttle mechanism to prevent rapid-fire requests
      if (now - lastSentTime < SEND_THROTTLE_MS) {
        console.warn("Message sending throttled - please wait");
        return;
      }

      setLastSentTime(now);

      onSendMessage(message.trim());
      setMessage("");
      setSelectedFiles([]);
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    }
  }, [
    message,
    isLoading,
    disabled,
    onSendMessage,
    lastSentTime,
    SEND_THROTTLE_MS,
    setLastSentTime,
  ]);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setMessage(e.target.value);

      // Auto-resize textarea
      const textarea = e.target;
      textarea.style.height = "auto";
      textarea.style.height = Math.min(textarea.scrollHeight, 120) + "px";
    },
    []
  );

  const canSend =
    message.trim() &&
    !isLoading &&
    !disabled &&
    Date.now() - lastSentTime >= SEND_THROTTLE_MS;

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(e.target.files || []);
      if (files.length > 0) {
        const file = files[0];
        const newFile: SelectedFile = {
          id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          type: file.type,
          size: file.size,
          file,
        };
        setSelectedFiles([newFile]); // Only allow one file
      }

      // Reset the input so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    },
    []
  );

  const removeFile = useCallback((fileId: string) => {
    setSelectedFiles((prev) => prev.filter((f) => f.id !== fileId));
  }, []);

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith("image/")) return "🖼️";
    if (type.startsWith("video/")) return "🎥";
    if (type.startsWith("audio/")) return "🎵";
    if (type.includes("json")) return "🗄️";
    if (type.includes("pdf")) return "📄";
    if (type.includes("text")) return "📝";
    return "📎";
  };

  return (
    <div className="fixed left-0 bottom-0 right-0 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-4 z-10">
      <div className="max-w-4xl mx-auto">
        <div className="relative rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 shadow-sm transition-colors focus-within:border-blue-500 dark:focus-within:border-blue-400">
          {/* Selected Files Display */}
          {selectedFiles.length > 0 && (
            <div className="border-b border-gray-200 dark:border-gray-600 px-4 pt-3 pb-2">
              <div className="flex flex-wrap gap-2">
                {selectedFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center gap-2 rounded-lg bg-gray-100 dark:bg-gray-700 px-3 py-2 text-sm"
                  >
                    <span className="text-lg">{getFileIcon(file.type)}</span>
                    <div className="flex min-w-0 flex-col">
                      <span className="max-w-32 truncate text-gray-800 dark:text-gray-200">
                        {file.name}
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {formatFileSize(file.size)}
                      </span>
                    </div>
                    <button
                      onClick={() => removeFile(file.id)}
                      className="text-gray-400 transition-colors hover:text-gray-600 dark:hover:text-gray-200"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 p-3">
            {/* File Upload Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading}
              className="flex-shrink-0 p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors disabled:opacity-50"
              title="Attach file"
            >
              <Plus className="w-5 h-5" />
            </button>

            {/* Textarea Container */}
            <div className="flex-1 relative min-h-[40px]">
              <textarea
                ref={textareaRef}
                value={message}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder={placeholder}
                disabled={disabled}
                rows={1}
                className="w-full px-3 py-2 bg-transparent text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 resize-none outline-none focus:outline-none border-none disabled:opacity-50"
                style={{
                  height: "auto",
                  minHeight: "40px",
                  maxHeight: "120px",
                  border: "none",
                  outline: "none",
                  boxShadow: "none",
                }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = "auto";
                  target.style.height =
                    Math.min(target.scrollHeight, 120) + "px";
                }}
              />
            </div>

            {/* Mic Button */}
            <button
              type="button"
              disabled={isLoading}
              onClick={handleMicClick}
              className={`flex-shrink-0 p-2 rounded-lg transition-colors disabled:opacity-50 ${
                isRecording
                  ? "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400"
                  : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
              }`}
              aria-label={isRecording ? "Stop recording" : "Start recording"}
            >
              <Mic
                className={`h-5 w-5 ${isRecording ? "animate-pulse" : ""}`}
              />
            </button>

            {/* Send Button */}
            <button
              onClick={handleSubmit}
              disabled={!canSend}
              className={`flex-shrink-0 p-2.5 rounded-lg transition-all duration-200 ${
                canSend
                  ? "bg-blue-600 hover:bg-blue-700 text-white shadow-sm hover:shadow-md"
                  : "bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 cursor-not-allowed"
              }`}
              title="Send message"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <ArrowUp className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Hidden File Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".json,text/plain,application/json"
          onChange={handleFileSelect}
          className="hidden"
          multiple={false}
        />
      </div>
    </div>
  );
};

export default InputBar;
