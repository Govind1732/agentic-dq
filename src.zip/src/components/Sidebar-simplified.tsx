import React from "react";
import {
  Plus,
  MessageSquare,
  Settings,
  Moon,
  Sun,
  Trash2,
  Clock,
  TrendingUp,
} from "lucide-react";
import type { Conversation } from "../types";

interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  currentConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  isDarkMode,
  onToggleDarkMode,
}) => {
  const formatTime = (timestamp: Date) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return "Just now";
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else if (diffInHours < 168) {
      return `${Math.floor(diffInHours / 24)}d ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const getConversationPreview = (conversation: Conversation) => {
    if (conversation.messages.length === 0) {
      return "New conversation";
    }
    const lastMessage = conversation.messages[conversation.messages.length - 1];
    return (
      lastMessage.content.slice(0, 60) +
      (lastMessage.content.length > 60 ? "..." : "")
    );
  };

  return (
    <div className="sidebar-modern w-64 h-full flex flex-col border-r border-gray-200 dark:border-gray-700">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                DQ Assistant
              </h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Data Quality Analysis
              </p>
            </div>
          </div>

          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-lg hover:bg-white/50 dark:hover:bg-gray-800/50 transition-colors duration-200"
            title={`Switch to ${isDarkMode ? "light" : "dark"} mode`}
          >
            {isDarkMode ? (
              <Sun className="w-5 h-5 text-yellow-500" />
            ) : (
              <Moon className="w-5 h-5 text-gray-600" />
            )}
          </button>
        </div>

        <button
          onClick={onNewConversation}
          className="btn-primary w-full py-3 rounded-xl flex items-center justify-center gap-2 group"
        >
          <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform duration-200" />
          <span className="font-medium">New Analysis</span>
        </button>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {conversations.length === 0 ? (
            <div className="p-4 text-center text-gray-500 dark:text-gray-400 animate-fade-in">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No conversations yet</p>
              <p className="text-xs mt-1">
                Start your first data quality analysis
              </p>
            </div>
          ) : (
            conversations.map((conversation) => (
              <div
                key={conversation.id}
                className={`
                  group relative p-3 rounded-xl cursor-pointer transition-all duration-200 hover:scale-[1.02]
                  ${
                    currentConversationId === conversation.id
                      ? "bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-200 dark:border-blue-800 shadow-sm"
                      : "hover:bg-gray-100 dark:hover:bg-gray-800/50"
                  }
                `}
                onClick={() => onSelectConversation(conversation.id)}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`
                    w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5
                    ${
                      currentConversationId === conversation.id
                        ? "bg-gradient-to-br from-blue-500 to-purple-600 text-white"
                        : "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400"
                    }
                  `}
                  >
                    <MessageSquare className="w-4 h-4" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3
                      className={`
                      font-medium text-sm mb-1 truncate
                      ${
                        currentConversationId === conversation.id
                          ? "text-blue-900 dark:text-blue-100"
                          : "text-gray-900 dark:text-gray-100"
                      }
                    `}
                    >
                      {conversation.title ||
                        `Analysis ${conversations.indexOf(conversation) + 1}`}
                    </h3>

                    <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 mb-2">
                      {getConversationPreview(conversation)}
                    </p>

                    <div className="flex items-center gap-2 text-xs text-gray-400 dark:text-gray-500">
                      <Clock className="w-3 h-3" />
                      <span>{formatTime(conversation.timestamp)}</span>
                      <span className="ml-auto px-2 py-0.5 bg-gray-100 dark:bg-gray-800 rounded-full">
                        {conversation.messages.length}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Delete button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteConversation(conversation.id);
                  }}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-500 opacity-0 group-hover:opacity-100 transition-all duration-200 hover:scale-110"
                  title="Delete conversation"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50">
        <button
          className="w-full p-3 text-left rounded-xl hover:bg-white dark:hover:bg-gray-800 transition-colors duration-200 group"
          title="Settings"
        >
          <div className="flex items-center gap-3">
            <Settings className="w-5 h-5 text-gray-500 group-hover:text-gray-700 dark:group-hover:text-gray-300 group-hover:rotate-90 transition-all duration-200" />
            <span className="text-sm text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-gray-100">
              Settings
            </span>
          </div>
        </button>

        <div className="mt-2 text-xs text-gray-400 dark:text-gray-500 text-center">
          v1.0.0 • Built with ❤️
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
