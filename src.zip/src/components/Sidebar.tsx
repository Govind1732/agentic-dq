import React, { memo } from "react";
import {
  Plus,
  Menu,
  X,
} from "lucide-react";

interface SidebarProps {
  onNewChat: () => void;
  isOpen: boolean;
  onToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = memo(
  ({
    onNewChat,
    isOpen,
    onToggle,
  }) => {
    return (
      <>
        {/* Mobile overlay */}
        {isOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-25 z-40 md:hidden"
            onClick={onToggle}
          />
        )}

        {/* Mobile toggle button */}
        <button
          onClick={onToggle}
          className="fixed top-4 left-4 z-50 md:hidden bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg p-2 shadow-sm"
        >
          {isOpen ? (
            <X className="w-5 h-5 text-gray-700 dark:text-gray-200" />
          ) : (
            <Menu className="w-5 h-5 text-gray-700 dark:text-gray-200" />
          )}
        </button>

        {/* Sidebar */}
        <div
          className={`
          fixed h-full bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 ease-in-out
          ${
            isOpen
              ? "translate-x-0 w-80 z-50"
              : "-translate-x-full w-0 md:translate-x-0 md:w-16 md:z-10 md:hover:w-80 md:hover:z-50"
          }
        `}
        >
          <div className="flex flex-col h-full">
            {/* Header */}
            <div className="p-2 border-b border-gray-200 dark:border-gray-700">
              <button
                onClick={onNewChat}
                className="w-full bg-gray-900 dark:bg-gray-700 text-white rounded-lg px-4 py-2 flex items-center gap-2 hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors"
              >
                <Plus className="w-4 h-4 flex-shrink-0" />
                <span className={`transition-opacity duration-300 ${isOpen ? "opacity-100" : "opacity-0"}`}>
                  New Chat
                </span>
              </button>
            </div>

            {/* Main content area */}
            <div className="flex-1 overflow-y-auto p-2">
              {isOpen && (
                <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                  <p className="text-sm">Single session chat - use "New Chat" to clear messages</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </>
    );
  }
);

Sidebar.displayName = "Sidebar";

export default Sidebar;
