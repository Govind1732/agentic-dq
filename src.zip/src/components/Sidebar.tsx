import { memo, useState } from "react";
import { Plus, MessageSquare, Brain, Clock } from "lucide-react";
import type { Conversation } from "../types";
import ProfileDropdown from "./ProfileDropdown";

interface SidebarProps {
  onNewChat: () => void;
  conversations?: Conversation[];
  currentConversationId?: string | null;
  onSelectConversation?: (conversationId: string) => void;
}

const Sidebar: React.FC<SidebarProps> = memo(
  ({
    onNewChat,
    conversations = [],
    currentConversationId,
    onSelectConversation,
  }) => {
    const [showProfileDropdown, setShowProfileDropdown] = useState(false);

    const handleProfileClick = () => {
      setShowProfileDropdown(!showProfileDropdown);
    };

    return (
      <>
        {/* Hidden checkbox to control sidebar state */}
        {/* <input type="checkbox" id="sidebar-toggle" className="peer sr-only" /> */}

        {/* Mobile toggle button */}
        {/* <label
        htmlFor="sidebar-toggle"
        className="fixed top-4 left-4 z-50 md:hidden bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg p-2 shadow-sm cursor-pointer"
      >
        <Menu className="w-5 h-5 text-gray-700 dark:text-gray-200 peer-checked:hidden" />
        <X className="w-5 h-5 text-gray-700 dark:text-gray-200 hidden peer-checked:block" />
      </label> */}

        {/* Mobile overlay */}
        {/* <div className="fixed inset-0 bg-black bg-opacity-25 z-40 md:hidden opacity-0 peer-checked:opacity-100 pointer-events-none peer-checked:pointer-events-auto transition-opacity duration-300" /> */}

        {/* Sidebar */}
        <div className="group fixed h-full bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 transition-all z-10 duration-300 ease-in-out md:w-16 md:hover:w-80">
          <div className="flex flex-col h-full">
            {/* Logo - Only visible when sidebar is collapsed */}
            <div className="flex flex-col items-center justify-center min-h-[120px]">
              <div className="md:group-hover:hidden">
                <svg
                  width="60"
                  height="60"
                  viewBox="0 0 100 100"
                  className="transition-opacity duration-300"
                >
                  <defs>
                    <linearGradient
                      id="gradient"
                      x1="0%"
                      y1="0%"
                      x2="0%"
                      y2="100%"
                    >
                      <stop offset="0%" stopColor="#FF1744" />
                      <stop offset="70%" stopColor="#FF1744" />
                      <stop offset="100%" stopColor="#FF9800" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M20 20 L35 20 L50 60 L65 20 L80 20 L60 80 L40 80 Z"
                    fill="url(#gradient)"
                  />
                </svg>
              </div>
            </div>

            {/* New Chat Button */}
            <div className="mt-5 p-2">
              <button
                onClick={onNewChat}
                className="w-full bg-gray-900 dark:bg-gray-700 cursor-pointer text-white rounded-lg px-4 py-2 flex items-center gap-2 hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors"
              >
                <Plus className="w-4 h-4 flex-shrink-0" />
                <span className="hidden md:group-hover:inline-block transition-opacity duration-300">
                  New Chat
                </span>
              </button>
            </div>

            {/* Main content area */}
            <div className="flex-1 overflow-y-auto p-2">
              <div className="hidden md:group-hover:block space-y-2">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 px-2 mb-3">
                  Conversations
                </h3>

                {conversations.length === 0 ? (
                  <div className="p-4 text-center text-gray-500 dark:text-gray-400 text-sm">
                    No conversations yet
                  </div>
                ) : (
                  <div className="space-y-1">
                    {conversations.map((conversation) => (
                      <button
                        key={conversation.id}
                        onClick={() => onSelectConversation?.(conversation.id)}
                        className={`w-full text-left p-3 rounded-lg flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors ${
                          currentConversationId === conversation.id
                            ? "bg-gray-100 dark:bg-gray-800 border-l-2 border-blue-500"
                            : ""
                        }`}
                      >
                        <div className="flex-shrink-0">
                          {conversation.type === "rca" ? (
                            <Brain className="w-4 h-4 text-blue-500" />
                          ) : (
                            <MessageSquare className="w-4 h-4 text-gray-500" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                            {conversation.title}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(
                              conversation.updated_at
                            ).toLocaleDateString()}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
            {/* Profile Button - Bottom */}
            <div className="p-2 border-t border-gray-200 dark:border-gray-700 min-h-[105px] flex items-center relative">
              <button
                onClick={handleProfileClick}
                className="w-full bg-gray-100 dark:bg-gray-800 text-gray-700 hover:cursor-pointer dark:text-gray-200 rounded-lg px-4 py-2 flex justify-center items-center md:group-hover:justify-start gap-4 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                <div className="w-6 h-6 dark:bg-gray-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-xs font-semibold">G</span>
                </div>
                <div className="hidden md:group-hover:flex flex-col justify-start items-start transition-opacity duration-300">
                  <span className="text-sm font-medium">Govind</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    govind@verizon.com
                  </span>
                </div>
              </button>

              <ProfileDropdown
                isOpen={showProfileDropdown}
                onClose={() => setShowProfileDropdown(false)}
                userName="Govind"
                userEmail="govind@verizon.com"
              />
            </div>
          </div>
        </div>
      </>
    );
  }
);

Sidebar.displayName = "Sidebar";

export default Sidebar;
