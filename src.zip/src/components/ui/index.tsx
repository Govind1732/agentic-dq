import React from 'react';
import { Loader2, AlertCircle, CheckCircle, Info } from 'lucide-react';
import { clsx } from 'clsx';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'primary' | 'secondary';
  className?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ 
  size = 'md', 
  variant = 'primary',
  className 
}) => {
  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-6 w-6', 
    lg: 'h-8 w-8'
  };

  const variantClasses = {
    primary: 'text-gray-600 dark:text-gray-400',
    secondary: 'text-gray-400 dark:text-gray-600'
  };

  return (
    <Loader2 
      className={clsx(
        'animate-spin',
        sizeClasses[size],
        variantClasses[variant],
        className
      )} 
    />
  );
};

interface NotificationProps {
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  onClose?: () => void;
  autoClose?: boolean;
  duration?: number;
}

export const Notification: React.FC<NotificationProps> = ({
  type,
  title,
  message,
  onClose,
  autoClose = true,
  duration = 5000
}) => {
  React.useEffect(() => {
    if (autoClose && onClose) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [autoClose, onClose, duration]);

  const icons = {
    success: <CheckCircle className="h-5 w-5 text-gray-600 dark:text-gray-400" />,
    error: <AlertCircle className="h-5 w-5 text-gray-600 dark:text-gray-400" />,
    warning: <AlertCircle className="h-5 w-5 text-gray-600 dark:text-gray-400" />,
    info: <Info className="h-5 w-5 text-gray-600 dark:text-gray-400" />
  };

  const bgColors = {
    success: 'bg-gray-50 border-gray-200 dark:bg-gray-800 dark:border-gray-700',
    error: 'bg-gray-50 border-gray-200 dark:bg-gray-800 dark:border-gray-700',
    warning: 'bg-gray-50 border-gray-200 dark:bg-gray-800 dark:border-gray-700',
    info: 'bg-gray-50 border-gray-200 dark:bg-gray-800 dark:border-gray-700'
  };

  return (
    <div className={clsx(
      'rounded-xl border p-4 shadow-sm backdrop-blur-sm',
      'animate-in slide-in-from-top-2 fade-in duration-300',
      bgColors[type]
    )}>
      <div className="flex items-start gap-3">
        {icons[type]}
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-gray-900 dark:text-gray-100">
            {title}
          </h4>
          {message && (
            <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
              {message}
            </p>
          )}
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
          >
            <span className="sr-only">Close</span>
            ×
          </button>
        )}
      </div>
    </div>
  );
};

interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'rectangular' | 'circular';
}

export const Skeleton: React.FC<SkeletonProps> = ({ 
  className, 
  variant = 'rectangular' 
}) => {
  const baseClasses = 'animate-pulse bg-gray-200 dark:bg-gray-700';
  
  const variantClasses = {
    text: 'h-4 rounded',
    rectangular: 'rounded-lg',
    circular: 'rounded-full'
  };

  return (
    <div 
      className={clsx(
        baseClasses,
        variantClasses[variant],
        className
      )} 
    />
  );
};

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  action,
  className
}) => {
  return (
    <div className={clsx('text-center py-12', className)}>
      {icon && (
        <div className="flex justify-center mb-4 text-gray-400 dark:text-gray-600">
          {icon}
        </div>
      )}
      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
        {title}
      </h3>
      {description && (
        <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-sm mx-auto">
          {description}
        </p>
      )}
      {action}
    </div>
  );
};
