interface AppConfig {
  websocketUrl: string;
}

const config: AppConfig = {
  websocketUrl: import.meta.env.VITE_WEBSOCKET_URL || 'http://localhost:3001',
};

export default config;
