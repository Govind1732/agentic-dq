import { useEffect, useCallback } from 'react';
import type { Conversation } from '../types';
import { storage } from '../utils';

const STORAGE_KEY = 'dq_conversations';
const MAX_STORED_CONVERSATIONS = 50;

interface UseConversationPersistenceProps {
  conversations: Conversation[];
  onLoadConversations: (conversations: Conversation[]) => void;
}

export function useConversationPersistence({ 
  conversations, 
  onLoadConversations 
}: UseConversationPersistenceProps) {
  
  // Load conversations from localStorage on mount
  useEffect(() => {
    const loadConversations = () => {
      try {
        const stored = storage.get<Conversation[]>(STORAGE_KEY);
        if (stored && Array.isArray(stored)) {
          // Validate and parse stored conversations
          const validConversations = stored
            .filter(conv => 
              conv && 
              typeof conv === 'object' && 
              'id' in conv && 
              'title' in conv && 
              'messages' in conv &&
              Array.isArray(conv.messages)
            )
            .map(conv => ({
              ...conv,
              timestamp: new Date(conv.timestamp),
              messages: conv.messages.map(msg => ({
                ...msg,
                timestamp: new Date(msg.timestamp)
              }))
            }))
            .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
            .slice(0, MAX_STORED_CONVERSATIONS);
          
          if (validConversations.length > 0) {
            onLoadConversations(validConversations);
          }
        }
      } catch (error) {
        console.warn('Failed to load conversations from storage:', error);
      }
    };

    loadConversations();
  }, [onLoadConversations]);

  // Save conversations to localStorage when they change
  const saveConversations = useCallback((conversationsToSave: Conversation[]) => {
    try {
      // Only store the most recent conversations to avoid storage bloat
      const toStore = conversationsToSave
        .slice(0, MAX_STORED_CONVERSATIONS)
        .map(conv => ({
          ...conv,
          // Convert dates to strings for JSON serialization
          timestamp: conv.timestamp.toISOString(),
          messages: conv.messages.map(msg => ({
            ...msg,
            timestamp: msg.timestamp.toISOString()
          }))
        }));
      
      storage.set(STORAGE_KEY, toStore);
    } catch (error) {
      console.warn('Failed to save conversations to storage:', error);
    }
  }, []);

  // Auto-save conversations when they change
  useEffect(() => {
    if (conversations.length > 0) {
      const saveTimeout = setTimeout(() => {
        saveConversations(conversations);
      }, 1000); // Debounce saves by 1 second

      return () => clearTimeout(saveTimeout);
    }
  }, [conversations, saveConversations]);

  return {
    saveConversations,
    clearStorage: () => storage.remove(STORAGE_KEY)
  };
}
