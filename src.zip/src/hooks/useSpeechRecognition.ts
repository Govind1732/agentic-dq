import { useState, useRef, useCallback } from "react";
import type { WebkitSpeechRecognition, SpeechRecognitionEvent } from "../types/speechRecognition";

export const useSpeechRecognition = () => {
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<WebkitSpeechRecognition | null>(null);

  const startRecording = useCallback((onResult: (transcript: string) => void) => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      onResult(transcript);
    };

    recognitionRef.current = recognition;
    recognition.start();
  }, []);

  const stopRecording = useCallback(() => {
    recognitionRef.current?.stop();
    setIsRecording(false);
  }, []);

  return {
    isRecording,
    startRecording,
    stopRecording,
  };
};
