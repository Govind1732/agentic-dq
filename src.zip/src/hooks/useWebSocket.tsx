import { useEffect, useState } from "react";
import { io, Socket } from "socket.io-client";
import config from "../config/environment";

interface UseWebSocketReturn {
  socket: Socket | null;
  isConnected: boolean;
  sendMessage: (message: Record<string, unknown>) => void;
}

export function useWebSocket(): UseWebSocketReturn {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  const sendMessage = (message: Record<string, unknown>) => {
    if (socket && isConnected) {
      socket.emit("start_process", message);
    }
  };

  useEffect(() => {
    const newSocket = io(config.websocketUrl, {
      transports: ["polling", "websocket"],
      autoConnect: true,
    });

    newSocket.on("connect", () => {
      console.log("✅ Connected to WebSocket");
      setSocket(newSocket);
      setIsConnected(true);
    });

    newSocket.on("disconnect", () => {
      console.log("❌ Disconnected from WebSocket");
      setIsConnected(false);
    });

    newSocket.on("connect_error", (error) => {
      console.error("🔴 Connection error:", error);
      setIsConnected(false);
    });

    return () => {
      newSocket.removeAllListeners();
      newSocket.disconnect();
    };
  }, []);

  return { socket, isConnected, sendMessage };
}
