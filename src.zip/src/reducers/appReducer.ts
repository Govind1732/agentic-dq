import type { 
  Message, 
  ProgressStep, 
  AnalysisResult, 
  TableData, 
  LineageNode, 
  FlowDiagramData,
  Conversation 
} from '../types';

export interface AppState {
  messages: Message[];
  isLoading: boolean;
  sidebarOpen: boolean;
  isProcessing: boolean;
  progressSteps: ProgressStep[];
  analysisResults: AnalysisResult[];
  tableData: TableData[];
  finalReport: unknown | null;
  currentStep: string;
  flowDiagramData: FlowDiagramData | null;
  conversations: Conversation[];
  currentConversationId: string | null;
  stepTitlesShown: Set<string>; // Track shown step titles to prevent duplicates
}

export type AppAction =
  | { type: 'ADD_MESSAGE'; payload: Message }
  | { type: 'ADD_STEP_TITLE'; payload: Message }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'CLEAR_MESSAGES' }
  | { type: 'SET_PROCESSING'; payload: boolean }
  | { type: 'ADD_PROGRESS_STEP'; payload: ProgressStep }
  | { type: 'UPDATE_PROGRESS_STEP'; payload: ProgressStep }
  | { type: 'ADD_ANALYSIS_RESULT'; payload: AnalysisResult }
  | { type: 'ADD_TABLE_DATA'; payload: TableData }
  | { type: 'SET_FINAL_REPORT'; payload: unknown }
  | { type: 'SET_CURRENT_STEP'; payload: string }
  | { type: 'ADD_FLOW_NODE'; payload: LineageNode }
  | { type: 'SET_CONVERSATIONS'; payload: Conversation[] }
  | { type: 'SET_CURRENT_CONVERSATION'; payload: string | null }
  | { type: 'ADD_CONVERSATION'; payload: Conversation }
  | { type: 'UPDATE_CONVERSATION'; payload: { id: string; messages: Message[] } }
  | { type: 'RESET_RCA_STATE' };

export const initialState: AppState = {
  messages: [],
  isLoading: false,
  sidebarOpen: false,
  isProcessing: false,
  progressSteps: [],
  analysisResults: [],
  tableData: [],
  finalReport: null,
  currentStep: '',
  flowDiagramData: null,
  conversations: [],
  currentConversationId: null,
  stepTitlesShown: new Set(),
};

export function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: [...state.messages, action.payload],
      };

    case 'ADD_STEP_TITLE': {
      // Create a unique key for this step title
      const stepKey = `${action.payload.stepNumber}-${action.payload.content}`;
      
      // Check if this step title has already been shown
      if (state.stepTitlesShown.has(stepKey)) {
        return state; // Don't add duplicate step title
      }
      
      // Add the step title and mark it as shown
      const newStepTitlesShown = new Set(state.stepTitlesShown);
      newStepTitlesShown.add(stepKey);
      
      return {
        ...state,
        messages: [...state.messages, action.payload],
        stepTitlesShown: newStepTitlesShown,
      };
    }

    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };

    case 'TOGGLE_SIDEBAR':
      return {
        ...state,
        sidebarOpen: !state.sidebarOpen,
      };

    case 'CLEAR_MESSAGES':
      return {
        ...state,
        messages: [],
      };

    case 'SET_PROCESSING':
      return {
        ...state,
        isProcessing: action.payload,
      };

    case 'ADD_PROGRESS_STEP':
      return {
        ...state,
        progressSteps: [...state.progressSteps, action.payload],
      };

    case 'UPDATE_PROGRESS_STEP':
      return {
        ...state,
        progressSteps: state.progressSteps.map(step =>
          step.step === action.payload.step ? action.payload : step
        ),
      };

    case 'ADD_ANALYSIS_RESULT':
      return {
        ...state,
        analysisResults: [...state.analysisResults, action.payload],
      };

    case 'ADD_TABLE_DATA':
      return {
        ...state,
        tableData: [...state.tableData, action.payload],
      };

    case 'SET_FINAL_REPORT':
      return {
        ...state,
        finalReport: action.payload,
      };

    case 'SET_CURRENT_STEP':
      return {
        ...state,
        currentStep: action.payload,
      };

    case 'ADD_FLOW_NODE': {
      const existingNodes = state.flowDiagramData?.nodes || [];
      const newNode = action.payload;
      
      // Check if node already exists
      const nodeExists = existingNodes.some(node => node.id === newNode.id);
      
      const updatedNodes = nodeExists 
        ? existingNodes.map(node => node.id === newNode.id ? newNode : node)
        : [...existingNodes, newNode];

      return {
        ...state,
        flowDiagramData: {
          nodes: updatedNodes.sort((a, b) => a.step - b.step),
          edges: state.flowDiagramData?.edges || [],
          currentStep: state.currentStep === 'lineage_traversal' ? newNode.step : 0,
        },
      };
    }

    case 'RESET_RCA_STATE':
      return {
        ...state,
        isProcessing: false,
        progressSteps: [],
        analysisResults: [],
        tableData: [],
        finalReport: null,
        currentStep: '',
        messages: [],
        flowDiagramData: null,
        stepTitlesShown: new Set(),
      };

    case 'SET_CONVERSATIONS':
      return {
        ...state,
        conversations: action.payload,
      };

    case 'SET_CURRENT_CONVERSATION':
      return {
        ...state,
        currentConversationId: action.payload,
        // Clear current messages when switching conversations
        messages: [],
        progressSteps: [],
        analysisResults: [],
        tableData: [],
        finalReport: null,
        flowDiagramData: null,
        stepTitlesShown: new Set(),
      };

    case 'ADD_CONVERSATION':
      return {
        ...state,
        conversations: [action.payload, ...state.conversations],
      };

    case 'UPDATE_CONVERSATION':
      return {
        ...state,
        conversations: state.conversations.map(conv =>
          conv.id === action.payload.id
            ? { ...conv, messages: action.payload.messages, updated_at: new Date().toISOString() }
            : conv
        ),
        // If updating current conversation, also update messages
        messages: action.payload.id === state.currentConversationId 
          ? action.payload.messages 
          : state.messages,
      };

    default:
      return state;
  }
}
