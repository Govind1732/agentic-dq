import type { Message, Conversation } from '../types';

export interface AppState {
  conversations: Conversation[];
  activeConversationId: string | null;
  isLoading: boolean;
  sidebarOpen: boolean;
  sidebarHover: boolean;
  darkMode: boolean;
}

export type AppAction =
  | { type: 'ADD_CONVERSATION'; payload: Conversation }
  | { type: 'SET_ACTIVE_CONVERSATION'; payload: string | null }
  | { type: 'ADD_MESSAGE'; payload: Message }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'SET_SIDEBAR_HOVER'; payload: boolean }
  | { type: 'TOGGLE_DARK_MODE' }
  | { type: 'NEW_CONVERSATION' };

export const initialState: AppState = {
  conversations: [],
  activeConversationId: null,
  isLoading: false,
  sidebarOpen: false,
  sidebarHover: false,
  darkMode: false,
};

export function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'ADD_CONVERSATION':
      return {
        ...state,
        conversations: [...state.conversations, action.payload],
        activeConversationId: action.payload.id,
      };

    case 'SET_ACTIVE_CONVERSATION':
      return {
        ...state,
        activeConversationId: action.payload,
      };

    case 'ADD_MESSAGE': {
      const activeConversation = state.conversations.find(
        (conv) => conv.id === state.activeConversationId
      );

      if (!activeConversation) return state;

      return {
        ...state,
        conversations: state.conversations.map((conv) =>
          conv.id === state.activeConversationId
            ? {
                ...conv,
                messages: [...conv.messages, action.payload],
                lastMessage: action.payload.content,
                timestamp: new Date(),
              }
            : conv
        ),
      };
    }

    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };

    case 'TOGGLE_SIDEBAR':
      return {
        ...state,
        sidebarOpen: !state.sidebarOpen,
      };

    case 'SET_SIDEBAR_HOVER':
      return {
        ...state,
        sidebarHover: action.payload,
      };

    case 'TOGGLE_DARK_MODE':
      return {
        ...state,
        darkMode: !state.darkMode,
      };

    case 'NEW_CONVERSATION': {
      const newConversation: Conversation = {
        id: `conv_${Date.now()}`,
        title: 'New Chat',
        lastMessage: '',
        timestamp: new Date(),
        messages: [],
      };

      return {
        ...state,
        conversations: [...state.conversations, newConversation],
        activeConversationId: newConversation.id,
      };
    }

    default:
      return state;
  }
}
