export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: string;
  isJson?: boolean;
  type?: string;
  stepNumber?: number;
  stepTitle?: string;
  stepData?: Record<string, unknown>;
  sample_input?: Record<string, unknown>;
  feedback_options?: string[];
  extension_questions?: string[];
}

export const MESSAGE_TYPES = {
  BOT_INTRODUCTION: 'bot_introduction',
  STEP: 'step',
  NODE_RESPONSE: 'node_response',
  MESSAGE: 'message',
  FINAL: 'final_response',
} as const;

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  sidebarOpen: boolean;
}