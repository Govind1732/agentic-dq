export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  type?: string;
  sample_input?: Record<string, unknown>;
  feedback_options?: string[];
  extension_questions?: string[];
}

export interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  messages: Message[];
}

export const MESSAGE_TYPES = {
  BOT_INTRODUCTION: 'bot_introduction',
  STEP: 'step',
  MESSAGE: 'message',
  FINAL: 'final_response',
} as const;
