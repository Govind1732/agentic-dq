// Types for Speech Recognition API
export interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

export interface SpeechRecognitionResultList {
  [index: number]: SpeechRecognitionResult;
  length: number;
}

export interface SpeechRecognitionResult {
  [index: number]: SpeechRecognitionAlternative;
  length: number;
}

export interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

export interface WebkitSpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives: number;
  onstart: ((this: WebkitSpeechRecognition, ev: Event) => void) | null;
  onend: ((this: WebkitSpeechRecognition, ev: Event) => void) | null;
  onerror: ((this: WebkitSpeechRecognition, ev: Event) => void) | null;
  onresult:
    | ((this: WebkitSpeechRecognition, ev: SpeechRecognitionEvent) => void)
    | null;
  start(): void;
  stop(): void;
}

declare global {
  interface Window {
    SpeechRecognition: new () => WebkitSpeechRecognition;
    webkitSpeechRecognition: new () => WebkitSpeechRecognition;
  }
}

export interface SelectedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  file: File;
}
