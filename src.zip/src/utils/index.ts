import type { Message } from '../types';

/**
 * Generate unique ID
 */
export function generateId(): string {
  return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Create a simple message object
 */
export function createMessage(
  content: string,
  role: 'user' | 'assistant',
  type?: string
): Message {
  return {
    id: generateId(),
    content: content.trim(),
    role,
    timestamp: new Date().toISOString(),
    type: type || 'message',
  };
}

/**
 * Simple storage utilities
 */
export const storage = {
  set(key: string, value: unknown): boolean {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  },

  get<T>(key: string): T | null {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch {
      return null;
    }
  },

  remove(key: string): boolean {
    try {
      localStorage.removeItem(key);
      return true;
    } catch {
      return false;
    }
  }
};
